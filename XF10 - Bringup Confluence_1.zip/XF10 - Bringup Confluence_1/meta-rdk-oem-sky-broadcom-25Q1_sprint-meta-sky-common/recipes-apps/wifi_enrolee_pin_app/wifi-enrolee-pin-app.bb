DESCRIPTION = "This is the implementation for wifi_enrolee_pin_app"
SECTION = "base"
LICENSE = "CLOSED"
FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
DEPENDS = "hal-wifi-sky"
SRC_URI = "file://wifi_enrolee_pin_app.c \
"

CFLAGS_append += "-I ${STAGING_INCDIR}/ccsp"
LDFLAGS_append +=  "-L ${libdir}"

do_compile () {

    ${CC} -o ${WORKDIR}/wifi_enrolee_pin_app ${CFLAGS}  ${WORKDIR}/wifi_enrolee_pin_app.c -lhal_wifi
    
     
}

do_install () {
    install -d ${D}${bindir}/ 
    install -m 0755 ${WORKDIR}/wifi_enrolee_pin_app ${D}${bindir}/
}

FILES_${PN} += "${bindir}/*"
