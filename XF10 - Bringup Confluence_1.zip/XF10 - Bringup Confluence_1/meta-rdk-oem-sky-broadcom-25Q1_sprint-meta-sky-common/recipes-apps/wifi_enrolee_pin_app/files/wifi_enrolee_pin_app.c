/*
 * =====================================================================================
 *
 *       Filename:  wifi_enrolee_pin_app.c
 *
 *    Description:  Application to set the Enrolee pin from user.
 *
 *        Version:  0.0.1-SKY
 *        Created:  22/05/19 10:27:58
 *
 *         Author:  Sreejith Ravi 
 *   Organization:  SKY
 *
 * =====================================================================================
 */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include "wifi_hal.h"


#define WPS_UI_PORT                 		40500
#define OUTPUT_STRING_LENGTH_32       	 	32
#define ENROLEE_PIN_SETTING_VERSION       	"0.0.1-SKY"

static void usage(void)
{
	printf ("Enrolee pin setting: %s Build on %s\n", ENROLEE_PIN_SETTING_VERSION,  __DATE__ );

	printf("Usage: enrolee_pin_app [option]...\n");
	printf("-h             :To list supported options\n");
	printf("-a <apIndex>   :To set Access Point index\n");
	printf("-p <pin>       :To set  WPS enroll Pin\n");
	exit(0);
}

static int set_wps_env(char *uibuf)
{
	int wps_fd = -1;
	struct sockaddr_in to;
	int sentBytes = 0;
	uint32_t uilen = strlen(uibuf);

	if ((wps_fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		goto exit;
	}

	printf("\n Command send to WPS :  %s\n",uibuf);
	/* send to WPS */
	to.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	to.sin_family = AF_INET;
	to.sin_port = htons(WPS_UI_PORT);

	sentBytes = sendto(wps_fd, uibuf, uilen, 0, (struct sockaddr *) &to,
			sizeof(struct sockaddr_in));

	if (sentBytes != uilen) {
		goto exit;
	}

	/* Sleep 100 ms to make sure
	   WPS have received socket */
	usleep(100*1000);
	close(wps_fd);
	return 0;

exit:
	if (wps_fd >= 0)
		close(wps_fd);

	return -1;
}

int main (int argc, char *argv[])
{
	char *enroleePin = "12345678";
	int apIndex = 0;
	int option = -1;
	char buf[256]={0};
	int ret = 0;
	/* Display usage if no options or wrong options passed */
	if(argc < 2) {
		usage();
		goto exit;
	}
	while((option=getopt(argc,argv,"ha:p:")) != -1 ){

		/* Detect the end of options */
		if ( option == -1 ){
			break;
		}

		switch( option ){

			case 'h':
				{
					usage();
					goto exit;

				}break;

			case 'a':
				{
					apIndex += atoi(optarg);
				}break;

			case 'p':
				{
					enroleePin = optarg;
				}break;

			default:
				{
					usage();
					goto exit;
				}break;

		}
	}
	printf("Setting Enrolee PIN %s in apIndex %d \n",enroleePin, apIndex);
	/* Set the WPS Enrolee pin for this Access Point */
	if (wifi_setApWpsEnable(apIndex, 1) != 0)
	{
		printf("Failed to start WPS monitor \n");
		goto exit;
	}

	/* Set the WPS Enrolee pin for this Access Point */
	if (wifi_setApWpsEnrolleePin(apIndex, enroleePin) != 0)
	{
		printf("Failed to set Enrolee PIN \n");
		goto exit;
	}
	sprintf(buf, "SET wps_method=2 wps_sta_pin=%s wps_action=3 wps_config_command=1 wps_pbc_method=0 wps_ifname=wl%d wps_autho_sta_mac=FF:FF:FF:FF:FF:FF",enroleePin,apIndex);
	ret = set_wps_env(buf);
	if(ret == 0){
		printf("Successfully set Enrolee PIN %s in apIndex %d \n",enroleePin, apIndex);
	} else{
		printf(" Failed to set Enrolee PIN %s in apIndex %d \n",enroleePin, apIndex);
		goto exit;
	}
	return 0;
exit:
	return -1;
}
