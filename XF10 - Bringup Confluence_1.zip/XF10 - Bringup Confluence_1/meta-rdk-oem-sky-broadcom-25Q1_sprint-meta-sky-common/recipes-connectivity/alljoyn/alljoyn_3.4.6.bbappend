FILESEXTRAPATHS_prepend := "${THISDIR}/files:"

SRC_URI_remove_morty = " file://fix_morty_errors.patch"
SRC_URI_append_morty = " file://fix_morty_errors_sky.patch"