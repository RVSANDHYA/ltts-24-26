FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

RDEPENDS_${PN} = "ppp"
RDEPENDS_${PN}-server = "${PN}"
RRECOMMENDS_${PN} = "ppp-oe ppp-oa"

SRC_URI += " \
            file://1001-dt-rp-pppoe-ifname_config.patch \
            file://pppoe.conf \
            file://pppoe_config.sh \
            file://1002-rp-pppoe-atm.patch  \
            file://1003-pppoe-stop.patch  \
           "

do_install_append() {
    install -d ${D}${bindir}
    install -m 0777 ${WORKDIR}/pppoe.conf ${D}${sysconfdir}/ppp/pppoe.conf
    install -m 0777 ${WORKDIR}/pppoe_config.sh ${D}${bindir}/
}

EXTRA_OECONF= "--enable-plugin"

