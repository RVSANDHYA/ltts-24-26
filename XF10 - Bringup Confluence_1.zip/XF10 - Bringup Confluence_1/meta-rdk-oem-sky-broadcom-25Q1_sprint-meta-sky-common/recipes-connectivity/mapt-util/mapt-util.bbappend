FILESEXTRAPATHS_prepend := "${THISDIR}/files:"

SRC_URI += "file://0001_ivictl_sky_modifications.patch;patchdir=../ "
