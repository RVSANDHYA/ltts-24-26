FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

# Use common patches applicable for all platforms like Hub4, Ada

SRC_URI += " \
            file://0001-ppp-negotiation-start-with-PADT.patch \
            file://0002-ppp-disable-interface-configuration.patch \
           "
CFLAGS_append = " -I ${STAGING_INCDIR}/ "

