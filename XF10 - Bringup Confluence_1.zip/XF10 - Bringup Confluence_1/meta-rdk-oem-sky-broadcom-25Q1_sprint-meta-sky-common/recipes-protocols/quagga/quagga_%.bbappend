
EXTRA_OECONF_append = " --with-cflags="-Drpl_malloc=malloc -Drpl_realloc=realloc" "

FILESEXTRAPATHS_prepend:="${THISDIR}/files:"
SRC_URI_append = " file://quagga-valid-preferred-time-fix.patch "
SRC_URI_append = " file://prefix_counter_1765.patch "
