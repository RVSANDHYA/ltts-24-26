FILESEXTRAPATHS_prepend := "${THISDIR}/webcfg:"

SRC_URI_remove += "\
       file://webcfgeventhandler.patch \
"
