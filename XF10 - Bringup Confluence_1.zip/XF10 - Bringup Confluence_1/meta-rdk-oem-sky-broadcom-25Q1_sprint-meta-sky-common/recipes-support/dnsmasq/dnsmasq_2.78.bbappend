FILESEXTRAPATHS_prepend := "${THISDIR}/${BP}:"

SRC_URI_append = " file://HUB4_DisableIpv4.patch \ 
                   file://RDKCENTRAL_REFUSED_Response.patch "