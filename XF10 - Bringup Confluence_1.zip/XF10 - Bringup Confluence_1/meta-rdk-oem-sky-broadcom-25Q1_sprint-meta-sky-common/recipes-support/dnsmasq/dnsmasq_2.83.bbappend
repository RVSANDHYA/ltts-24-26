FILESEXTRAPATHS_prepend := "${THISDIR}/${BP}:"

SRC_URI_append = " file://HUB4_DisableIpv4.patch \
             file://HUB4_DisableIpv4_L07.patch \
             file://HUB4_DisableIpv4_Refactor.patch \
             file://HUB4_RestrictIPV4_DNSServer.patch \
             "
