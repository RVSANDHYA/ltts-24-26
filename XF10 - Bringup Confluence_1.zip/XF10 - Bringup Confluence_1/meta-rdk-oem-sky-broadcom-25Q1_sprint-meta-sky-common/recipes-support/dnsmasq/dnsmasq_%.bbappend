FILESEXTRAPATHS_prepend := "${THISDIR}/${BPN}:"

SRC_URI += "file://dnsmasq.conf"
SRC_URI += "file://dnsmasq.service"

do_install_append() {

    install -d ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/dnsmasq.service ${D}${systemd_unitdir}/system/dnsmasq.service

    install -d ${D}/var
    install -d ${D}${sysconfdir}
    install -d ${D}${sysconfdir}/default
    cp ${D}${sysconfdir}/dnsmasq.conf ${D}/var/
    cp ${D}${sysconfdir}/dnsmasq.conf ${D}${sysconfdir}/default
    touch ${D}/var/dhcp_options
    
}



FILES_${PN} += "/var/dnsmasq.conf \
                /etc/default/dnsmasq.conf \
                /etc/dhcp_options \
                /lib/systemd/system/dnsmasq.service \
               "
