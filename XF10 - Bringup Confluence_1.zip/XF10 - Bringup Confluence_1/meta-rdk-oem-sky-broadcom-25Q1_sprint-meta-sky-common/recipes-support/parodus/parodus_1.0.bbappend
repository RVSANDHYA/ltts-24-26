#
#CEDM 3.X support not yet available for ComscopeXB7
#Installing legacy one for backward compatibility
#

FILESEXTRAPATHS_prepend := "${THISDIR}/files:"

SRC_URI += "\
    file://mamjwwgtf.wpa \
"

do_install_append() {
   install -d ${D}/etc/parodus
   install -m 777 ${WORKDIR}/mamjwwgtf.wpa ${D}/etc/parodus/mamjwwgtf.wpa
}

FILES_${PN} += " \
        /etc/parodus/* \
"

