FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
SRC_URI += "file://002_ntp_sysevent_set.patch \
            file://003_ntp_error_when_no_sync.patch \
           "
do_install_append() {

	 sed -i -e 's#ExecStart=/usr/sbin/ntpd -u ntp:ntp -p /run/ntpd.pid -g#ExecStart=/usr/sbin/ntpd -u ntp:ntp -p /run/ntpd.pid -l /rdklogs/logs/ntpLog.log -c $NTP_CONF_TMP  -g#' ${D}${systemd_unitdir}/system/ntpd.service
	 sed -i '/\[Install\]/d'  ${D}${systemd_unitdir}/system/ntpd.service
	 sed -i '/WantedBy=multi-user.target/d'  ${D}${systemd_unitdir}/system/ntpd.service
}
PACKAGES += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203',' ntpq ','',d)}"
FILES_ntpq = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203','${sbindir}/ntpq','',d)}"

