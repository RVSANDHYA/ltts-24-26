inherit tigress-code-transformation-ecfs-search

FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
SRC_URI += "\
    file://ecfsmount_hub4.conf \
"

CFLAGS += "-DDEVICE_KEY_PATH=/nvram/"
CFLAGS += "-DVENDOR_MODEL_STRING=HUB4"

EXTRA_OECONF += " --enable-cpgecfsksearch"

do_install_append(){
    install -m 0755 ${S}/scripts/ecfsInit_broadband.sh ${D}${base_libdir}/rdk/ecfsInit.sh
    install -D -m 0644 ${WORKDIR}/ecfsmount_hub4.conf ${D}${systemd_unitdir}/system/securemount.service.d/ecfsmount.conf
    install -d ${D}/opt/secure/
}

FILES_${PN}_append = " ${systemd_unitdir}/system/securemount.service.d/ecfsmount.conf"
FILES_${PN}_append = " /opt/secure/"
