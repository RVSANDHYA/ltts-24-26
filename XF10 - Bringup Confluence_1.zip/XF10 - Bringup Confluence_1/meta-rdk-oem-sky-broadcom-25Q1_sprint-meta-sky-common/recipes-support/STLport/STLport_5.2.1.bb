SUMMARY = "Library for STLport"

LICENSE = "CLOSED"
PR = "r1"

SRC_URI = "https://sourceforge.net/projects/stlport/files/STLport/STLport-5.2.1/STLport-5.2.1.tar.bz2 \
           file://STLport-5.2.1.patch \
          "

S = "${WORKDIR}/STLport-${PV}"
LIB-SRC = "STLport-5.2.1"


SRC_URI[md5sum] = "a8341363e44d9d06a60e03215b38ddde"
SRC_URI[sha256sum] = "755b007b982c4545086c43affc8ed32c0acd577ee206eb1f6967e250c3546fc9"

LDFLAGS="-pthread -fexceptions  -fPIC -O2 -fuse-cxa-atexit"

EXTRA_OECONF = '--target=${TARGET_SYS} \
                --prefix=${prefix} \
                --bindir=${bindir} \
                --libdir=${D}${libdir} \
                --with-cxx=c++ \
                --with-cc=gcc \
                --enable-static \
               '

do_configure() {
	./configure ${EXTRA_OECONF}
}

do_install() {
        echo ${PWD}
        echo "Source Dir ${S}"
        install -d ${D}/${libdir}
        install -d ${D}/${includedir}/stlport dist/public/stlport/*
        install -d ${D}/${bindir}
        echo "Copying libs to ${D}/${libdir}"
        cp ${S}/build/lib/obj/arm-rdk-linux-gnueabi-gcc/so/*.so* ${D}/${libdir}
        cp ${S}/build/lib/obj/arm-rdk-linux-gnueabi-gcc/so/*.a ${D}/${libdir}
}

PARALLEL_MAKE = ""

BBCLASSEXTEND = "native"

