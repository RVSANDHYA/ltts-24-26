# Removing the patch for skyhub since validation is pending.
# Once verified patch will be applied back to skyhub devices as part of RDKB-44622

SRC_URI_remove += " file://CVE-2015-8946_fix.patch \
                   file://CVE-2016-1572_fix.patch \
                   file://CVE-2016-6224_fix.patch \
"
