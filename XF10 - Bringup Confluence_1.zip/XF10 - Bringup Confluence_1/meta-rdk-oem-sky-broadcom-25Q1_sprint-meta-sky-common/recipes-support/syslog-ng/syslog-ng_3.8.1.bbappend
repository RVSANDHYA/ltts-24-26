FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
SRC_URI += "file://syslog-ng.conf \
            file://syslog-ng.service \
           "
do_install_append() {
    install -d ${D}${sysconfdir}/${BPN}
    install -d ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/syslog-ng.service ${D}${systemd_unitdir}/system
    install -m 0644 ${WORKDIR}/syslog-ng.conf ${D}${sysconfdir}/${BPN}/syslog-ng.conf
}
FILES_${PN} += "${systemd_unitdir}/system/* ${sysconfdir}/${BPN}/*"
