FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
SRC_URI += "file://syslog-ng.conf \
           "
do_install_append() {
    install -d ${D}${sysconfdir}/${BPN}
    install -m 0644 ${WORKDIR}/syslog-ng.conf ${D}${sysconfdir}/${BPN}/syslog-ng.conf
}
FILES_${PN} += "${systemd_unitdir}/system/* ${sysconfdir}/${BPN}/*"
