
do_install_append() {
    rm ${D}${systemd_unitdir}/system/syslog-ecm.service
}
SYSTEMD_SERVICE_${PN}_remove += "syslog-ecm.service"

