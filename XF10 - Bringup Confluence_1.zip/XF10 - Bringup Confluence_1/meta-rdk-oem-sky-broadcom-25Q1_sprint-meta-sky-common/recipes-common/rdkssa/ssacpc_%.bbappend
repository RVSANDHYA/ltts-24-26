
do_install_append() {
    install -D -m 0644 ${S}/ssa_top/ssa_cpc/ssa_common/providers/CA/xpki/scripts/rdkb/ntpd-path-based/rdkssainit-rdkb-delayed.service ${D}${systemd_unitdir}/system/rdkssainit.service
    install -D -m 0644 ${S}/ssa_top/ssa_cpc/ssa_common/providers/CA/xpki/scripts/rdkb/ntpd-path-based/rdkssainit-rdkb-delayed.path ${D}${systemd_unitdir}/system/rdkssainit.path
}

SYSTEMD_SERVICE_${PN}_append = " rdkssainit.path"

LDFLAGS_append = " \
        -lsecure_wrapper \
       "

