
inherit systemd
export VENDOR_MODEL_STRING="HUB4"

do_install_append() {
    install -D -m 0644 ${S}/service/lxy-extractor-rdkb.service ${D}${systemd_unitdir}/system/lxy-extractor.service
    install -D -m 0644 ${S}/service/HUB4/lxy-extractor.conf ${D}${systemd_unitdir}/system/lxy-extractor.service.d/lxy-extractor.conf
    install -D -m 0755 ${S}/scripts/lxyinit.sh ${D}${bindir}/lxyinit.sh
}
SYSTEMD_SERVICE_${PN}_append = " lxy-extractor.service"
FILES_${PN}_append = " ${systemd_unitdir}/system/lxy-extractor.service.d/lxy-extractor.conf"
FILES_${PN}_append = " ${systemd_unitdir}/system/*"

