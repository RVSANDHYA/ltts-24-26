SRC_URI = "${RDK_GENERIC_ROOT_GIT}/rbuscore/devices/sky/sky_hub4;protocol=${RDK_GIT_PROTOCOL};branch=${RDK_GIT_BRANCH};destsuffix=git/device;name=config"

LICENSE = "CLOSED"

SRCREV_config = "${AUTOREV}"

S = "${WORKDIR}/git"

DEPENDS = "rbus"

do_install_append() {
   install -D -m 0644 ${S}/device/conf/rbus_start.conf ${D}${systemd_unitdir}/system/rbus.service.d/rbus_start.conf
   install -D -m 0644 ${S}/device/conf/rbus_start.conf ${D}${systemd_unitdir}/system/rbus_session_mgr.service.d/rbus_start.conf
}

FILES_${PN} += "${systemd_unitdir}/system/rbus_session_mgr.service.d/rbus_start.conf"
FILES_${PN} += "${systemd_unitdir}/system/rbus.service.d/rbus_start.conf"
