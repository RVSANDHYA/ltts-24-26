FILESEXTRAPATHS_prepend := "${THISDIR}/files:"

SRC_URI += "file://002_sky_customization.patch"

do_install_append () {
		## Changes for SOC
		install -d ${D}/rdklogger
		install -d ${D}/fss/gw/rdklogger
		ln -sf /etc/log4crc ${D}/rdklogger/log4crc
		ln -sf /etc/log4crc ${D}/fss/gw/rdklogger/log4crc
}

FILES_${PN} += " /rdklogger/ \
                 /fss/gw/rdklogger/ \
               "
