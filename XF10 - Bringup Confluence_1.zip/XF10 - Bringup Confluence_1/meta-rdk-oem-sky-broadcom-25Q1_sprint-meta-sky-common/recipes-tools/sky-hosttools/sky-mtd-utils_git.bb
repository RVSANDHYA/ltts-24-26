SUMMARY = "SKY/BCM Tools for managing memory technology devices"
DEPENDS = "zlib-native lzo-native e2fsprogs-native util-linux-native"
LICENSE = "CLOSED"

SRC_URI = "git://${RDK_GIT}/rdk/rdkb/components/sdk/devices/sky/hub4/mtd-utils;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=sky-mtd-utils"
SRCREV_${PN} = "${AUTOREV}"
PV = "1.0+git${SRCPV}"

S = "${WORKDIR}/git"

EXTRA_OEMAKE = "'CC=${CC}' 'RANLIB=${RANLIB}' 'AR=${AR}' 'CFLAGS=${CFLAGS} -I${S}/include -DWITHOUT_XATTR' 'BUILDDIR=${S}'"

do_install () {
	oe_runmake install DESTDIR=${D} SBINDIR=${sbindir} MANDIR=${mandir} INCLUDEDIR=${includedir}
        install -d ${D}${sbindir}
        install -m 0755 ${S}/ubi-utils/ubinize ${sbindir}
}


PARALLEL_MAKE = ""
inherit native
