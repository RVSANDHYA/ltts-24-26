DESCRIPTION = "Sky image packaging tools"
LICENSE = "CLOSED"

SRC_URI += "https://${NEXUS_SKY_HUB4}/tools/sky-mtd-utils/2.2/sky-mtd-utils-2.2.tar.gz;name=sky-mtd-utils_2.2"
SRC_URI[sky-mtd-utils_2.2.md5sum] = "e1533c103b3db0b1fcb35c97beeb734f"
SRC_URI[sky-mtd-utils_2.2.sha256sum] = "21ef6628cb463e92b1920c8d8b472130dab8938d9dff3869134971cfa9542579"

do_install() {
	install -d ${D}${bindir}
	install -d ${D}${bindir}/bin
	install -m 0755 ${WORKDIR}/cmplzma ${D}${bindir}
	install -m 0755 ${WORKDIR}/lzmacmd ${D}${bindir}
	install -m 0755 ${WORKDIR}/mkfs.jffs2 ${D}${bindir}/bin
}

inherit native

