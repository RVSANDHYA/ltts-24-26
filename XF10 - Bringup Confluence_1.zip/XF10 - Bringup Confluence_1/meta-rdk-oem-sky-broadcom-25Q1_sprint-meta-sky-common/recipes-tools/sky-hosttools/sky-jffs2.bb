SUMMARY = "BCM jffs2"
DEPENDS = "zlib lzo e2fsprogs util-linux"
LICENSE = "CLOSED"

SRC_URI = "git://${RDK_GIT}/rdk/rdkb/components/sdk/devices/sky/hub4/jffs2;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRCREV = "${AUTOREV}"
S = "${WORKDIR}/git"

EXTRA_OEMAKE = "'CC=${CC}' 'RANLIB=${RANLIB}' 'AR=${AR}' 'CFLAGS=${CFLAGS} -I${S}/include -DWITHOUT_XATTR' 'BUILDDIR=${S}'"

do_install () {
    install -d ${D}${bindir}/sky
    install -m 0755 ${S}/mkfs.jffs2 ${D}${bindir}/sky
}

inherit native
