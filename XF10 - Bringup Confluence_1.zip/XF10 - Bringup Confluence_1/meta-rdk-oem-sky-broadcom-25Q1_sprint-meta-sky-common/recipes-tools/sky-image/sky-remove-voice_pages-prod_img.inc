ROOTFS_POSTPROCESS_COMMAND += "remove_voicediagnostics_prod_img;"

remove_voicediagnostics_prod_img(){
	rm -f ${IMAGE_ROOTFS}/usr/www/Voip_Debug_GlobalParameter.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/Voip_Debug_ServiceProvider.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/Voip_SipAdvanced_ServiceProvider.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/Voip_SipBasic_GlobalParamaters.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/Voip_SipBasic_ServiceProvider.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/actionHandler/ajaxSet_voip_debug.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/actionHandler/ajaxSet_SIPAdvanced_ServiceProvider.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/actionHandler/ajaxSet_SIPBasic_GlobalParameter.php;
	rm -f ${IMAGE_ROOTFS}/usr/www/actionHandler/ajaxSet_SIPBasic_ServiceProvider.php;
}
