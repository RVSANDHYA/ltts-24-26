ROOTFS_POSTPROCESS_COMMAND += "remove_dropbear_socket_service; "

remove_dropbear_socket_service() {

    rm -f ${IMAGE_ROOTFS}${systemd_unitdir}/system/sockets.target.wants/dropbear.socket;
    rm -f ${IMAGE_ROOTFS}${systemd_unitdir}/system/dropbear.socket;
    rm -f ${IMAGE_ROOTFS}${systemd_unitdir}/system/tmp-dropbear.service;

}
