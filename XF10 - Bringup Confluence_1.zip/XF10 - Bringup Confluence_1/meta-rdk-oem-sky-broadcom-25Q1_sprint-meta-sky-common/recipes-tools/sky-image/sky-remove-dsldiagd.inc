ROOTFS_POSTPROCESS_COMMAND += "remove_dsldiagd_app;"

remove_dsldiagd_app() {

    rm -f ${IMAGE_ROOTFS}/usr/bin/dsldiagd;

}
