#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

#include "ccsp/ccsp_hal_ethsw.h"
/* To get number of eth ports in LAN side. */
extern int maxEthPortsSupported ();

#define CONSOLE_LOG_FILE "/rdklogs/logs/WANMANAGERLog.txt.0"


#define DBG_PRINT(fmt ...)     {\
    FILE     *fp        = NULL;\
    time_t now;\
    time(&now);\
    fp = fopen ( CONSOLE_LOG_FILE, "a+");\
    if (fp)\
    {\
        fprintf(fp, "%s", ctime(&now)); \
        fprintf(fp,fmt);\
        fprintf(fp,"\n"); \
        fclose(fp);\
    }\
}\

#define SLEEP_TIME 4

void refresh_external_switch()
{
    CCSP_HAL_ETHSW_PORT port;
    uint32_t enablePortBitmap = 0;
    INT max_phy_eth_ports = 0;

#if defined(FEATURE_RDKB_WAN_MANAGER) && defined(FEATURE_RDKB_AUTO_PORT_SWITCH)
    /* For DSL:4 ports, WANOE:3 ports*/
    max_phy_eth_ports = maxEthPortsSupported();
#else
    max_phy_eth_ports = CCSP_HAL_ETHSW_EthPort3;
#endif
    CCSP_HAL_ETHSW_ADMIN_STATUS  adminStatus = CCSP_HAL_ETHSW_AdminDown;

    for (port = CCSP_HAL_ETHSW_EthPort1; port <= max_phy_eth_ports; port++)
    {
        // Check to see if the port is enabled
        if (CcspHalEthSwGetPortAdminStatus(port, &adminStatus) == RETURN_OK)
        {
            DBG_PRINT("%s(): port %d: admin status = 0x%x\n", __FUNCTION__, port, adminStatus);
            // Save status into the bitmask
            enablePortBitmap |= ((adminStatus == CCSP_HAL_ETHSW_AdminUp ? 1 : 0) << port);

            // Disable the port
            CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminDown);
        }
    }

    sleep(SLEEP_TIME);

    for (port = CCSP_HAL_ETHSW_EthPort1; port <= max_phy_eth_ports; port++)
    {
        // If the port was previously enabled then enable the port
        // Workaround: let's enable all ports for now
        //if (enablePortBitmap & (1 << port))
        {
            DBG_PRINT("%s(): setting admin status up for port %d\n", __FUNCTION__, port);
            CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminUp);
        }
    }
}

void refresh_wifi()
{
    /* dis-associate connected wifi clients */
    system ("dmcli eRT setv Device.WiFi.AccessPoint.1.X_CISCO_COM_KickAssocDevices bool true");
    system ("dmcli eRT setv Device.WiFi.AccessPoint.2.X_CISCO_COM_KickAssocDevices bool true");

}

int main(int argc, char **argv)
{
    if (argc == 2) {
        if (strncmp (argv[1], "ethsw", strlen ("ethsw")) == 0) {
            DBG_PRINT ("[%s] calling to update ethsw setting \n",argv[0]);
            refresh_external_switch();
        }else if (strncmp (argv[1], "wifi", strlen ("wifi")) == 0) {
            DBG_PRINT ("[%s] calling to update wifi setting \n",argv[0]);
            refresh_wifi();
        }
        else {
            DBG_PRINT ("Invalid argument: Usage: [%s] ethsw/wifi \n", argv[0]);
        }
    }else {
        DBG_PRINT("gw_lan_refresh \n");
        refresh_external_switch();
        refresh_wifi();
    }
    return 0;
}
