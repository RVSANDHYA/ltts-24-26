FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

DEPENDS_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' nanomsg ', '', d)}"
DEPENDS_remove = " hal-dhcpv4c "

SRC_URI += " \
            file://vlan_util_hub4.sh \
            file://system_defaults_hub4 \
            file://igd_platform_dependent_inf.patch \
            file://monitor_log.sh \ 
            file://monitor_wifi_packets.sh \ 
            file://monitor_dhd_dump.sh \ 
            file://ntp_health_check.sh \
            file://ntp_recovery.sh \
"

CFLAGS_append = " -D_WAN_MANAGER_ENABLED_ -DHUB4_BFD_FEATURE_ENABLED -DHUB4_QOS_MARK_ENABLED -DHUB4_SELFHEAL_FEATURE_ENABLED -DSKY_RDKB"
CFLAGS_append = " -DWTS_ENABLED"
CFLAGS_append = " \
    -I=${includedir}/dbus-1.0 \
    -I=${libdir}/dbus-1.0/include \
    "
LDFLAGS_append = " -lccsp_common -ldbus-1 "
EXTRA_OECONF_append = "PLATFORM_HAL_SYNDICATION=yes"

IsRdkbExtSupported = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', 'true', 'false', d)}"
EXTRA_OECONF_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', '--enable-extender', '', d)}"

do_install_append () {
	# Config files and scripts
	install -m 755 ${S}/source/scripts/init/system/utopia_init_hub4.sh ${D}${sysconfdir}/utopia/utopia_init.sh
	install -m 755 ${WORKDIR}/vlan_util_hub4.sh ${D}${sysconfdir}/utopia/service.d/vlan_util_hub4.sh
	install -m 644 ${WORKDIR}/system_defaults_hub4 ${D}${sysconfdir}/utopia/system_defaults
    if [ "${IsRdkbExtSupported}" = "false" ]; then
    	rm -rf ${D}${sysconfdir}/utopia/registration.d/15_wecb
        ln -sf /usr/bin/10_ntpd ${D}${sysconfdir}/utopia/registration.d/10_ntpd
    fi
    ln -sf /usr/bin/10_mcastproxy ${D}${sysconfdir}/utopia/post.d/10_mcastproxy
    ln -sf /usr/bin/10_mldproxy ${D}${sysconfdir}/utopia/post.d/10_mldproxy
    ln -sf /usr/bin/15_igd ${D}${sysconfdir}/utopia/post.d/15_igd

    # Creating symbolic links to install files required for extender mode in RDKB
    if [ "${IsRdkbExtSupported}" = "true" ]; then
        install -d ${D}${sysconfdir}/utopia/svc_router
        install -d ${D}${sysconfdir}/utopia/svc_common
        install -d ${D}${sysconfdir}/utopia/service.d/service_devicemode
        install -m 755 ${S}/source/scripts/init/service.d/service_devicemode/*.sh ${D}${sysconfdir}/utopia/service.d/service_devicemode

        # Creating symbolic links to install files in specific directory as in legacy builds
        ln -sf /usr/bin/02_devicemode ${D}${sysconfdir}/utopia/svc_common/02_devicemode
        ln -sf /usr/bin/02_ipv4 ${D}${sysconfdir}/utopia/svc_common/02_ipv4
        ln -sf /usr/bin/02_lanHandler ${D}${sysconfdir}/utopia/svc_common/02_lanHandler
        ln -sf /usr/bin/02_multinet ${D}${sysconfdir}/utopia/svc_common/02_multinet
        ln -sf /usr/bin/10_firewall ${D}${sysconfdir}/utopia/svc_common/10_firewall
        ln -sf /usr/bin/10_ntpd ${D}${sysconfdir}/utopia/svc_common/10_ntpd
        ln -sf /usr/bin/15_dhcp_server ${D}${sysconfdir}/utopia/svc_common/15_dhcp_server
    	ln -sf /usr/bin/20_routing ${D}${sysconfdir}/utopia/svc_common/20_routing   
        ln -sf /usr/bin/25_crond ${D}${sysconfdir}/utopia/svc_common/25_crond
        
        ln -sf /usr/bin/15_ccsphs ${D}${sysconfdir}/utopia/svc_router/15_ccsphs
    fi

	install -d ${D}/fss/gw/usr/bin
	install -d ${D}/fss/gw/usr/sbin
	ln -sf ${sbindir}/log_start.sh ${D}/fss/gw/usr/sbin/log_start.sh
	ln -sf ${sbindir}/log_handle.sh ${D}/fss/gw/usr/sbin/log_handle.sh
	ln -sf ${bindir}/firewall ${D}/fss/gw/usr/bin/firewall
	ln -sf ${bindir}/GenFWLog ${D}/fss/gw/usr/bin/GenFWLog
	ln -sf ${bindir}/syseventd_fork_helper ${D}/fss/gw/usr/bin/syseventd_fork_helper
    # Remove the Broadcom version of the file. Hub4 traffic_count utility is installed through userspace_apps.
    rm -f ${D}${sbindir}/traffic_count

    #install sky directory in etc
    install -d ${D}/${sysconfdir}/sky
    install -m 755 ${WORKDIR}/monitor_log.sh ${D}${sysconfdir}/sky/monitor_log.sh
    install -m 755 ${WORKDIR}/monitor_wifi_packets.sh ${D}${sysconfdir}/sky/monitor_wifi_packets.sh
    install -m 755 ${WORKDIR}/monitor_dhd_dump.sh ${D}${sysconfdir}/sky/monitor_dhd_dump.sh
    install -m 755 ${WORKDIR}/ntp_health_check.sh ${D}${sysconfdir}/sky/ntp_health_check.sh
    install -m 755 ${WORKDIR}/ntp_recovery.sh ${D}${sysconfdir}/sky/ntp_recovery.sh

    #install fss path
    install -d ${D}/fss/gw/etc/utopia/service.d
    install -m 0755 ${S}/source/scripts/init/service.d/log_env_var.sh ${D}${sysconfdir}/utopia/service.d/
    ln -sf ${sysconfdir}/utopia/service.d/log_env_var.sh ${D}/fss/gw/etc/utopia/service.d/log_env_var.sh

    #move logrotate.sh from cron.every5minute to cron.everyminute
    rm -rf ${D}${sysconfdir}/cron/cron.every5minute/logrotate.sh
    install -d ${D}${sysconfdir}/cron/cron.everyminute
    install -m 755 ${S}/source/scripts/init/service.d/logrotate.sh ${D}${sysconfdir}/cron/cron.everyminute/
}

do_configure_prepend () {
    sed -i '/02_wan.c/d' ${S}/source/scripts/init/c_registration/Makefile.am
    sed -e s/02_wan//g -i ${S}/source/scripts/init/c_registration/Makefile.am
}

FILES_${PN} += " \
               /fss/gw/usr/sbin/log_start.sh \
               /fss/gw/usr/sbin/log_handle.sh \
               ${sysconfdir}/utopia/service.d/log_env_var.sh \
               /fss/gw/etc/utopia/service.d/log_env_var.sh \
               /fss/gw/usr/bin/GenFWLog \
               /fss/gw/usr/bin/firewall \
               /fss/gw/usr/bin/syseventd_fork_helper \
               ${sysconfdir}/sky/* \
               "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', '${sysconfdir}/utopia/service.d/service_devicemode/*', '', d)}" \
               "
