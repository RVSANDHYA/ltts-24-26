#!/bin/sh
source /etc/log_timestamp.sh
source /etc/utopia/service.d/log_capture_path.sh
source /etc/utopia/service.d/log_env_var.sh
source /etc/RebootCondition.sh

CRONTAB_DIR="/var/spool/cron/crontabs/"
CRONTAB_FILE=$CRONTAB_DIR"root"
CRONFILE_BK="/tmp/cron_tab_bk.txt"
FILE_LOCK="/tmp/ntp_check.lock"
MAX_RETRY_COUNT=10

uptime=`cat /proc/uptime | awk '{ print $1 }' | cut -d"." -f1`

#Uptime should be more than 10mins
if [ $uptime -lt 3600 ]; then
   exit
fi

count=0
#Only one process should schedule cron at a time
while : ; do
    if [ $count -lt $MAX_RETRY_COUNT ]; then
        if [ -f $FILE_LOCK ]; then
            echo_t "SKY_NTP_MONITOR: another instance is running"
            sleep 1;
            count=$((count+1))
            continue;
        else
            # Creating lock to allow one process at a time
            touch $FILE_LOCK
            break;
        fi
    else
        echo_t "SKY_NTP_MONITOR: Exiting, another instance is running and max retry reached"
        exit 1
    fi
done

NTPD_STATUS=`sysevent get ntp_time_sync`
WAN_STATUS=`sysevent get wan-status`
IPv4_STATUS=`sysevent get ipoe_health_check_ipv4_status`
IPv6_STATUS=`sysevent get ipoe_health_check_ipv6_status`

if ( [ "x$NTPD_STATUS" != "x1" ] && [ "$WAN_STATUS" == "started" ] && ( [ "x$IPv4_STATUS" == "xsuccess" ] || [ "x$IPv6_STATUS" == "xsuccess" ] )); then

    ntp_restart_count=`sysevent get ntp_restart_count`
    if [ "x$ntp_restart_count" == "x" ]; then
        echo_t "SKY_NTP_MONITOR : NTP sync failed, restarting the NTPD"
        sysevent set ntpd-restart
        sysevent set ntp_restart_count 1

    elif [ -f $CRONTAB_FILE ]; then
        echo_t "SKY_NTP_MONITOR : NTP sync failed after one manual ntp restart, so scheduling the device to reboot"
        ExtractMaintenanceTime
        start_time_hh=$((start_time/3600))
        cronPattern="15 $start_time_hh * * *"
        # Dump existing cron jobs to a file
        crontab -l -c $CRONTAB_DIR > $CRONFILE_BK
        echo_t "SKY_NTP_MONITOR : ntp_recovery.sh adding into the cron job"
        echo "$cronPattern /etc/sky/ntp_recovery.sh" >> $CRONFILE_BK
        echo_t "SKY_NTP_MONITOR : Removing ntp_health_check.sh from cron job since CPE reboot scheduled for ntp recovery"
        sed -i '/ntp_health_check.sh/d' $CRONFILE_BK
        crontab $CRONFILE_BK -c $CRONTAB_DIR
        rm -rf $CRONFILE_BK
    fi
fi
rm -f $FILE_LOCK
