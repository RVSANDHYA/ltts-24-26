#!/bin/sh
source /etc/log_timestamp.sh
source /etc/utopia/service.d/log_capture_path.sh
source /etc/utopia/service.d/log_env_var.sh

storedTime=`syscfg get lastActiontakentime`
    if [ "$storedTime" != "" ] || [ "$storedTime" -ne 0 ]
    then
        currTime=$(date -u +"%s")
        diff=$(($currTime-$storedTime))
        diff_in_minutes=$(($diff / 60))
        diff_in_hours=$(($diff_in_minutes / 60))
        if [ "$diff_in_hours" -ge 24 ]
        then
            syscfg set todays_reboot_count 0
            syscfg set lastActiontakentime 0
            syscfg commit
        fi
    fi
MAX_REBOOT_COUNT=`syscfg get max_reboot_count`
TODAYS_REBOOT_COUNT=`syscfg get todays_reboot_count`
    if [ "$TODAYS_REBOOT_COUNT" -ge "$MAX_REBOOT_COUNT" ]
    then
        echo_t "SKY_NTP_MONITOR : Today's max reboot count already reached, please wait for reboot till next 24 hour window"
    else

        NTPD_STATUS=`sysevent get ntp_time_sync`
        WAN_STATUS=`sysevent get wan-status`
        REBOOT_WAIT="/tmp/.waitingreboot"

        if [ "x$NTPD_STATUS" != "x1" ] && [ "$WAN_STATUS" == "started" ] && [ ! -e $REBOOT_WAIT ]; then
            echo_t "SKY_NTP_MONITOR : NTP sync failed after manual ntp restart try, rebooting the device to recover ntp"
	    syscfg set todays_reboot_count $TODAYS_REBOOT_COUNT
            syscfg set lastActiontakentime $currTime
            echo_t "SKY_NTP_MONITOR : Updating the last reboot reason as ntp_sync_failure_reboot and last reboot counter to 1"
            syscfg set X_RDKCENTRAL-COM_LastRebootReason "ntp_sync_failure_reboot"
            syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
            syscfg commit
            sync
            echo_t "SKY_NTP_MONITOR : take log back up and reboot"
            sh /rdklogger/backupLogs.sh
        else
            exit 0
        fi
    fi
