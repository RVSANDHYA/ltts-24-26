#!/bin/sh

##################################################################################
# If not stated otherwise in this file or this component's Licenses.txt file the
# following copyright and licenses apply:

#  Copyright 2020 RDK Management

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################

source /etc/utopia/service.d/log_capture_path.sh
WL0_CONSOLEDUMP="/tmp/.consoledump_wl0.txt"
WL1_CONSOLEDUMP="/tmp/.consoledump_wl1.txt"
LAST_TIMESTAMP_FILE="/tmp/.dhd_last_timestamp.txt"
RDKB_DHD_TIMESTAMP_FILE="/tmp/.rdkb_dhd_timestamp.txt"

UPTIME=`awk '{print $1}' /proc/uptime | awk -F '.' '{print $1}'`

if [ "$UPTIME" -lt 3600 ]
then
    exit 0
fi

CRONTAB_DIR="/var/spool/cron/crontabs/"
CRONTAB_FILE=$CRONTAB_DIR"root"
CRONFILE_BK="/tmp/cron_tab$$.txt"
NV_RESTART="nvram restart"
#Pending reboot flags
XPKI_CERT_UPDATE_REBOOT_SCHEDULED="/tmp/.XpkiCrtUpdtdWaitingReboot"
RFC_REBOOT_SCHEDULED="/tmp/.RfcwaitingReboot"
DOWNLOAD_INPROGRESS="/tmp/.downloadingfw"
REBOOT_WAIT="/tmp/.waitingreboot"
NVRAM_RESTART_SCHEDULED="/tmp/.nvramRestartWaiting"
KERNEL_VERSION=`uname -r`

driver_reload()
{
   echo_t "DHD module reloading..."
   rm -rf /tmp/nvramloaded
   rmmod dhd
   insmod /lib/modules/$KERNEL_VERSION/extra/dhd.ko firmware_path=/etc/wlan/dhd mfg_firmware_path=/etc/wlan/dhd/mfg  dhd_dpc_prio=5  iface_name=wl  dhd_console_ms=0
   nvram restart
   sh /etc/sky/sky_dhd_monitor_reboot.sh fast_restart &
}

ScheduleCron()
{
   #calculate random time in sec
   rand_time_in_sec=`awk -v min=3600 -v max=14400 -v seed="$(date +%N)" 'BEGIN{srand(seed);print int(min+rand()*(max-min+1))}'`

        # To avoid cron to be set beyond 24 hr clock limit
        if [ $rand_time_in_sec -ge 86400 ]
        then
                rand_time_in_sec=$((rand_time_in_sec-86400))
                echo_t "[monitor_dhd_dump.sh] Random time in sec exceed 24 hr limit.setting it correct limit" >> $LOG_FILE

        fi

        #conversion of random generated time to HH:MM:SS format
                #calculate random second
                rand_time=$rand_time_in_sec
                rand_sec=$((rand_time%60))

                #calculate random minute
                rand_time=$((rand_time/60))
                rand_min=$((rand_time%60))

                #calculate random hour
                rand_time=$((rand_time/60))
                rand_hr=$((rand_time%60))

        # Dump existing cron jobs to a file & add new job
        crontab -l -c $CRONTAB_DIR > $CRONFILE_BK
        echo "$rand_min $rand_hr * * * $NV_RESTART" >> $CRONFILE_BK
        crontab $CRONFILE_BK -c $CRONTAB_DIR
        rm -rf $CRONFILE_BK
        touch $NVRAM_RESTART_SCHEDULED
}

dhd -i wl0 consoledump > $WL0_CONSOLEDUMP
dhd -i wl1 consoledump > $WL1_CONSOLEDUMP

dhd -i wl0 consoledump >/dev/null 2>&1
RESULT=`echo $?`

if [ "$RESULT" != "0" ]; then
    echo_t "RDKB_DHD_DUMP_ERROR: Getting DHD dump output error for wl0 interface"
    echo_t "=========================== wl0 dhd dump output ================================"
    cat $WL0_CONSOLEDUMP
    echo_t "================================================================================"
fi

dhd -i wl1 consoledump >/dev/null 2>&1
RESULT=`echo $?`

if [ "$RESULT" != "0" ]; then
    echo_t "RDKB_DHD_DUMP_ERROR: Getting DHD dump output error for wl1 interface"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
fi

RESULT=`cat $WL0_CONSOLEDUMP | grep "wl0: rxfifo-1 overflows"`
ERROR_RESULT=`cat $WL0_CONSOLEDUMP | grep "rxmgmt/ctrl nframes: 0!!!" | wc -l`

if [ "$RESULT" != "" ]; then
    echo_t "RDKB_DHD_RX_OVERFLOW_WL0: rxfifo overflow error observed for wl0 interface"
    echo_t "=========================== wl0 dhd dump output ================================"
    cat $WL0_CONSOLEDUMP
    echo_t "================================================================================"
    if [ $ERROR_RESULT -gt 10 ];then
        echo_t "RDKB_DHD_RX_OVERFLOW_RECOVER_WL0: Recovering the rx overflow on wl0 interface with a fast restart"
	driver_reload
    fi
fi

RESULT=`cat $WL1_CONSOLEDUMP | grep "wl1: rxfifo-1 overflows"`
ERROR_RESULT=`cat $WL1_CONSOLEDUMP | grep "rxmgmt/ctrl nframes: 0!!!" | wc -l`

if [ "$RESULT" != "" ]; then
    echo_t "RDKB_DHD_RX_OVERFLOW_WL1: rxfifo overflow error observed for wl1 interface"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
    if [ $ERROR_RESULT -gt 10 ];then
        echo_t "RDKB_DHD_RX_OVERFLOW_RECOVER_WL1: Recovering the rx overflow on wl1 interface with a fast restart"
	driver_reload
    fi
fi

RESULT=`cat $WL0_CONSOLEDUMP | grep "wl0: wlc_dpc HAMMERING fatal"`
`wl -i wl0 assoclist > /tmp/wl0_assoclist.txt`
if [ "$RESULT" != "" ] && [ ! -s /tmp/wl0_assoclist.txt ]; then
    echo_t "RDKB_DPC_HAMMERING: observed fatal error on wl0 interface due to dpc hammering: dumping and recovering"
    echo_t "=========================== wl0 dhd dump output ================================"
    cat $WL0_CONSOLEDUMP
    echo_t "================================================================================"
    driver_reload
fi

RESULT=`cat $WL1_CONSOLEDUMP | grep "wl1: wlc_dpc HAMMERING fatal"`
`wl -i wl1 assoclist > /tmp/wl1_assoclist.txt`
if [ "$RESULT" != "" ] && [ ! -s /tmp/wl1_assoclist.txt ]; then
    echo_t "RDKB_DPC_HAMMERING: observed fatal error on wl1 interface due to dpc hammering: dumping and recovering"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
    driver_reload
fi

RESULT=`cat $WL0_CONSOLEDUMP | grep "pciedev_queue_d2h_req full"`

if [ "$RESULT" != "" ]; then
    echo_t "RDKB_DHD_PCIEDEV_QUEUE_REQ_FULL_WL0: pciedev_queue_d2h_req full in wl0 interface"
    echo_t "=========================== wl0 dhd dump output ================================"
    cat $WL0_CONSOLEDUMP
    echo_t "================================================================================"
fi

RESULT=`cat $WL1_CONSOLEDUMP | grep "pciedev_queue_d2h_req full"`

if [ "$RESULT" != "" ]; then
    echo_t "RDKB_DHD_PCIEDEV_QUEUE_REQ_FULL_WL1: pciedev_queue_d2h_req full in wl1 interface"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
fi
# Check if the RDKB_DHD_TIMESTAMP_FILE exists
if [ ! -f "$RDKB_DHD_TIMESTAMP_FILE" ]; then
    echo "RDKB_DHD_STATE_DOWN_WL0 = 0" > "$RDKB_DHD_TIMESTAMP_FILE"
    echo "RDKB_DHD_STATE_DOWN_WL1 = 0" >> "$RDKB_DHD_TIMESTAMP_FILE"
    echo "RDKB_DHD_DRIVER_DOWN_WL0 = 0" >> "$RDKB_DHD_TIMESTAMP_FILE"
    echo "RDKB_DHD_DRIVER_DOWN_WL1 = 0" >> "$RDKB_DHD_TIMESTAMP_FILE"
    Modified_Timestamp_file=0
else
    Modified_Timestamp_file=1
fi

RESULT=`cat $WL0_CONSOLEDUMP | grep "wlc_enable_probe_req: state down"`
TIMESTAMP=$(echo "$RESULT" | tail -n 1 | awk '{print $1}')
LAST_PROCESSED_TIMESTAMP=$(grep "RDKB_DHD_STATE_DOWN_WL0" "$RDKB_DHD_TIMESTAMP_FILE" | awk '{print $3}')
if [ "$RESULT" != "" ] && [ "$LAST_PROCESSED_TIMESTAMP" != "$TIMESTAMP" ]; then
    sed -i "s/RDKB_DHD_STATE_DOWN_WL0 =.*/RDKB_DHD_STATE_DOWN_WL0 = $TIMESTAMP/" "$RDKB_DHD_TIMESTAMP_FILE"
    Modified_Timestamp_file=1
    echo_t "RDKB_DHD_STATE_DOWN_WL0: wlc_enable_probe_req: state down in wl0 interface"
    echo_t "=========================== wl0 dhd dump output ================================"
    cat $WL0_CONSOLEDUMP
    echo_t "================================================================================"
fi

RESULT=`cat $WL1_CONSOLEDUMP | grep "wlc_enable_probe_req: state down"`
TIMESTAMP=$(echo "$RESULT" | tail -n 1 | awk '{print $1}')
LAST_PROCESSED_TIMESTAMP=$(grep "RDKB_DHD_STATE_DOWN_WL1" "$RDKB_DHD_TIMESTAMP_FILE" | awk '{print $3}')
if [ "$RESULT" != "" ] && [ "$LAST_PROCESSED_TIMESTAMP" != "$TIMESTAMP" ] ; then
    sed -i "s/RDKB_DHD_STATE_DOWN_WL1 =.*/RDKB_DHD_STATE_DOWN_WL1 = $TIMESTAMP/" "$RDKB_DHD_TIMESTAMP_FILE"
    Modified_Timestamp_file=1
    echo_t "RDKB_DHD_STATE_DOWN_WL1: wlc_enable_probe_req: state down in wl1 interface"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
fi

RESULT=`cat $WL0_CONSOLEDUMP | grep "wlc_scan_request_ex, can not scan while driver is down"`
TIMESTAMP=$(echo "$RESULT" | tail -n 1 | awk '{print $1}')
LAST_PROCESSED_TIMESTAMP=$(grep "RDKB_DHD_DRIVER_DOWN_WL0" "$RDKB_DHD_TIMESTAMP_FILE" | awk '{print $3}')
if [ "$RESULT" != "" ] && [ "$LAST_PROCESSED_TIMESTAMP" != "$TIMESTAMP" ]; then
    sed -i "s/RDKB_DHD_DRIVER_DOWN_WL0 =.*/RDKB_DHD_DRIVER_DOWN_WL0 = $TIMESTAMP/" "$RDKB_DHD_TIMESTAMP_FILE"
    Modified_Timestamp_file=1
    echo_t "RDKB_DHD_DRIVER_DOWN_WL0: wlc_scan_request_ex, can not scan while driver is down in wl0 interface"
    echo_t "=========================== wl0 dhd dump output ================================"
    cat $WL0_CONSOLEDUMP
    echo_t "================================================================================"
fi

RESULT=`cat $WL1_CONSOLEDUMP | grep "wlc_scan_request_ex, can not scan while driver is down"`
TIMESTAMP=$(echo "$RESULT" | tail -n 1 | awk '{print $1}')
LAST_PROCESSED_TIMESTAMP=$(grep "RDKB_DHD_DRIVER_DOWN_WL1" "$RDKB_DHD_TIMESTAMP_FILE" | awk '{print $3}')
if [ "$RESULT" != "" ] && [ "$LAST_PROCESSED_TIMESTAMP" != "$TIMESTAMP" ]; then
    sed -i "s/RDKB_DHD_DRIVER_DOWN_WL1 =.*/RDKB_DHD_DRIVER_DOWN_WL1 = $TIMESTAMP/" "$RDKB_DHD_TIMESTAMP_FILE"
    Modified_Timestamp_file=1
    echo_t "RDKB_DHD_DRIVER_DOWN_WL1: wlc_scan_request_ex, can not scan while driver is down in wl1 interface"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
fi
#### SKYH4-7355
wl_flag=0
BOX_TYPE=`grep -i "BOX_TYPE" /etc/device.properties  | cut -f2 -d=`
if  [ "$BOX_TYPE" = "HUB4" ]; then
	wl0_ccode=`nvram get wl0_country_code`
	wl1_ccode=`nvram get wl1_country_code`

	if [ "$wl0_ccode" != "IT" ]; then
           echo_t "NVRAM_WL0_COUNTRY_CODE: wl0_country_code value is $wl0_ccode. Setting it to IT"
           nvram set wl0_country_code=IT
           wl_flag=1
        fi

        if [ "$wl1_ccode" != "IT" ]; then
           echo_t "NVRAM_WL1_COUNTRY_CODE: wl1_country_code value is $wl1_ccode. Setting it to IT"
           nvram set wl1_country_code=IT
           wl_flag=1
        fi

	if [ "$wl_flag" = "1" ]; then
           nvram commit restart
           sleep 6
           wl_flag=0
           systemctl restart ccspwifiagent.service
        fi

fi
#### SKYH4-7355

DRIVER_DOWN_RESULT=$(dmcli eRT getv Device.WiFi.Radio.1.Enable | grep "value" | cut -f3 -d":" | cut -f2 -d" ")
DRIVER_STATUS_RESULT=$(dmcli eRT getv Device.WiFi.Radio.1.Status | grep "value" | cut -f3 -d":" | cut -f2 -d" ")
if [ "$DRIVER_DOWN_RESULT" = "true" ] && [ "$DRIVER_STATUS_RESULT" = "Down" ]; then
    echo_t "RDKB_DHD_DRIVER_DOWN_WL0: Recovering  wl0 driver down"
    wl -i wl0 radio on
    wl -i wl0 up
fi

DRIVER_DOWN_RESULT=$(dmcli eRT getv Device.WiFi.Radio.2.Enable | grep "value" | cut -f3 -d":" | cut -f2 -d" ")
DRIVER_STATUS_RESULT=$(dmcli eRT getv Device.WiFi.Radio.2.Status | grep "value" | cut -f3 -d":" | cut -f2 -d" ")
if [ "$DRIVER_DOWN_RESULT" = "true" ] && [ "$DRIVER_STATUS_RESULT" = "Down" ]; then
    echo_t "RDKB_DHD_DRIVER_DOWN_WL1: Recovering  wl1 driver down"
    wl -i wl1 radio on
    wl -i wl1 up
fi

#telemetry support for SKYH4-5769
CHANIM_RESULT=`wl -i wl0 chanim_stats | grep "txop"`
DRIVER_DOWN_RESULT=$(dmcli eRT getv Device.WiFi.Radio.1.Enable | grep "value" | cut -f3 -d":" | cut -f2 -d" ")
if [ "$CHANIM_RESULT" = "" ]  &&  [ "$DRIVER_DOWN_RESULT" = "true" ]; then
    echo_t "RDKB_CHANIM_STATS_WL0: chanim_stats are empty in wl0 interface"

    if [ -f $NVRAM_RESTART_SCHEDULED ] || [ -f $XPKI_CERT_UPDATE_REBOOT_SCHEDULED ] || [ -f $RFC_REBOOT_SCHEDULED ] || [ -f $DOWNLOAD_INPROGRESS ] || [ -f $REBOOT_WAIT ]
    then
        echo_t "[monitor_dhd_dump.sh] nvram restart or Reboot is already scheduled"
    else
        ScheduleCron
        echo "w0" > $NVRAM_RESTART_SCHEDULED
    fi
else
    if [ -f $NVRAM_RESTART_SCHEDULED ]; then
        RESULT=`cat $NVRAM_RESTART_SCHEDULED | grep "w0"`
        if [ "$RESULT" != "" ]; then
            crontab -l | grep -v 'nvram restart'  | crontab -
            rm $NVRAM_RESTART_SCHEDULED
        fi
    fi
fi

CHANIM_RESULT=`wl -i wl1 chanim_stats | grep "txop"`
DRIVER_DOWN_RESULT=$(dmcli eRT getv Device.WiFi.Radio.2.Enable | grep "value" | cut -f3 -d":" | cut -f2 -d" ")
if [ "$CHANIM_RESULT" = "" ]  &&  [ "$DRIVER_DOWN_RESULT" = "true" ]; then
    echo_t "RDKB_CHANIM_STATS_WL1: chanim_stats are empty in wl1 interface"

    if [ -f $NVRAM_RESTART_SCHEDULED ] || [ -f $XPKI_CERT_UPDATE_REBOOT_SCHEDULED ] || [ -f $RFC_REBOOT_SCHEDULED ] || [ -f $DOWNLOAD_INPROGRESS ] || [ -f $REBOOT_WAIT ]
    then
        echo_t "[monitor_dhd_dump.sh] nvram restart or Reboot is already scheduled"
    else
        ScheduleCron
        echo "w1" > $NVRAM_RESTART_SCHEDULED
    fi
else
    if [ -f $NVRAM_RESTART_SCHEDULED ]; then
        RESULT=`cat $NVRAM_RESTART_SCHEDULED | grep "w1"`
        if [ "$RESULT" != "" ]; then
            crontab -l | grep -v 'nvram restart'  | crontab -
            rm $NVRAM_RESTART_SCHEDULED
        fi
    fi
fi

RESULT=`cat $WL1_CONSOLEDUMP | grep "cca_stats_watchdog: Bad chanspec"`
TIMESTAMP=$(echo "$RESULT" | tail -n 1 | awk '{print $1}')

# Check if the last timestamp file exists
if [ ! -f "$LAST_TIMESTAMP_FILE" ]; then
    # If not, create it with 0
    echo "0" > "$LAST_TIMESTAMP_FILE"
fi

LAST_PROCESSED_TIMESTAMP=$(cat "$LAST_TIMESTAMP_FILE")

if [ "$RESULT" != "" ] && [ "$LAST_PROCESSED_TIMESTAMP" != "$TIMESTAMP" ]; then
    echo_t "$TIMESTAMP" > $LAST_TIMESTAMP_FILE
    echo_t "RDKB_DHD_DRIVER_BAD_CHANSPEC: cca_stats_watchdog: Bad chanspec"
    echo_t "=========================== wl1 dhd dump output ================================"
    cat $WL1_CONSOLEDUMP
    echo_t "================================================================================"
fi

WL0_STATUS=`wl -i wl0 status | grep "wl driver adapter not found"`
if [ "$WL0_STATUS" != "" ]; then
    echo_t "wl driver adapter not found: Driver went into bad state"
    /lib/rdk/deviceRebootCronscheduler.sh /rdklogs/logs/SelfHeal.txt.0 "sh /rdklogger/backupLogs.sh &"
fi

WL1_STATUS=`wl -i wl1 status | grep "wl driver adapter not found"`
if [ "$WL1_STATUS" != "" ]; then
    echo_t "wl driver adapter not found: Driver went into bad state"
    /lib/rdk/deviceRebootCronscheduler.sh /rdklogs/logs/SelfHeal.txt.0 "sh /rdklogger/backupLogs.sh &"
fi

rm $WL0_CONSOLEDUMP
rm $WL1_CONSOLEDUMP
rm /tmp/wl0_assoclist.txt
rm /tmp/wl1_assoclist.txt
if [ "$Modified_Timestamp_file" != "1" ]; then
    rm -rf $RDKB_DHD_TIMESTAMP_FILE
fi

exit 0

