#! /bin/sh
#Script to print good packet and bad packet of each interface
#every 10 seconds for 3 times

source /etc/log_timestamp.sh

uptime=`cat /proc/uptime | awk '{ print $1 }' | cut -d"." -f1`

#Uptime should be more than 10mins
if [ $uptime -lt 600 ]; then
   exit
fi

LOG_FILE=/rdklogs/logs/WifiConsole.txt
TMP_LOG_FILE=/tmp/good_bad_packet.txt
LOG_FINDER="WIFI_LOG_PACKET_COUNTERS"
count=1
SLEEP_INTERVAL=10s
LOG_MARKER_WL0="WIFI_LOG_BAD_PACKET_ACCUMULATION_WL0"
LOG_MARKER_WL1="WIFI_LOG_BAD_PACKET_ACCUMULATION_WL1"
WL0_ASSOCLIST="wl -i wl0 assoclist"
WL1_ASSOCLIST="wl -i wl1 assoclist"

#wifi ifnames - wl0 wl1 wl0.1 wl1.1
#Note: Do not add any log inside while loop, which will affect the result
echo " " >> $TMP_LOG_FILE
while [ $count -lt 4 ]
do
        echo_t "$LOG_FINDER *** Iteration $count ***" >> $TMP_LOG_FILE
        echo "For wl0" >> $TMP_LOG_FILE
        wl -i wl0 pktcnt >> $TMP_LOG_FILE
        echo "For wl1" >> $TMP_LOG_FILE
        wl -i wl1 pktcnt >> $TMP_LOG_FILE
        count=$(( count+1 ))
        echo "***************************************" >> $TMP_LOG_FILE
        sleep $SLEEP_INTERVAL
done

good_first_wl0=$(tail -n +3 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 1 | cut -d ' ' -f 4)
bad_first_wl0=$(tail -n +3 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 2 | cut -d ' ' -f 4)

good_last_wl0=$(tail -n +19 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 1 | cut -d ' ' -f 4)
bad_last_wl0=$(tail -n +19 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 2 | cut -d ' ' -f 4)

good_first_wl1=$(tail -n +6 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 1 | cut -d ' ' -f 4)
bad_first_wl1=$(tail -n +6 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 2 | cut -d ' ' -f 4)

good_last_wl1=$(tail -n +22 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 1 | cut -d ' ' -f 4)
bad_last_wl1=$(tail -n +22 $TMP_LOG_FILE | head -n 4 | grep Transmit: | cut -d ',' -f 2 | cut -d ' ' -f 4)

wl0_bad_diff=$(( bad_last_wl0-bad_first_wl0 ))
wl0_good_diff=$(( good_last_wl0-good_first_wl0 ))
if [ $wl0_bad_diff -gt $wl0_good_diff ]
then
        #check the assoclist
        retval_wl0=$($WL0_ASSOCLIST)
        #Only set the marker if there is no device in the wl0 assoclist and the bad packet count is more than good packet
        if [ -z "$retval_wl0" ]
        then
                echo_t "$LOG_MARKER_WL0 IfName:wl0 BadPacket:[1st:$bad_first_wl0 3rd:$bad_last_wl0 Diff:$wl0_bad_diff] GoodPacket:[1st:$good_first_wl0 3rd:$good_last_wl0 Diff:$wl0_good_diff]" >> $TMP_LOG_FILE
        fi

fi

wl1_bad_diff=$(( bad_last_wl1-bad_first_wl1 ))
wl1_good_diff=$(( good_last_wl1-good_first_wl1 ))
if [ $wl1_bad_diff -gt $wl1_good_diff ]
then
        #check the assoclist
        retval_wl1=$($WL1_ASSOCLIST)
        #Only set the marker if there is no device in the wl1 assoclist and the bad packet count is more than good packet
        if [ -z "$retval_wl1" ]
        then
                echo_t "$LOG_MARKER_WL1 IfName:wl1 BadPacket:[1st:$bad_first_wl1 3rd:$bad_last_wl1 Diff:$wl1_bad_diff] GoodPacket:[1st:$good_first_wl1 3rd:$good_last_wl1 Diff:$wl1_good_diff]" >> $TMP_LOG_FILE
        fi
fi

#Copy the temp file contents to log file
cat $TMP_LOG_FILE >> $LOG_FILE

sleep 1s

#Remove the temporary file
rm $TMP_LOG_FILE

