#!/bin/sh

##################################################################################
# If not stated otherwise in this file or this component's Licenses.txt file the
# following copyright and licenses apply:

#  Copyright 2019 RDK Management

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################
UTOPIA_PATH="/etc/utopia/service.d"

source $UTOPIA_PATH/log_env_var.sh
source /usr/ccsp/tad/corrective_action.sh
source /etc/log_timestamp.sh

exec 3>&1 4>&2 >>$SELFHEALFILE 2>&1

MONITOR_LOG_ENABLE="true"

while [ $MONITOR_LOG_ENABLE = "true" ]
do

#sleep for 5mins
sleep 300


TMPFS_THRESHOLD=95
TMPFS_CUR_USAGE=`df /tmp | tail -1 | awk '{print $(NF-1)}' | cut -d"%" -f1`

VAR_THRESHOLD=95
VAR_CUR_USAGE=`df /var | tail -1 | awk '{print $(NF-1)}' | cut -d"%" -f1`

VAR_VOLATILE_THRESHOLD=95
VAR_VOLATILE_CUR_USAGE=`df /var/volatile | tail -1 | awk '{print $(NF-1)}' | cut -d"%" -f1`

var_tmpfs_reach=0
tmp_fs_reach=0
var_volatile_tmpfs_reach=0

reason=""

if [ $TMPFS_CUR_USAGE -ge $TMPFS_THRESHOLD ]
then
    echo_t "TMPFS_USAGE:$TMPFS_CUR_USAGE"

    echo_t "================================================================================"
    echo_t "TMPFS_FILELIST: Systems TempFS file list is"
    ls -al /tmp/
    echo_t "================================================================================"
 
    reason="TMPFS"
    tmp_fs_reach=1
fi

#Reset the dibbler log file once threshold is reached, except for ashlene/xle sky platforms
if [ "$BOX_TYPE" != "SE501" ] && [ "$BOX_TYPE" != "WNXL11BWL" ]; then

    VAR_DIBBLER_THRESHOLD=1024
    VAR_DIBBLER_CUR_USAGE=`du /var/lib/dibbler/ | awk -v sum=0 '{print sum+=$1}' | tail -1`

    if [ $VAR_DIBBLER_CUR_USAGE -ge $VAR_DIBBLER_THRESHOLD ]
    then
       cat /dev/null > /var/lib/dibbler/client.sh-log
       VAR_CUR_USAGE=`df /var | tail -1 | awk '{print $(NF-1)}' | cut -d"%" -f1`
    fi
fi

if [ $VAR_CUR_USAGE -ge $VAR_THRESHOLD ]
then
    echo_t "VAR_TMPFS_USAGE:$VAR_CUR_USAGE"

    echo_t "================================================================================"
    echo_t "VAR_TMPFS_FILELIST: Systems VAR TempFS file list is"
    ls -al /var/
    ls -al /var/log/
    echo_t "================================================================================"
   
    if [ "$reason" != "" ]; then 
       reason=${reason}"_VAR_TMPFS"
    else
       reason="VAR_TMPFS"
    fi

    var_tmpfs_reach=1

fi

if [ $VAR_VOLATILE_CUR_USAGE -ge $VAR_VOLATILE_THRESHOLD ]
then
    echo_t "VAR_VOLATILE_TMPFS_USAGE:$VAR_VOLATILE_CUR_USAGE"

    echo_t "================================================================================"
    echo_t "VAR_VOLATILE_TMPFS_FILELIST: Systems VAR Volatile TempFS file list is"
    ls -al /var/volatile
    echo_t "================================================================================"

    if [ "$reason" != "" ]; then
        reason=${reason}"_VAR_VOLATILE"
    else
       reason="VAR_VOLATILE"
    fi

    var_volatile_tmpfs_reach=1

fi

#if anyone of the directory reaches 95% then we may need to reboot the device
if [ "$var_tmpfs_reach" == "1" ] || [ "$tmp_fs_reach" == "1" ] || [ "$var_volatile_tmpfs_reach" == "1" ]; then	
    reason=${reason}"_FULL"
    rebootCount=1
    echo_t "[RDKB_SELFHEAL] : Device reboot due to $reason"
    rebootNeeded RM "" $reason $rebootCount
fi

done
