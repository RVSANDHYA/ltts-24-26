#!/bin/sh

##################################################################################
# If not stated otherwise in this file or this component's Licenses.txt file the
# following copyright and licenses apply:

#  Copyright 2018 RDK Management

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################
source /etc/utopia/service.d/log_capture_path.sh

#Configure LAN bridges for XB6 using vlan_util (which calls vlan_hal)
VLAN_UTIL="vlan_util"
QWCFG_TEST="qwcfg_test"
QCSAPI_PCIE="qcsapi_pcie"
IP="ip"
IFCONFIG="ifconfig"
NCPU_EXEC="ncpu_exec"
SYSEVENT="sysevent"
KILLALL="killall"
LOCKFILE=/var/tmp/vlan_util.pid

#Initial state variable values (will get reset later)
IF_LIST=""
CURRENT_IF_LIST=""
BRIDGE_MODE=0

#Prefix for wifi interfaces
WIFI_PREFIX="ath"
#Prefix for external switch ports
SW_PREFIX="eth_"

#GRE tunnel information
DEFAULT_GRE_TUNNEL="gretap0"
#Dummy MAC address to assign to GRE tunnels so we can add them to bridges
DUMMY_MAC="02:03:DE:AD:BE:EF"

#mesh ethernet backhaul
IF_MESHEB="brebhaul"
MESHEB_IP="169.254.85.1 netmask 255.255.255.0"
EBHAUL_VLAN_ID="123"
    
wait_for_gre_ready(){
    while [ "`$SYSEVENT get if_${LAN_GRE_TUNNEL}-status`" != "ready" ] ; do
        echo_t "Waiting for $LAN_GRE_TUNNEL to be ready..."
        sleep 1
    done
}

wait_for_erouter0_ready(){
    while [ "`$SYSEVENT get wan-status`" != "started" ] ; do
        echo_t "Waiting for erouter0 to be ready..."
        sleep 1
    done
}

#Do any gretap setup needed here, or call events, whatever
#Also returns LAN_GRE_TUNNEL so we know which to use for the base tunnel
#Syntax: setup_gretap [start|stop] bridge_name group_number
setup_gretap(){
    GRE_MODE="$1"
    LAN="$2"
    LAN_VLAN="$3"
    
    #For now, both use the same tunnel
    LAN_GRE_TUNNEL="$DEFAULT_GRE_TUNNEL"
    
    if [ "$GRE_MODE" = "start" ]
    then
        #Wait until gre got created
        wait_for_gre_ready
        vconfig add $LAN_GRE_TUNNEL $LAN_VLAN
        ifconfig $LAN_GRE_TUNNEL up
        ifconfig ${LAN_GRE_TUNNEL}.$LAN_VLAN up
    else
        vconfig rem ${LAN_GRE_TUNNEL}.${LAN_VLAN}
    fi
}

#Gets a space-separated list of interfaces currently in a group
#Returns the list in CURRENT_IF_LIST
get_current_if_list() {
    CURRENT_IF_NAMES=`$VLAN_UTIL list_interfaces $BRIDGE_NAME`
    CMD_STATUS=$?
    CURRENT_IF_LIST=""
    
    if [ $CMD_STATUS -ne 0 ]
    then
        echo_t "$0 error: couldn't get interface list for group $BRIDGE_VLAN"
    else
        for LINE in $CURRENT_IF_NAMES; do
            if [ "$CURRENT_IF_LIST" = "" ]
            then
                CURRENT_IF_LIST="$LINE"
            else
                CURRENT_IF_LIST="$CURRENT_IF_LIST $LINE"
            fi
        done
    fi
    echo -e "Group $BRIDGE_NAME vlan $BRIDGE_VLAN now includes:\t$CURRENT_IF_LIST"
}

#Calls dmcli to check whether switch port 2 should be enabled in instance 1 (private LAN) or 2 (XFinity Home) networks
#If the setting is not yet available, waits for 1 second and tries again, for up to 30 seconds
#Returns "true" in variable $isport2enable if port 2 should be enabled in this group
check_port_2(){
    COUNTER=0
    MAXTRIES=30
    PORT_ERR="INIT"

    #Only supports instance 1 or 2 currently
    case $INSTANCE in
        #XFinity Private LAN
        1)
            PORT_CMD="dmcli eRT getv Device.Bridging.Bridge.1.Port.8.Enable"
        ;;
        #XFinity Home
        2)
            PORT_CMD="dmcli eRT getv Device.Bridging.Bridge.2.Port.2.Enable"        
        ;;    
    esac
        
    while [ "$PORT_ERR" != "" -a $COUNTER -lt $MAXTRIES ] ; do
        PORT_CHECK=`$PORT_CMD`
        PORT_ERR=`echo "$PORT_CHECK"|grep "Can't find"`
        
        if [ "$PORT_ERR" != "" ] ; then
            echo_t "Waiting for dmcli port 2 configuration to be available..."
            COUNTER=`expr $COUNTER + 1`
            isport2enable="false"
            sleep 1
        else
            isport2enable=`echo "$PORT_CHECK" | grep value | cut -f3 -d : | cut -f2 -d " "`
        fi
        
    done

    if [ $COUNTER -eq $MAXTRIES ] ; then
        echo_t "$0 error: dmcli configuration for instance $INSTANCE port 2 timed out!"
        isport2enable="false"
    fi
}


check_xfinity_wifi(){
       isXfinityWiFiEnable=`psmcli get dmsb.hotspot.enable`
}

#Returns a space-separated list of interfaces that should be in this group in the current operating mode
#Returns the list in IF_LIST
get_expected_if_list() {
    
    case $INSTANCE in
        
        #XFinity Private LAN
        1)
            check_port_2
            
            if [ "$BRIDGE_MODE" -gt 0 ]
            then
                #Interface list for bridged mode
                if [ "$isport2enable" = "true" ]
                then
                    #Switch port 2 connected to XFinity Private LAN
                    IF_LIST="eth_1 eth_0 nmoca0 l${CMDIAG_IF} lbr0"
                else
                    IF_LIST="eth_1 nmoca0 l${CMDIAG_IF} lbr0"
                    #Switch port 2 connected to XFinity Home
                fi
            else
                #Interface list for routed mode
                if [ "$isport2enable" = "true" ]
                then
                    #Switch port 2 connected to XFinity Private LAN
                    IF_LIST="eth_1 eth_0 nmoca0 ath0 ath1"
                else
                    #Switch port 2 connected to XFinity Home
                    IF_LIST="eth_1 nmoca0 ath0 ath1"
                fi
            fi

            syscfg set lan_ethernet_physical_ifnames "$IF_LIST"
        ;;
        
        #XFinity Home
        2)
            check_port_2
            
            if [ "$isport2enable" = "true" ]
            then
                #Switch port 2 connected to XFinity Home
                IF_LIST="eth_0 nmoca0.${BRIDGE_VLAN} ath2 ath3"
            else
                #Switch port 2 connected to XFinity Private LAN
                IF_LIST="nmoca0.${BRIDGE_VLAN} ath2 ath3"
            fi
        ;;
        
        #XFinity Hostspot 2.4 GHz
        3)
	check_xfinity_wifi
	if [ $isXfinityWiFiEnable -eq 1 ]
	then
            IF_LIST="nmoca0.${BRIDGE_VLAN} ${DEFAULT_GRE_TUNNEL}.${BRIDGE_VLAN} ath4"
	else
         echo_t "Xfinity WiFi is not enabled"
        fi
        ;;
        
        #XFinity Hotspot 5 GHz
        4)
	check_xfinity_wifi
	if [ $isXfinityWiFiEnable -eq 1 ]
	then
            IF_LIST="nmoca0.${BRIDGE_VLAN} ${DEFAULT_GRE_TUNNEL}.${BRIDGE_VLAN} ath5"
	else
         echo_t "Xfinity WiFi is not enabled"
        fi
        ;;
        
        #XFinity IoT network
        6)
            IF_LIST="ath6 ath7 ath10 ath11"
        ;;
        
    esac
    
    echo -e "Group $BRIDGE_NAME vlan $BRIDGE_VLAN should include:\t$IF_LIST"
}

remove_from_group() {
    IF_TO_REMOVE="$1"
    
    echo_t "Removing $IF_TO_REMOVE from group $BRIDGE_NAME"
    
    #Handle the case for wifi vlans
    if [ "`echo \"$IF_TO_REMOVE\"|egrep -e \"ath*\"`" != "" ]
    then
        setup_qtn_local stop $IF_TO_REMOVE
        #setup_qtn stop $IF_TO_REMOVE &
    elif [ "`echo \"$IF_TO_REMOVE\"|egrep -e \"host*\"`" != "" ]
    then
        setup_qtn_local stop $IF_TO_REMOVE
        #setup_qtn stop $IF_TO_REMOVE &
        #Handle the case for GRE tunnels
    elif [ "`echo \"$IF_TO_REMOVE\"|egrep -e \"${DEFAULT_GRE_TUNNEL}*\"`" != "" ]
    then
        setup_gretap stop $BRIDGE_NAME $BRIDGE_VLAN
    fi
    
    $VLAN_UTIL del_interface $BRIDGE_NAME $IF_TO_REMOVE
}

remove_from_all_groups(){
    IF_TO_REMOVE="$1"
    
    $VLAN_UTIL show|grep "Group:"|awk '{print $2}'|while read GROUP_NAME
    do
        $VLAN_UTIL list_interfaces $GROUP_NAME|while read IF_FOUND
        do
            if [ "$IF_TO_REMOVE" = "$IF_FOUND" -a "$GROUP_NAME" != "$BRIDGE_NAME" ]
            then
                echo_t "$IF_TO_REMOVE already belongs to $GROUP_NAME, removing"
                $VLAN_UTIL del_interface $GROUP_NAME $IF_FOUND
                break
            fi
        done
    done
}

add_to_group() {
    IF_TO_ADD="$1"
    VLAN_TO_ADD=""
    
    #If this interface is already in another group, remove it from there
    remove_from_all_groups $IF_TO_ADD $VLAN_TO_ADD
    
    #Check if the interface desired is a vlan interface
    echo "$IF_TO_ADD"|egrep -e ".*\..*"
    if [ $? -eq 0 ]
    then
        VLAN_TO_ADD="`echo \"$IF_TO_ADD\"|cut -d \".\" -f 2`"
        BASE_IF="`echo \"$IF_TO_ADD\"|cut -d \".\" -f 1`"
        IF_TO_ADD="$BASE_IF"
        echo_t "Adding ${IF_TO_ADD}.${VLAN_TO_ADD} to group $BRIDGE_NAME"
    else
        echo_t "Adding $IF_TO_ADD to group $BRIDGE_NAME"
    fi
    
    #Handle the case for wifi vlans
    if [ "`echo \"$IF_TO_ADD\"|egrep -e \"ath*\"`" != "" ]
    then
        setup_qtn_local start $IF_TO_ADD
        #setup_qtn start $IF_TO_ADD &
    elif [ "`echo \"$IF_TO_ADD\"|egrep -e \"host*\"`" != "" ]
    then
        setup_qtn_local start $IF_TO_ADD
        #setup_qtn start $IF_TO_ADD &
        #Handle the case for GRE tunnels
    elif [ "`echo \"$IF_TO_ADD\"|egrep -e \"${DEFAULT_GRE_TUNNEL}*\"`" != "" ]
    then
	check_xfinity_wifi
	if [ $isXfinityWiFiEnable -eq 1 ]
	then
		echo_t "Xfinity wifi enabled"
		wait_for_erouter0_ready
        	sh /etc/utopia/service.d/service_multinet/handle_gre.sh create $INSTANCE $DEFAULT_GRE_TUNNEL
        	setup_gretap start $BRIDGE_NAME $BRIDGE_VLAN
	else
          echo_t "Xfinity WiFi is not enabled"
        fi
    fi
    
    $VLAN_UTIL add_interface $BRIDGE_NAME $IF_TO_ADD $VLAN_TO_ADD
}

#This function will create the group if it doesn't already exist,
#remove interfaces that shouldn't be connected, and add any
#interfaces that should be connected to this group.
#Takes a parameter "true" or "false" which determines whether we are
#tearing down this group. In that case, remove all ports from the bridge.
sync_group_settings() {
    TEARDOWN="$1"
    NEED_SW_UPDATE="false"
    NEED_WIFI_UPDATE="false"

    echo_t "VLAN SKY : sync_group_settings TEARDOWN:$TEARDOWN" 

    [ "$TEARDOWN" != "true" ] && $SYSEVENT set multinet_${INSTANCE}-localready 1

    #Check if bridge exists and if ID is correct.  If not, delete and re-create.
#    CURRENT_VLAN=`$VLAN_UTIL show_vlan $BRIDGE_NAME`
#    CMD_STATUS=$?

#	echo_t "Group RAISE_EVENTS:$CURRENT_VLAN BRIDGE_VLAN:$BRIDGE_VLAN CMD_STATUS:$CMD_STATUS"
    
#    if [ $CMD_STATUS -ne 0 -o "$CURRENT_VLAN" != "$BRIDGE_VLAN" ]
#    then
#        echo_t "Group $BRIDGE_NAME doesn't exist or has wrong VLAN ID, re-creating"
        #We need to destroy and re-create bridge
#        $VLAN_UTIL del_group $BRIDGE_NAME
#        $VLAN_UTIL add_group $BRIDGE_NAME $BRIDGE_VLAN
#         if [ $BRIDGE_NAME = "brlan0" ]; then
#          mac=$WAN_MAC
#          echo_t "############## CM  Mac Address is :$mac###############"          
#          last=`echo $mac | cut -f6 -d ':'`
#          last=`echo $(( 16#$last + 3 ))`          
#          newmac="${mac:0:15}`printf '%x\n' $last`"          	
#          ifconfig brlan0 hw ether $newmac up  
#          echo_t "################SETTING BRLAN0 mac to:$newmac###########"	
#        fi
#    fi

#    echo_t "Group after $BRIDGE_NAME configuration RAISE_EVENTS:$RAISE_EVENTS" 

    [ "$TEARDOWN" != "true" ] && $SYSEVENT set multinet_${INSTANCE}-status partial

    #Get the list of which interfaces should be added to this group
#    if [ "$TEARDOWN" = "true" ] ; then
#        IF_LIST=""
#    else
#    echo_t "Group getting expected iface list" 
#        get_expected_if_list
#    fi

     #Remove any interfaces that don't belong in this group
#    echo_t "Group remove any iface that don't belong in this group" 
#    get_current_if_list
#    echo_t "Group CURRENT_IF_LIST:$CURRENT_IF_LIST"
#    for EXISTING_IF in $CURRENT_IF_LIST; do
#        IF_BELONGS=0
#        for EXPECTED_IF in $IF_LIST; do
#            if [ "$EXISTING_IF" = "$EXPECTED_IF" ]
#            then
#                IF_BELONGS=1
#            fi
#        done
        
#        if [ $IF_BELONGS -eq 0 ]
#        then
#            echo_t "Group remove $EXISTING_IF" 
#            remove_from_group $EXISTING_IF
#	    if [ "`echo \"$EXISTING_IF\"|grep \"$WIFI_PREFIX\"`" != "" ] ; then
#                NEED_WIFI_UPDATE="true"
#	    elif [ "`echo \"$EXISTING_IF\"|grep \"$SW_PREFIX\"`" != "" ] ; then
#                NEED_SW_UPDATE="true"
#            fi 
#        fi
#    done
    
    #Now add whatever is missing to this group
#    echo_t "Group add whatever is missing to this group"
#    get_current_if_list
#    echo_t "Group IF_LIST:$IF_LIST"
#    for NEEDED_IF in $IF_LIST; do
#        IF_FOUND=0
#        for EXISTING_IF in $CURRENT_IF_LIST; do
#            if [ "$EXISTING_IF" = "$NEEDED_IF" ]
#            then
#                IF_FOUND=1
#            fi
#        done
        
#        if [ $IF_FOUND -ne 1 ]
#        then
#            echo_t "Group add $NEEDED_IF"
#            add_to_group $NEEDED_IF
#	    if [ "`echo \"$NEEDED_IF\"|grep \"$WIFI_PREFIX\"`" != "" ] ; then
#                NEED_WIFI_UPDATE="true"
#	    elif [ "`echo \"$NEEDED_IF\"|grep \"$SW_PREFIX\"`" != "" ] ; then
#                NEED_SW_UPDATE="true"
#            fi 
#        fi
#    done

    #In bridge mode if we reconfigure the ports we need to flush DOCSIS CPE table
#     if [ "$BRIDGE_MODE" -gt 0 ]
#     then
#         ncpu_exec -e "(echo \"LearnFrom=CPE_DYNAMIC\" > /proc/net/dbrctl/delalt)"
#     fi

#    if [ "$NEED_WIFI_UPDATE" = "true" ]
#    then
#        echo_t "calling gw_lan_refresh to update wifi setting"
#        gw_lan_refresh wifi
#    fi
#    if [ "$NEED_SW_UPDATE" = "true" ]
#    then
#        echo_t "calling gw_lan_refresh to update external switch setting"
#        gw_lan_refresh switch
#    fi

    if [ "$TEARDOWN" != "true" ]; then
        $SYSEVENT set multinet_${INSTANCE}-status ready
#        ifconfig $BRIDGE_NAME up
    fi

    echo_t "VLAN SKY : Group sync exit" 
}

#Remove any interfaces from this group
remove_all_from_group() {
    sync_group_settings true
}

print_syntax(){
    echo "Syntax: $0 [multinet-up|multinet-down|multinet-syncMembers] instance"
    echo -e "\t$0 [iot-up|iot-down]"
}

mesh_ethbahaul_conf() {
    
    #Define interfaces and vlans required for Ethernet Backhaul
    eb_enable=`syscfg get eb_enable`
    
    if [ "$eb_enable" != "true" ];then
        echo_t "Ignoring POD eth backhaul enable request due to eb_enable flag is false"
        exit 1
    fi

    ethWanMode=`syscfg get eth_wan_enabled`
    
    if [ "$ethWanMode" = "true" ];then
        EBHAUL_IFACES="eth0 eth1 eth2"
    else
        EBHAUL_IFACES="eth0 eth1 eth2 eth3"
    fi
}

#Sets up ethernet backhaul for Pods to work in ethernet mode
mesh_ethbhaul_setup() {

   mesh_ethbahaul_conf
   
   brctl addbr $IF_MESHEB
   ifconfig $IF_MESHEB $MESHEB_IP up
   
   configured=false
   
   for i in $EBHAUL_IFACES;do
       ip link add link $i name $i.$EBHAUL_VLAN_ID type vlan id $EBHAUL_VLAN_ID
       ip link set $i.$EBHAUL_VLAN_ID master $IF_MESHEB
       ip link set $i.$EBHAUL_VLAN_ID up 
   done

   configured=true

   echo_t "POD Ethernet Backhaul VLANs are successfully created"
}

#Remove ethernet backhaul related vlans
remove_pod_ethbhaul() {
    ethWanMode=`syscfg get eth_wan_enabled`

    if [ "$ethWanMode" = "true" ];then
        EBHAUL_IFACES="eth0 eth1 eth2"
    else
        EBHAUL_IFACES="eth0 eth1 eth2 eth3"
    fi

    for i in $EBHAUL_IFACES;do
        ip link set $i.$EBHAUL_VLAN_ID nomaster
        ip link delete $i.$EBHAUL_VLAN_ID
    done

    echo_t "POD Ethernet Backhaul VLANs are successfully removed"
}

#Script execution begins here
while [ -e ${LOCKFILE} ] ; do
    #See if process is still running
    kill -0 `cat ${LOCKFILE}`
    if [ $? -ne 0 ]
    then
        break
    fi
    echo_t "VLAN SKY : Waiting for parallel instance of $0 to finish..."
    sleep 1
done

#make sure the lockfile is removed when we exit and then claim it
trap "rm -f ${LOCKFILE}; exit" INT TERM EXIT
echo $$ > ${LOCKFILE}


BRIDGE_MODE=`syscfg get bridge_mode`

#Get event
EVENT="$1"

echo_t "VLAN SKY : Received Event:$EVENT BRIDGE_MODE:$BRIDGE_MODE"

if [ "$EVENT" = "multinet-up" ]
then
    MODE="up"
elif [ "$EVENT" = "multinet-start" ]
then
    MODE="start"
elif [ "$EVENT" = "lnf-setup" ]
then
    MODE="lnf-start"
elif [ "$EVENT" = "lnf-down" ]
then
    MODE="lnf-stop"
elif [ "$EVENT" = "meshbhaul-setup" ]
then
    MODE="meshbhaul-start"
elif [ "$EVENT" = "meshethbhaul-up" ]
then
    MODE="meshethbhaul-start"
elif [ "$EVENT" = "meshethbhaul-down" ]
then
    MODE="meshethbhaul-stop"
elif [ "$EVENT" = "multinet-down" ]
then
    MODE="stop"
elif [ "$EVENT" = "multinet-stop" ]
then
    MODE="stop"
elif [ "$EVENT" = "multinet-syncMembers" ]
then
    MODE="syncmembers"
else
    echo_t "$0 error: Unknown event: $1"
    print_syntax
    rm -f ${LOCKFILE}
    exit 1
fi

#Instance maps to brlan0, brlan1, etc.
INSTANCE="$2"

echo_t "VLAN SKY : Received INSTANCE:$INSTANCE"

#Get lan bridge name from instance number
BRIDGE_NAME=""
BRIDGE_VLAN=0
case $INSTANCE in
    0)
        #Bridge
    ;;

    1)
        #Private LAN
        BRIDGE_NAME="brlan0"
        BRIDGE_VLAN=100
    ;;
    2)
        #Home LAN
        BRIDGE_NAME="brlan1"
        BRIDGE_VLAN=101
    ;;
    3)
        #Public wifi 2.4GHz
        BRIDGE_NAME="brlan2"
        BRIDGE_VLAN=102
    ;;
    4)
        #Public wifi 5GHz
        BRIDGE_NAME="brlan3"
        BRIDGE_VLAN=103
    ;;
    6)
        BRIDGE_NAME="br106"
        BRIDGE_VLAN=106
    ;;
    10)
        BRIDGE_NAME="br403"
        BRIDGE_VLAN=1060
    ;;
    65)
        BRIDGE_NAME="br65"
        BRIDGE_VLAN=65
    ;;
    66)
        BRIDGE_NAME="br66"
        BRIDGE_VLAN=66
    ;;
    *)
        #Unknown / unsupported instance number
        echo_t "$0 error: Unknown instance $INSTANCE"
        print_syntax
        rm -f ${LOCKFILE}
        exit 1
    ;;
esac

echo_t "VLAN SKY : BRIDGE_NAME:$BRIDGE_NAME BRIDGE_VLAN:$BRIDGE_VLAN"


#Set the interface name
$SYSEVENT set multinet_${INSTANCE}-name $BRIDGE_NAME
$SYSEVENT set multinet_${INSTANCE}-vid $BRIDGE_VLAN

echo_t "VLAN SKY : Mode is set to $MODE"

if [ "$MODE" = "up" ]
then  
    remove_all_from_group
    #Sync the group interfaces and raise status events
    echo_t "VLAN SKY : calling sync_group_settings"
    sync_group_settings
    if [ $BRIDGE_NAME = "brlan0" ]
    then
#        echo_t "DISABLE MULTICAST SNOOPING FOR $BRIDGE_NAME"
#        echo 0 >  /sys/devices/virtual/net/$BRIDGE_NAME/bridge/multicast_snooping
        echo_t "Enabling ip forwarding"
        echo 1 > /proc/sys/net/ipv4/ip_forward
    fi

elif [ $MODE = "start" ]
then
    #Sync the group interfaces and raise status events
    sync_group_settings
 
    #Restart the firewall after the network is set up
    echo_t "VLAN SKY : Triggering RDKB_FIREWALL_RESTART from mode=start"
    $SYSEVENT set firewall-restart

elif [ $MODE = "lnf-start" ]
then
    echo_t "VLAN SKY : lnf is not required for sky device!"

elif [ $MODE = "lnf-stop" ]
then
    echo_t "VLAN SKY : lnf is not required for sky device!"

elif [ $MODE = "meshbhaul-start" ]
then
    #Sync the group interfaces and raise status events
    sync_group_settings

#    ifconfig $BRIDGE_NAME 192.168.245.254
    #Restart the firewall after setting up LnF
    echo_t "VLAN SKY : Triggering RDKB_FIREWALL_RESTART from mode=MeshBhaulstart"
    $SYSEVENT set firewall-restart

elif [ $MODE = "meshethbhaul-start" ]
then
    #config ethernet backhaul vlan
    mesh_ethbhaul_setup

elif [ $MODE = "meshethbhaul-stop" ]
then
    #delete ethernet backhaul vlahbhaul-start"
    remove_pod_ethbhaul

elif [ "$MODE" = "stop" ]
then
    #Indicate LAN is stopping
    $SYSEVENT set multinet_${INSTANCE}-status stopping
    remove_all_from_group
    #Send event that LAN is stopped
    $SYSEVENT set multinet_${INSTANCE}-status stopped

elif [ "$MODE" = "syncmembers" ]
then
    #Sync the group interfaces and raise status events
    sync_group_settings

elif [ "$MODE" = "restart" ]
then
    #Indicate LAN is restarting
    $SYSEVENT set multinet_${INSTANCE}-status restarting
    remove_all_from_group
    #Sync the group interfaces and raise status events
    sync_group_settings
    #Restart the firewall after the network is set up
    echo_t "VLAN SKY : Triggering RDKB_FIREWALL_RESTART from mode=restart"
    $SYSEVENT set firewall-restart

else
    echo "Syntax: $0 [start | stop | restart]"
    rm -f ${LOCKFILE}
    exit 1
fi


echo_t "VLAN SKY : End of shell script"

#Script finished, remove lock file
rm -f ${LOCKFILE}
