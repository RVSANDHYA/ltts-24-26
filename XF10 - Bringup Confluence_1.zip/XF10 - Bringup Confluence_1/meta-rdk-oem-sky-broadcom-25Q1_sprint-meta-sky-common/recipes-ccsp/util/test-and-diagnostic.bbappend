FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

DEPENDS_append = " utopia"

SRC_URI += "file://dhd_trap_reboot_enable.patch"

CFLAGS_append = " \
    -I=${includedir}/utctx \
    -I=${includedir}/utapi \
    "

do_install_append() {
    ln -sf /usr/bin/Sub64 ${D}/usr/ccsp/Sub64
    install -d ${D}/usr/sbin
    install -m 644 ${S}/config/TestAndDiagnostic_arm.XML ${D}${exec_prefix}/ccsp/tad/TestAndDiagnostic.XML
    install -m 755 ${S}/scripts/*.sh ${D}${exec_prefix}/ccsp/tad/
    install -m 0755 ${S}/scripts/ping_peer ${D}${sbindir}/ping_peer
    install -m 0755 ${S}/scripts/arping_peer ${D}${sbindir}/arping_peer
    ## causing compilation issue,using with -f option
    rm -f ${D}/usr/bin/Selfhealutil
	
    ## Changes for new rootfs
    install -d ${D}/fss/gw/usr/ccsp/tad
    ln -sf /usr/ccsp/tad/check_memory_health.sh ${D}/fss/gw/usr/ccsp/tad/check_memory_health.sh
    ln -sf /usr/ccsp/tad/corrective_action.sh ${D}/fss/gw/usr/ccsp/tad/corrective_action.sh
    ln -sf /usr/ccsp/tad/getSsidNames.sh ${D}/fss/gw/usr/ccsp/tad/getSsidNames.sh
    ln -sf /usr/ccsp/tad/log_mem_cpu_info.sh ${D}/fss/gw/usr/ccsp/tad/log_mem_cpu_info.sh
    ln -sf /usr/ccsp/tad/monitor_zombies.sh ${D}/fss/gw/usr/ccsp/tad/monitor_zombies.sh
    ln -sf /usr/ccsp/tad/resource_monitor.sh ${D}/fss/gw/usr/ccsp/tad/resource_monitor.sh
    ln -sf /usr/ccsp/tad/self_heal_connectivity_test.sh ${D}/fss/gw/usr/ccsp/tad/self_heal_connectivity_test.sh
    ln -sf /usr/ccsp/tad/selfheal_bootup.sh ${D}/fss/gw/usr/ccsp/tad/selfheal_bootup.sh
    ln -sf /usr/ccsp/tad/selfheal_reset_counts.sh ${D}/fss/gw/usr/ccsp/tad/selfheal_reset_counts.sh
    ln -sf /usr/ccsp/tad/task_health_monitor.sh ${D}/fss/gw/usr/ccsp/tad/task_health_monitor.sh
    ln -sf /usr/ccsp/tad/uptime.sh ${D}/fss/gw/usr/ccsp/tad/uptime.sh
    ln -sf /usr/ccsp/tad/rxtx_cur.sh ${D}/fss/gw/usr/ccsp/tad/rxtx_cur.sh
    ln -sf /usr/ccsp/tad/rxtx_lan.sh ${D}/fss/gw/usr/ccsp/tad/rxtx_lan.sh
    ln -sf /usr/ccsp/tad/rxtx_res.sh ${D}/fss/gw/usr/ccsp/tad/rxtx_res.sh
    ln -sf /usr/ccsp/tad/rxtx_sta.sh ${D}/fss/gw/usr/ccsp/tad/rxtx_sta.sh
    ln -sf /usr/bin/Sub64 ${D}/fss/gw/usr/ccsp/Sub64
}

FILES_${PN}-ccsp += " \
                    ${prefix}/ccsp/tad/* \
                    /fss/gw/usr/ccsp/tad/* \
                    "


