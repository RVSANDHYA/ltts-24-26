FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"
# Adding flag for Vlan Manager HAL 
DEPENDS_append = " json-hal-lib "
CFLAGS_append  = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '-DVLAN_MANAGER_HAL_ENABLED', '', d)}"

EXTRA_OECONF_append  ?= "${@bb.utils.contains('DISTRO_FEATURES', 'kirkstone', ' ', ' --with-ccsp-platform=bcm --with-ccsp-arch=arm ', d)}"

LDFLAGS_append = " \
    -ljson_hal_client \
    -ljson-c \
"
