FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

EXTRA_OECONF_remove = " --enable-notify"

SRC_URI += "${RDKB_CCSP_ROOT_GIT}/CcspPsm/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};destsuffix=git/device;name=deviceCcspPsm"
SRC_URI += "file://bbhm_write_validity_check.patch"

SRCREV_deviceCcspPsm = "${AUTOREV}"
SRCREV_FORMAT = "CcspPsm_deviceCcspPsm"

DEPENDS +="libxml2"
CFLAGS_append = " \
    -I${STAGING_INCDIR}/libxml2 \
 "

LDFLAGS_append = " \
    -lxml2 \
"

do_compile_prepend () {
    cp ${S}/device/psm-hal/psm_hal_apis.c ${S}/source/Ssp/psm_hal_apis.c
}

do_install_append () {

    # Config files and scripts

    install -d ${D}/usr/ccsp/config
    install -m 644 ${S}/device/config/bbhm_def_cfg_hub4.xml ${D}/usr/ccsp/config/bbhm_def_cfg.xml
}
