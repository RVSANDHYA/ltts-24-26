#! /bin/sh

source /etc/device.properties

HTTP_ADMIN_PORT=`syscfg get http_admin_port`
HTTP_PORT=`syscfg get mgmt_wan_httpport`
HTTP_PORT_ERT=`syscfg get mgmt_wan_httpport_ert`
HTTPS_PORT=`syscfg get mgmt_wan_httpsport`
BRIDGE_MODE=`syscfg get bridge_mode`
LAN_IPADDR=`syscfg get lan_ipaddr`
LOCAL_DOMAIN=`syscfg get SecureWebUI_LocalFqdn`
SECUREWEBUI_ENABLE=`syscfg get SecureWebUI_Enable`
NAMESERVERENCHK=`syscfg get dhcp_nameserver_enabled`
LAN_IPADDR_V6=`sysevent get lan_ipaddr_v6`

if ([ "$BOX_TYPE" == "HUB4" ] || [ "$BOX_TYPE" == "SR300" ] || [ "$BOX_TYPE" == "SR213" ]); then
    # Grab the locale based on the region code if we don't have the override flag
    LOCALE_OVERRIDE_FILE=/nvram/locale-override
    LOCALE_CONF=/tmp/locale.conf
    if [ -f "$LOCALE_OVERRIDE_FILE" ]; then
       LOCALE=`cat $LOCALE_OVERRIDE_FILE`
    else
       # set the locale from the region code
       COUNTRY=`grep "REGION" /tmp/serial.txt | cut -d"=" -f2 | xargs`
       if [ "$COUNTRY" == "IT" ]; then
               LOCALE="it_IT.utf8"
       else
               LOCALE="en_GB.utf8"
       fi
    fi
    # Now set the system locale before starting the UI
    localectl set-locale LANG=$LOCALE
    sed -i'' "s/LANG=en_GB.utf8/LANG=$LOCALE/g" $LOCALE_CONF
    export LANG=$LOCALE
fi

if [ "$BRIDGE_MODE" != "0" ]; then
    INTERFACE="lan0"
else
    INTERFACE="brlan0"
fi

if ([ "$BOX_TYPE" == "HUB4" ] || [ "$BOX_TYPE" == "SR300" ] || [ "$BOX_TYPE" == "SR213" ]); then
    echo "setenv.add-environment = (\"LANG\" => \"$LOCALE\")"
fi
HTTP_SECURITY_HEADER_ENABLE=`syscfg get HTTPSecurityHeaderEnable`

if [ "$HTTP_SECURITY_HEADER_ENABLE" = "true" ]; then
    echo "setenv.add-response-header = ("
    echo "    \"X-Frame-Options\" => \"deny\","
    echo "    \"X-XSS-Protection\" => \"1; mode=block\","
    echo "    \"X-Content-Type-Options\" => \"nosniff\","
    echo "    \"Strict-Transport-Security\" => \"max-age=15768000; includeSubdomains\","
    echo "    \"Pragma\" => \"no-cache\","
    echo "    \"Cache-Control\" => \"no-store, no-cache, must-revalidate\","
    echo "    \"Content-Security-Policy\" => \"default-src 'self' ; style-src 'self' ; frame-src 'self' ; font-src 'self' ; form-action 'self' ; script-src 'self' 'unsafe-inline' 'unsafe-eval'; img-src 'self'; connect-src 'self'; object-src 'none'; media-src 'none'; script-nonce 'none'; plugin-types 'none'; reflected-xss 'none'; report-uri 'none';\","  
    echo ")"
    echo "#sandbox 'allow-same-origin allow-scripts allow-popups allow-forms';"
fi

echo "server.port = $HTTP_ADMIN_PORT"
echo "server.bind = \"$INTERFACE\""

if [ "$BOX_TYPE" == "HUB4" ]
then
	if [ "x$HTTP_PORT_ERT" != "x" ] && [ $HTTP_PORT_ERT -ne 0 ] && [ "$HTTP_PORT_ERT" -ge 1025 ] && [ "$HTTP_PORT_ERT" -le 65535 ];then
		echo "\$SERVER[\"socket\"] == \"erouter0:$HTTP_PORT_ERT\" { server.use-ipv6 = \"enable\" }"
	elif [ $HTTP_PORT -ne 0 ] && [ "$HTTP_PORT" -ge 1025 ] && [ "$HTTP_PORT" -le 65535 ];then
		echo "\$SERVER[\"socket\"] == \"erouter0:$HTTP_PORT\" { server.use-ipv6 = \"enable\" }"
	else
		# When the httpport is set to NULL. Always put default value into database.
		syscfg set mgmt_wan_httpport 8080
		syscfg commit
		HTTP_PORT=`syscfg get mgmt_wan_httpport`
		echo "\$SERVER[\"socket\"] == \"erouter0:$HTTP_PORT\" { server.use-ipv6 = \"enable\" }"
	fi
fi

if [ "$SECUREWEBUI_ENABLE" = "true" ] && [ "$BRIDGE_MODE" = "0" ]
then
    echo -e "\$SERVER[\"socket\"] == \"$INTERFACE:443\" {\n    server.use-ipv6 = \"enable\"\n    ssl.engine = \"enable\"\n    ssl.pemfile = \"/etc/server.pem\"\n    ssl.ca-file = \"/etc/server.pem\"\n}"
else
    echo "\$SERVER[\"socket\"] == \"$INTERFACE:443\" { server.use-ipv6 = \"enable\" ssl.engine = \"enable\" ssl.pemfile = \"/etc/server.pem\" }"
fi

if [ $HTTPS_PORT -ne 0 ] && [ "$HTTPS_PORT" -ge 1025 ] && [ "$HTTPS_PORT" -le 65535 ]
then
  echo "\$SERVER[\"socket\"] == \"erouter0:$HTTPS_PORT\" { server.use-ipv6 = \"enable\" ssl.engine = \"enable\" ssl.pemfile = \"/etc/server.pem\" }"
else
    # When the httpsport is set to NULL. Always put default value into database.
    syscfg set mgmt_wan_httpsport 8181
    syscfg commit
    HTTPS_PORT=`syscfg get mgmt_wan_httpsport`
    echo "\$SERVER[\"socket\"] == \"erouter0:$HTTPS_PORT\" { server.use-ipv6 = \"enable\" ssl.engine = \"enable\" ssl.pemfile = \"/etc/server.pem\" }"
fi

echo "\$SERVER[\"socket\"] == \"$INTERFACE:21515\" { server.use-ipv6 = \"enable\" server.document-root = \"/tmp/pcontrol/\" url.rewrite-if-not-file = (\"^/(.*)$\" => \"/index.html?fwd=$1\") url.access-deny =(\".inc\" )  }"

#SL-100 firmware_download
FD_INTERFACE="usb0"
FD_HTTP_PORT="21616"
if [ "$BOX_TYPE" == "SR213" ]; then
    INTERFACE_CHECK=$(ifconfig $FD_INTERFACE 2>&1)
    if [[ $INTERFACE_CHECK == *"Ethernet"* ]]; then
        echo "\$SERVER[\"socket\"] == \"$FD_INTERFACE:$FD_HTTP_PORT\" { ssl.engine = \"enable\" ssl.pemfile = \"/etc/server.pem\" server.document-root = \"/etc/firmware_download/\" }"
    fi
fi
