FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

inherit systemd

SRC_URI += " \
	    file://CcspXconf.conf \
           "

do_install_append () {
	# Config files and scripts
	install -d ${D}${sysconfdir}
	install -d ${D}${systemd_unitdir}/system/CcspXconf.service.d
	
	install -m 755 ${S}/scripts/xb6_firmwareDwnld.sh ${D}${sysconfdir}/hub4_firmwareDwnld.sh

	# sed Curl path to /usr/bin path 	
	sed -i -e "s/CURL_PATH=\/bin/CURL_PATH=\/usr\/bin/g" ${D}${sysconfdir}/hub4_firmwareDwnld.sh

	install -D -m 0644 ${WORKDIR}/CcspXconf.conf ${D}${systemd_unitdir}/system/CcspXconf.service.d/CcspXconf.conf
}

FILES_${PN}_append = " \
            ${sysconfdir} \
            ${sysconfdir}/hub4_firmwareDwnld.sh \
            ${systemd_unitdir}/system/CcspXconf.service.d/CcspXconf.conf \
                     "
