FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

DEPENDS += "hal-wan-sky sky-headers virtual/kernel"

CFLAGS_append += " \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/userspace/public/include/ \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/sky/userspace/public/include \
               -DSKY_RDKB -DBFD_IMPLEMENTATION_ENABLED -DFEATURE_MAPT_DEBUG \
               "
LDFLAGS_append = " \
    -lhal_wan \
    -lcms_msg \
    -lcms_util \
"

do_configure[depends] += "${MLPREFIX}halinterface:do_install"
do_configure[depends] += "${MLPREFIX}sky-headers:do_install"
do_configure[depends] += "virtual/kernel:do_install"
