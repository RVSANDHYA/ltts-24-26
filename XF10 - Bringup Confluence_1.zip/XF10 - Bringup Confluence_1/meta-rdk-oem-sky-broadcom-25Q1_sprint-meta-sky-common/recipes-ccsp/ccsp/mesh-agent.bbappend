FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += " ${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203','file://002_security_daemon_mesh_disable.patch', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi','file://meshAgent_onewifi.service','file://meshAgent.service', d)}"

do_install_append () {
    if ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', 'true', 'false', d)}; then
    	install -D -m 0644 ${WORKDIR}/meshAgent_onewifi.service ${D}${systemd_unitdir}/system/meshAgent.service
    else
    	install -D -m 0644 ${WORKDIR}/meshAgent.service ${D}${systemd_unitdir}/system/meshAgent.service
    fi    
    rm -rf ${D}${systemd_unitdir}/system/meshAgent.path
}

DEPENDS += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR300','ovs-agent','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR300', '-DMESH_OVSAGENT_ENABLE', '', d)}"
LDFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR300',' -lOvsAgentApi ',' ',d)}"

DEPENDS += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SE501','ovs-agent','',d)}"
CFLAGS_append += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SE501', '-DMESH_OVSAGENT_ENABLE', '', d)}"
LDFLAGS_append += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SE501',' -lOvsAgentApi ',' ',d)}"

DEPENDS += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203','ovs-agent','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203', '-DMESH_OVSAGENT_ENABLE', '', d)}"
LDFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203',' -lOvsAgentApi ',' ',d)}"

DEPENDS += "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR213','ovs-agent','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR213', '-DMESH_OVSAGENT_ENABLE', '', d)}"
LDFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR213',' -lOvsAgentApi ',' ',d)}"

DEPENDS += "${@bb.utils.contains('MACHINE_IMAGE_NAME','WNXL11BWL','ovs-agent','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','WNXL11BWL', '-DMESH_OVSAGENT_ENABLE', '', d)}"
LDFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','WNXL11BWL',' -lOvsAgentApi ',' ',d)}"

SYSTEMD_SERVICE_${PN}_remove = " meshAgent.path"
FILES_${PN}_remove = " ${systemd_unitdir}/system/meshAgent.path"

FILES_${PN} += "${systemd_unitdir}/system/meshAgent.service"
SYSTEMD_SERVICE_${PN} = " ${@bb.utils.contains('DISTRO_FEATURES', 'meshwifi', 'meshAgent.service', '', d)}"
