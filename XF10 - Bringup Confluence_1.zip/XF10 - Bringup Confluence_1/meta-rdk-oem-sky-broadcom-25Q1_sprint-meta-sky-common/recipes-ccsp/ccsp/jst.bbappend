CFLAGS_append = " \
    -DBUILD_RBUS \
    -I=${includedir}/dbus-1.0 \
    -I=${libdir}/dbus-1.0/include \
    "
