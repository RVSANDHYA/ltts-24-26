FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

do_install_append_skyhub4-l07 () {
    install -m 644 ${S}/source/cr-deviceprofile_skyhub4-l07.xml ${D}/usr/ccsp/cr-ethwan-deviceprofile.xml
    install -m 644 ${S}/source/cr-deviceprofile_skyhub4-l07.xml ${D}/usr/ccsp/cr-deviceprofile.xml
}

do_install_append_skysr213 () {
    install -m 644 ${S}/source/cr-deviceprofile_skysr213.xml ${D}/usr/ccsp/cr-ethwan-deviceprofile.xml
    install -m 644 ${S}/source/cr-deviceprofile_skysr213.xml ${D}/usr/ccsp/cr-deviceprofile.xml
}

do_install_append_xle-wnc () {
    install -m 644 ${S}/source/cr-deviceprofile_xle-wnc.xml ${D}/usr/ccsp/cr-ethwan-deviceprofile.xml
    install -m 644 ${S}/source/cr-deviceprofile_xle-wnc.xml ${D}/usr/ccsp/cr-deviceprofile.xml
}

EXTRA_OECONF_remove = " --enable-notify"
