FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

HASAKER = "${@bb.utils.contains('DISTRO_FEATURES', 'aker', 'true', 'false', d)}"
HASWANMANAGER = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'true', 'false', d)}"
HASTELCOVOICEMANAGER = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'true', 'false', d)}"
HASTELCOVOICEMANAGERV2 = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2', 'true', 'false', d)}"
HASXDSLPPPMANAGER = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'true', 'false', d)}"
HASRDKLEDMANAGER = "${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', 'true', 'false', d)}"
IsRdkbExtSupported = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', 'true', 'false', d)}"

CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'feature_mapt', '-DFEATURE_MAPT', '', d)}"

SRC_URI_append = " \
    file://autoconf.h \
    file://systemd/gwprovapp-ethwan.conf \
    file://systemd/CcspCrSsp.conf \
    file://systemd/CcspPandMSsp.conf \
    file://systemd/PsmSsp.conf \
    file://systemd/harvester.conf \
    file://systemd/aker.conf \
    file://systemd/CcspWebpaAdapter.conf \
    file://systemd/CcspWebUI.conf \
    file://systemd/parodus.conf \
    file://systemd/utopia-ready.path \
    file://systemd/cr-ready.path \
    file://systemd/waninitialized.path \
    file://systemd/rdk-netfilter.service \
    file://rdk_netfilter.conf \
    file://cacert.pem \
    file://deviceinfo.sh \
    file://utopia.service \
    file://ledmanager.service \
    file://systemd/rdkbLogMonitor.conf \
    file://systemd/CcspEthAgent.conf \
    file://systemd/wifi-telemetry-cron.conf \
    file://systemd/meshwifi.conf \
    file://systemd/SkyLanManager.path \
    file://SkyLanManager.service \
"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', ' file://systemd/extenderModeWait.sh', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', ' file://systemd/CcspLMLite.conf', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'file://systemd/RdkVlanManager.conf', 'file://systemd/CcspVLANAgent.conf', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'file://systemd/RdkTelcoVoiceManager.conf', 'file://systemd/CcspTelcoVoipAgent.conf', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'file://systemd/RdkWanManager.conf', 'file://systemd/CcspWanAgent.conf', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'file://systemd/RdkXdslManager.conf', 'file://systemd/CcspXTMAgent.conf file://systemd/CcspDSLAgent.conf', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'file://ifacemanager_xdsl.service', 'file://ifacemanager.service', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'file://ifacemanager_vlan.service', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'file://ifacemanager_telcovoice.service', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'file://rdktelcovoicemanager/RdkTelcoVoiceManager.path', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'file://systemd/RdkFwUpgradeManager.service', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'file://systemd/RdkPppManager.service', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'file://rdktelcovoicemanager/telcovoice_config_default_ROI.json', '', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2', 'file://rdktelcovoicemanager/telcovoice_config_default_UK_v2.json', 'file://rdktelcovoicemanager/telcovoice_config_default_UK.json', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2', 'file://rdktelcovoicemanager/telcovoice_config_default_ITA_v2.json', 'file://rdktelcovoicemanager/telcovoice_config_default_ITA.json', d)}"
SRC_URI_append += "${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', 'file://systemd/RdkLedManager.conf', '', d)}"

do_install_append_class-target () {
	rm -rf ${D}/usr/ccsp/cm
	rm -rf ${D}/usr/ccsp/mta
	rm -rf ${D}/usr/ccsp/tr069pa

	#Installing autoconf.h
	install -m 644 ${WORKDIR}/autoconf.h ${D}/usr/include/ccsp/

	install -D -m 0644 ${WORKDIR}/systemd/utopia-ready.path ${D}${systemd_unitdir}/system/utopia-ready.path
	install -D -m 0644 ${WORKDIR}/systemd/cr-ready.path ${D}${systemd_unitdir}/system/cr-ready.path
	install -D -m 0644 ${WORKDIR}/systemd/waninitialized.path ${D}${systemd_unitdir}/system/waninitialized.path
        install -D -m 0644 ${WORKDIR}/systemd/SkyLanManager.path ${D}${systemd_unitdir}/system/SkyLanManager.path

	# Config files and scripts
	install -m 644 ${S}/config/basic.conf ${D}/usr/ccsp/basic.conf
	install -m 644 ${S}/config/ccsp_msg.cfg ${D}/usr/ccsp/ccsp_msg.cfg

	install -m 777 ${S}/scripts/cli_start_atom.sh ${D}/usr/ccsp/cli_start.sh
	install -m 777 ${S}/systemd_units/scripts/ccspSysConfigEarly.sh ${D}/usr/ccsp/ccspSysConfigEarly.sh
	install -m 777 ${S}/systemd_units/scripts/ccspSysConfigLate.sh ${D}/usr/ccsp/ccspSysConfigLate.sh
	install -m 777 ${S}/systemd_units/scripts/utopiaInitCheck.sh ${D}/usr/ccsp/utopiaInitCheck.sh
	install -m 777 ${S}/systemd_units/scripts/ProcessResetCheck.sh ${D}/usr/ccsp/ProcessResetCheck.sh
	install -m 777 ${S}/systemd_units/scripts/log_psm.db.sh ${D}/usr/ccsp/log_psm.db.sh
    if [ "${IsRdkbExtSupported}" = "true" ]; then
        install -D -m 777 ${WORKDIR}/systemd/extenderModeWait.sh ${D}/usr/ccsp/extenderModeWait.sh
        install -d ${D}${systemd_unitdir}/system/CcspLMLite.service.d
        install -D -m 0644 ${WORKDIR}/systemd/CcspLMLite.conf ${D}${systemd_unitdir}/system/CcspLMLite.service.d/CcspLMLite.conf
    fi

	#Installing gwprovapp.service
	install -D -m 0644 ${S}/systemd_units/gwprovapp-ethwan.service ${D}${systemd_unitdir}/system/gwprovapp-ethwan.service
	install -D -m 0644 ${WORKDIR}/systemd/gwprovapp-ethwan.conf ${D}${systemd_unitdir}/system/gwprovapp-ethwan.service.d/gwprovapp-ethwan.conf
	install -D -m 0644 ${WORKDIR}/systemd/CcspCrSsp.conf ${D}${systemd_unitdir}/system/CcspCrSsp.service.d/CcspCrSsp.conf
	install -D -m 0644 ${WORKDIR}/systemd/CcspPandMSsp.conf ${D}${systemd_unitdir}/system/CcspPandMSsp.service.d/CcspPandMSsp.conf
	install -D -m 0644 ${WORKDIR}/systemd/PsmSsp.conf ${D}${systemd_unitdir}/system/PsmSsp.service.d/PsmSsp.conf
	install -D -m 0644 ${WORKDIR}/systemd/harvester.conf ${D}${systemd_unitdir}/system/harvester.service.d/harvester.conf

    install -D -m 0644 ${WORKDIR}/systemd/CcspEthAgent.conf ${D}${systemd_unitdir}/system/CcspEthAgent.service.d/CcspEthAgent.conf

	#Systemd Services
	install -D -m 0644 ${S}/systemd_units/CcspCrSsp.service ${D}${systemd_unitdir}/system/CcspCrSsp.service
	install -D -m 0644 ${S}/systemd_units/ProcessResetDetect.path ${D}${systemd_unitdir}/system/ProcessResetDetect.path

	#utopia systemd service
	install -m 0644 ${WORKDIR}/utopia.service ${D}${systemd_unitdir}/system/utopia.service

        #SkyLanManager systemd service
        install -m 0644 ${WORKDIR}/SkyLanManager.service ${D}${systemd_unitdir}/system/SkyLanManager.service

	#services that need to be notified by CcspCrSsp.service

	install -D -m 0644 ${S}/systemd_units/randomFileUpload.service ${D}${systemd_unitdir}/system/randomFileUpload.service
	install -D -m 0644 ${S}/systemd_units/PsmSsp.service ${D}${systemd_unitdir}/system/PsmSsp.service

	#services that need to be notified by PsmSsp.service
	install -D -m 0644 ${S}/systemd_units/CcspPandMSsp.service ${D}${systemd_unitdir}/system/CcspPandMSsp.service
    if [ ${HASWANMANAGER} = "true" ]; then
        install -D -m 0644 ${S}/systemd_units/RdkWanManager.service ${D}${systemd_unitdir}/system/RdkWanManager.service
        install -D -m 0644 ${S}/systemd_units/RdkVlanManager.service ${D}${systemd_unitdir}/system/RdkVlanManager.service
        install -D -m 0644 ${WORKDIR}/systemd/RdkWanManager.conf ${D}${systemd_unitdir}/system/RdkWanManager.service.d/RdkWanManager.conf
        install -D -m 0644 ${WORKDIR}/systemd/RdkVlanManager.conf ${D}${systemd_unitdir}/system/RdkVlanManager.service.d/RdkVlanManager.conf
        install -D -m 0644 ${WORKDIR}/ifacemanager_vlan.service ${D}${systemd_unitdir}/system/ifacemanager_vlan.service
        install -D -m 0644 ${S}/systemd_units/RdkFwUpgradeManager.service ${D}${systemd_unitdir}/system/RdkFwUpgradeManager.service
    else
        install -D -m 0644 ${S}/systemd_units/CcspWanAgent.service ${D}${systemd_unitdir}/system/CcspWanAgent.service
        install -D -m 0644 ${S}/systemd_units/CcspVLANAgent.service ${D}${systemd_unitdir}/system/CcspVLANAgent.service
        install -D -m 0644 ${WORKDIR}/systemd/CcspVLANAgent.conf ${D}${systemd_unitdir}/system/CcspVLANAgent.service.d/CcspVLANAgent.conf
        install -D -m 0644 ${WORKDIR}/systemd/CcspWanAgent.conf ${D}${systemd_unitdir}/system/CcspWanAgent.service.d/CcspWanAgent.conf
        #eth_interface_mgr service.
        install -m 0644 ${WORKDIR}/ifacemanager.service ${D}${systemd_unitdir}/system/ifacemanager.service
    fi

    if [ ${HASRDKLEDMANAGER} = "true" ]; then
        install -D -m 0644 ${S}/systemd_units/RdkLedManager.service ${D}${systemd_unitdir}/system/RdkLedManager.service
        install -D -m 0644 ${WORKDIR}/systemd/RdkLedManager.conf ${D}${systemd_unitdir}/system/RdkLedManager.service.d/RdkLedManager.conf
    else
        # old ledmanager systemd service
	    install -m 0644 ${WORKDIR}/ledmanager.service ${D}${systemd_unitdir}/system/ledmanager.service
    fi

    if [ ${HASTELCOVOICEMANAGER} = "true" ]; then
        install -D -m 0644 ${WORKDIR}/ifacemanager_telcovoice.service ${D}${systemd_unitdir}/system/ifacemanager_telcovoice.service
        install -D -m 0644 ${WORKDIR}/rdktelcovoicemanager/RdkTelcoVoiceManager.path ${D}${systemd_unitdir}/system/RdkTelcoVoiceManager.path
        install -D -m 0644 ${WORKDIR}/systemd/RdkTelcoVoiceManager.conf ${D}${systemd_unitdir}/system/RdkTelcoVoiceManager.service.d/RdkTelcoVoiceManager.conf
        install -D -m 0644 ${S}/systemd_units/RdkTelcoVoiceManager.service ${D}${systemd_unitdir}/system/RdkTelcoVoiceManager.service
        install -D -m 0644 ${WORKDIR}/rdktelcovoicemanager/telcovoice_config_default_ROI.json ${D}/usr/rdk/voicemanager/telcovoice_config_default_ROI.json
	if [ ${HASTELCOVOICEMANAGERV2} = "true" ]; then
           install -D -m 0644 ${WORKDIR}/rdktelcovoicemanager/telcovoice_config_default_UK_v2.json ${D}/usr/rdk/voicemanager/telcovoice_config_default_UK.json
           install -D -m 0644 ${WORKDIR}/rdktelcovoicemanager/telcovoice_config_default_ITA_v2.json ${D}/usr/rdk/voicemanager/telcovoice_config_default_ITA.json
        else
           install -D -m 0644 ${WORKDIR}/rdktelcovoicemanager/telcovoice_config_default_UK.json ${D}/usr/rdk/voicemanager/telcovoice_config_default_UK.json
           install -D -m 0644 ${WORKDIR}/rdktelcovoicemanager/telcovoice_config_default_ITA.json ${D}/usr/rdk/voicemanager/telcovoice_config_default_ITA.json
        fi
    else
        install -D -m 0644 ${WORKDIR}/systemd/CcspTelcoVoipAgent.conf ${D}${systemd_unitdir}/system/CcspTelcoVoipAgent.service.d/CcspTelcoVoipAgent.conf
        install -D -m 0644 ${S}/systemd_units/CcspTelcoVoipAgent.service ${D}${systemd_unitdir}/system/CcspTelcoVoipAgent.service
    fi

   if [ ${HASXDSLPPPMANAGER} = "true" ]; then
        install -D -m 0644 ${S}/systemd_units/RdkXdslManager.service ${D}${systemd_unitdir}/system/RdkXdslManager.service
        install -D -m 0644 ${WORKDIR}/systemd/RdkXdslManager.conf ${D}${systemd_unitdir}/system/RdkXdslManager.service.d/RdkXdslManager.conf
        install -D -m 0644 ${WORKDIR}/ifacemanager_xdsl.service ${D}${systemd_unitdir}/system/ifacemanager_xdsl.service
        install -D -m 0644 ${S}/systemd_units/RdkPppManager.service ${D}${systemd_unitdir}/system/RdkPppManager.service
   else
        install -D -m 0644 ${S}/systemd_units/CcspDSLAgent.service ${D}${systemd_unitdir}/system/CcspDSLAgent.service
        install -D -m 0644 ${S}/systemd_units/CcspXTMAgent.service ${D}${systemd_unitdir}/system/CcspXTMAgent.service
        install -D -m 0644 ${WORKDIR}/systemd/CcspDSLAgent.conf ${D}${systemd_unitdir}/system/CcspDSLAgent.service.d/CcspDSLAgent.conf
        install -D -m 0644 ${WORKDIR}/systemd/CcspXTMAgent.conf ${D}${systemd_unitdir}/system/CcspXTMAgent.service.d/CcspXTMAgent.conf
   fi

	#services that are triggered by system events
	install -D -m 0644 ${S}/systemd_units/ProcessResetDetect.service ${D}${systemd_unitdir}/system/ProcessResetDetect.service

	#services that need to be notified by CcspPandMSsp.service
	install -D -m 0644 ${S}/systemd_units/notifyComp.service ${D}${systemd_unitdir}/system/notifyComp.service

	#wifi-vendor-initialized target services
	if ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', 'true', 'false', d)}; then
		install -D -m 0644 ${S}/systemd_units/onewifi.service ${D}${systemd_unitdir}/system/onewifi.service
	else
		install -D -m 0644 ${S}/systemd_units/ccspwifiagent.service ${D}${systemd_unitdir}/system/ccspwifiagent.service
	fi
	
	#CCSP WiFi Initialization Targets
	install -D -m 0644 ${S}/systemd_units/wifi-initialized.target ${D}${systemd_unitdir}/system/wifi-initialized.target
	install -D -m 0644 ${S}/systemd_units/wifiinitialized.path ${D}${systemd_unitdir}/system/wifiinitialized.path
	if ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', 'true', 'false', d)}; then
		sed -i -- '/StandardOutput=syslog/a\\n[Install]\nWantedBy=wifi-initialized.target\n' ${D}${systemd_unitdir}/system/onewifi.service
	else
	        sed -i -- 's/WantedBy=multi-user.target/WantedBy=wifi-initialized.target/g' ${D}${systemd_unitdir}/system/ccspwifiagent.service
	fi

    #meshwifi
    if ${@bb.utils.contains('DISTRO_FEATURES', 'kirkstone', 'true', 'false', d)}; then
        sed -i "s|KillMode=.*$|KillMode=|" ${WORKDIR}/systemd/meshwifi.conf
    fi
    install -D -m 0644 ${WORKDIR}/systemd/meshwifi.conf ${D}${systemd_unitdir}/system/meshwifi.service.d/meshwifi.conf

	#Exporting log redirection logic to redirect all statements to console log file
	if ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', 'true', 'false', d)}; then
		sed -i -- 's/ExecStart=\/usr\/bin\/CcspWifiSsp \-subsys \$Subsys/ExecStart=\/bin\/sh \-c \"source \/etc\/utopia\/service.d\/log_capture_path.sh \&\& \/usr\/bin\/CcspWifiSsp \-subsys \$Subsys\"/g' ${D}${systemd_unitdir}/system/onewifi.service
	else
		sed -i -- 's/ExecStart=\/usr\/bin\/CcspWifiSsp \-subsys \$Subsys/ExecStart=\/bin\/sh \-c \"source \/etc\/utopia\/service.d\/log_capture_path.sh \&\& \/usr\/bin\/CcspWifiSsp \-subsys \$Subsys\"/g' ${D}${systemd_unitdir}/system/ccspwifiagent.service
		#RDKB-43737 Avoid killing child process upon wifiagent restart
		sed -i -- "s/ExecStopPost=.*/ExecStopPost=\/bin\/sh \-c \'echo \"\`date\`\: Stopping\/Restarting CcspWifiSsp\" >> \${PROCESS_RESTART_LOG} \&\& \/usr\/bin\/killall wifidb\-server\'/g" ${D}${systemd_unitdir}/system/ccspwifiagent.service
		sed -i -- '/ExecStopPost/i KillMode=process' ${D}${systemd_unitdir}/system/ccspwifiagent.service
	fi
	sed -i -- 's/ExecStart=\/usr\/bin\/CcspPandMSsp \-subsys \$Subsys/ExecStart=\/bin\/sh \-c \"source \/etc\/utopia\/service.d\/log_capture_path.sh \&\& \/usr\/bin\/CcspPandMSsp \-subsys \$Subsys\"/g' ${D}${systemd_unitdir}/system/CcspPandMSsp.service

        #service to initiate xconf download
        install -D -m 0644 ${S}/systemd_units/CcspXconf.service ${D}${systemd_unitdir}/system/CcspXconf.service

        #Xdns service
	install -D -m 0644 ${S}/systemd_units/CcspXdnsSsp.service ${D}${systemd_unitdir}/system/CcspXdnsSsp.service

        install -D -m 0644 ${S}/systemd_units/CcspTandDSsp.service ${D}${systemd_unitdir}/system/CcspTandDSsp.service

        #service to start LM lite
        install -D -m 0644 ${S}/systemd_units/CcspLMLite.service ${D}${systemd_unitdir}/system/CcspLMLite.service
        #remove LM lite dependecy on MOCA (no MOCA in HUB4)
        sed -i -- 's/CcspMoca.service/wifi-initialized.target/g' ${D}${systemd_unitdir}/system/CcspLMLite.service
       	sed -i -- '/After=/a\\nRequires=wifi-initialized.target\n' ${D}${systemd_unitdir}/system/CcspLMLite.service

        #CCSP Initialization Targets
	install -D -m 0644 ${S}/systemd_units/wan-initialized.target ${D}${systemd_unitdir}/system/wan-initialized.target
    install -D -m 0644 ${S}/systemd_units/ServiceCtrl.service ${D}${systemd_unitdir}/system/ServiceCtrl.service

if [ ${HASNOADVSECURITY} != "true" ]; then
        #CcspAdvSecurity
        install -D -m 0644 ${S}/systemd_units/CcspAdvSecuritySsp.service ${D}${systemd_unitdir}/system/CcspAdvSecuritySsp.service
fi

        #Remove TandD dependecy on MOCA (no MOCA in HUB4)
	sed -i -- 's/CcspMoca.service/CcspCrSsp.service/g' ${D}${systemd_unitdir}/system/CcspTandDSsp.service

	#CCSP Process targets
	sed -i -- '3s/$/Requires=dbus.service\n/' ${D}${systemd_unitdir}/system/CcspCrSsp.service

	#ccspPAMCPCheck.sh is not required for sky devices as captive portal is disabled.
	sed -i '/ccspPAMCPCheck.sh/d' ${D}${systemd_unitdir}/system/CcspPandMSsp.service

	#CCSP convert systemd Typ from Notify to forking -- TCXB6-2733
	sed -i -- 's/NotifyAccess=.*/#NotifyAccess=main/g' ${D}${systemd_unitdir}/system/CcspCrSsp.service
	sed -i -- 's/NotifyAccess=.*/#NotifyAccess=main/g' ${D}${systemd_unitdir}/system/PsmSsp.service
	sed -i -- 's/notify.*/forking/g' ${D}${systemd_unitdir}/system/CcspCrSsp.service
	sed -i -- 's/notify.*/forking/g' ${D}${systemd_unitdir}/system/PsmSsp.service

	sed -i -- '3s/$/ConditionPathExists=\/tmp\/cr_initialized/' ${D}${systemd_unitdir}/system/PsmSsp.service

	install -D -m 0644 ${S}/systemd_units/CcspWebUI.service ${D}${systemd_unitdir}/system/CcspWebUI.service
	sed -i -- 's/WantedBy=wifi-initialized.target/WantedBy=multi-user.target/g' ${D}${systemd_unitdir}/system/CcspWebUI.service
	#sed -i -- 's/WantedBy=wan-initialized.target/WantedBy=multi-user.target/g' ${D}${systemd_unitdir}/system/CcspXconf.service
        sed -i -- '/RemainAfterExit=yes/a\\n[Install]\nWantedBy=multi-user.target\n' ${D}${systemd_unitdir}/system/CcspXconf.service
	install -D -m 0644 ${WORKDIR}/systemd/CcspWebUI.conf ${D}${systemd_unitdir}/system/CcspWebUI.service.d/CcspWebUI.conf

	install -D -m 0644 ${S}/systemd_units/CcspEthAgent.service ${D}${systemd_unitdir}/system/CcspEthAgent.service

	#Webpa services
	install -D -m 0644 ${S}/systemd_units/parodus.service ${D}${systemd_unitdir}/system/parodus.service
	if [ ${IsRdkbExtSupported} = "false" ]; then
		install -D -m 0644 ${WORKDIR}/systemd/parodus.conf ${D}${systemd_unitdir}/system/parodus.service.d/parodus.conf
	fi
	install -D -m 0644 ${S}/systemd_units/webpa.service ${D}${systemd_unitdir}/system/webpa.service
	install -D -m 0644 ${WORKDIR}/systemd/CcspWebpaAdapter.conf ${D}${systemd_unitdir}/system/webpa.service.d/CcspWebpaAdapter.conf
	if ${@bb.utils.contains('DISTRO_FEATURES', 'webconfig_bin', 'true', 'false', d)}; then
        	install -D -m 0644 ${S}/systemd_units/webconfig.service ${D}${systemd_unitdir}/system/webconfig.service
    	fi
	install -D -m 0644 ${S}/systemd_units/harvester.service ${D}${systemd_unitdir}/system/harvester.service
	if [ ${HASAKER} = "true" ]; then
		install -D -m 0644 ${S}/systemd_units/aker.service ${D}${systemd_unitdir}/system/aker.service
		install -D -m 0644 ${WORKDIR}/systemd/aker.conf ${D}${systemd_unitdir}/system/aker.service.d/aker.conf
	fi

	#wan-intialized target services
	install -D -m 0644 ${S}/systemd_units/rfc.service ${D}${systemd_unitdir}/system/rfc.service
	install -D -m 0644 ${S}/systemd_units/CcspTelemetry.service ${D}${systemd_unitdir}/system/CcspTelemetry.service

	install -D -m 0644 ${S}/systemd_units/log_journalmsg.service ${D}${systemd_unitdir}/system/log_journalmsg.service

	sed -i -- 's/WantedBy=multi-user.target/WantedBy=wan-initialized.target/g' ${D}${systemd_unitdir}/system/CcspXdnsSsp.service

	# Adding some extra netfilter threshold settings
	install -d ${D}/usr/ccsp
	install -m 644 ${WORKDIR}/rdk_netfilter.conf ${D}/usr/ccsp/rdk_netfilter.conf
	install -D -m 0644 ${WORKDIR}/systemd/rdk-netfilter.service ${D}${systemd_unitdir}/system/rdk-netfilter.service

	install -D -m 0444 ${S}/../cacert.pem ${D}${sysconfdir}/cacert.pem

	install -d ${D}${sbindir}
	install -D -m 0755 ${S}/../deviceinfo.sh ${D}${sbindir}/deviceinfo.sh
	install -D -m 0644 ${WORKDIR}/systemd/rdkbLogMonitor.conf ${D}${systemd_unitdir}/system/rdkbLogMonitor.service.d/rdkbLogMonitor.conf

    install -D -m 0644 ${WORKDIR}/systemd/wifi-telemetry-cron.conf ${D}${systemd_unitdir}/system/wifi-telemetry-cron.service.d/wifi-telemetry-cron.conf

    #alter log_journalmsg.service
    sed -i -- 's/After=CcspMtaAgentSsp.service//g' ${D}${systemd_unitdir}/system/log_journalmsg.service
    sed -i -- '/Description=/a\\nAfter=CcspPandMSsp.service notifyComp.service\n' ${D}${systemd_unitdir}/system/log_journalmsg.service

	if ${@bb.utils.contains('DISTRO_FEATURES', 'webui_jst', 'true', 'false', d)}; then
    	  sed -i -- 's/www/www2/g' ${D}${systemd_unitdir}/system/CcspWebUI.service
	fi

        #NTP synchorization targets
        install -D -m 0644 ${S}/systemd_units/rdkntp.path ${D}${systemd_unitdir}/system/rdkntp.path
        install -D -m 0644 ${S}/systemd_units/rdkntp.target ${D}${systemd_unitdir}/system/rdkntp.target
}

SYSTEMD_SERVICE_${PN} += "gwprovapp-ethwan.service"
SYSTEMD_SERVICE_${PN} += "utopia.service"
SYSTEMD_SERVICE_${PN} += "CcspCrSsp.service"
SYSTEMD_SERVICE_${PN} += "ProcessResetDetect.path"
SYSTEMD_SERVICE_${PN} += "CcspPandMSsp.service"
SYSTEMD_SERVICE_${PN} += "CcspWebUI.service"
SYSTEMD_SERVICE_${PN} += "CcspEthAgent.service"
SYSTEMD_SERVICE_${PN} += "rdkbLogMonitor.service"
SYSTEMD_SERVICE_${PN} += "log_journalmsg.service"
SYSTEMD_SERVICE_${PN} += "randomFileUpload.service"
SYSTEMD_SERVICE_${PN} += "PsmSsp.service"
SYSTEMD_SERVICE_${PN} += "ServiceCtrl.service"
SYSTEMD_SERVICE_${PN} += "wan-initialized.target"
SYSTEMD_SERVICE_${PN} += "wifi-initialized.target"
SYSTEMD_SERVICE_${PN} += "wifiinitialized.path"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', 'onewifi.service', 'ccspwifiagent.service', d)}"
SYSTEMD_SERVICE_${PN} += "utopia-ready.path"
SYSTEMD_SERVICE_${PN} += "cr-ready.path"
SYSTEMD_SERVICE_${PN} += "SkyLanManager.path"
SYSTEMD_SERVICE_${PN} += "SkyLanManager.service"
SYSTEMD_SERVICE_${PN} += "waninitialized.path"
SYSTEMD_SERVICE_${PN} += "CcspXconf.service"
SYSTEMD_SERVICE_${PN} += "CcspXdnsSsp.service"
SYSTEMD_SERVICE_${PN} += "CcspLMLite.service"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('HASNOADVSECURITY', 'true', '', 'CcspAdvSecuritySsp.service', d)}"
SYSTEMD_SERVICE_${PN} += "harvester.service"
SYSTEMD_SERVICE_${PN} += "webpa.service"
SYSTEMD_SERVICE_${PN} += "${@bb.utils.contains('DISTRO_FEATURES', 'webconfig_bin', 'webconfig.service', '', d)}"
SYSTEMD_SERVICE_${PN} += "parodus.service"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'aker', 'aker.service', '', d)}"
SYSTEMD_SERVICE_${PN} += "rdk-netfilter.service"
SYSTEMD_SERVICE_${PN} += "rfc.service"
SYSTEMD_SERVICE_${PN} += "CcspTelemetry.service"
SYSTEMD_SERVICE_${PN} += "CcspTandDSsp.service"
SYSTEMD_SERVICE_${PN} += "notifyComp.service"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'RdkWanManager.service', 'CcspWanAgent.service', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'RdkXdslManager.service', 'CcspXTMAgent.service CcspDSLAgent.service', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'RdkVlanManager.service', 'CcspVLANAgent.service', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'RdkTelcoVoiceManager.service', 'CcspTelcoVoipAgent.service', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'ifacemanager_vlan.service', '', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'ifacemanager_telcovoice.service', '', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'RdkTelcoVoiceManager.path', '', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'ifacemanager_xdsl.service', '', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'RdkFwUpgradeManager.service', '', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'RdkPppManager.service', '', d)}"
SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', 'RdkLedManager.service', 'ledmanager.service', d)}"
SYSTEMD_SERVICE_${PN} += "rdkntp.target"
SYSTEMD_SERVICE_${PN} += "rdkntp.path"

FILES_${PN} += " \
	/usr/ccsp/pam \
	${systemd_unitdir}/system/gwprovapp-ethwan.service \
	${systemd_unitdir}/system/gwprovapp-ethwan.service.d/gwprovapp-ethwan.conf \
	${systemd_unitdir}/system/CcspCrSsp.service.d/CcspCrSsp.conf \
	${systemd_unitdir}/system/CcspPandMSsp.service.d/CcspPandMSsp.conf \
	${systemd_unitdir}/system/PsmSsp.service.d/PsmSsp.conf \
	${systemd_unitdir}/system/harvester.service.d/harvester.conf \
	${systemd_unitdir}/system/webpa.service.d/CcspWebpaAdapter.conf \
	${systemd_unitdir}/system/CcspWebUI.service.d/CcspWebUI.conf \
	${systemd_unitdir}/system/parodus.service.d/parodus.conf \
    ${systemd_unitdir}/system/CcspEthAgent.service.d/CcspEthAgent.conf \
    ${systemd_unitdir}/system/wifi-telemetry-cron.service.d/wifi-telemetry-cron.conf \
	${systemd_unitdir}/system/meshwifi.service.d/meshwifi.conf \
    /usr/ccsp/utopiaInitCheck.sh \
	/usr/ccsp/ccspSysConfigEarly.sh \
	/usr/ccsp/ccspSysConfigLate.sh \
	/usr/ccsp/ProcessResetCheck.sh \
	/usr/ccsp/log_psm.db.sh \
	${systemd_unitdir}/system/waninitialized.path \
	${systemd_unitdir}/system/CcspCrSsp.service \
	${systemd_unitdir}/system/ProcessResetDetect.path \
	${systemd_unitdir}/system/ProcessResetDetect.service \
	${systemd_unitdir}/system/notifyComp.service \
	${systemd_unitdir}/system/CcspWebUI.service \
	${systemd_unitdir}/system/CcspEthAgent.service \
	${systemd_unitdir}/system/rdkbLogMonitor.service \
        ${systemd_unitdir}/system/rdkbLogMonitor.service.d/rdkbLogMonitor.conf \
	${systemd_unitdir}/system/log_journalmsg.service \
	${systemd_unitdir}/system/randomFileUpload.service \
	${systemd_unitdir}/system/PsmSsp.service \
	${systemd_unitdir}/system/ServiceCtrl.service \
	${systemd_unitdir}/system/wifi-initialized.target \
	${systemd_unitdir}/system/wifiinitialized.path \
	${systemd_unitdir}/system/CcspXconf.service \
	${systemd_unitdir}/system/CcspXdnsSsp.service \
	${systemd_unitdir}/system/CcspPandMSsp.service \
	${systemd_unitdir}/system/CcspLMLite.service \
	${systemd_unitdir}/system/wan-initialized.target \
	${systemd_unitdir}/system/utopia-ready.path \
	${systemd_unitdir}/system/cr-ready.path \
	${systemd_unitdir}/system/parodus.service \
	${systemd_unitdir}/system/webpa.service \
	${@bb.utils.contains('DISTRO_FEATURES', 'webconfig_bin', '${systemd_unitdir}/system/webconfig.service ', '', d)} \
	${systemd_unitdir}/system/harvester.service \
	${systemd_unitdir}/system/rdk-netfilter.service \
	${systemd_unitdir}/system/rfc.service \
	${systemd_unitdir}/system/CcspTelemetry.service \
	${systemd_unitdir}/system/CcspTandDSsp.service \
	/usr/ccsp/rdk_netfilter.conf \
	${sysconfdir}/cacert.pem \
        ${systemd_unitdir}/system/rdkntp.target \
        ${systemd_unitdir}/system/rdkntp.path \
    "
FILES_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', '/usr/ccsp/extenderModeWait.sh', '', d)}"
FILES_${PN} += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_extender', ' ${systemd_unitdir}/system/CcspLMLite.service.d/CcspLMLite.conf', '', d)}"

FILES_${PN} += " ${@bb.utils.contains('HASNOADVSECURITY', 'true', '', '${systemd_unitdir}/system/CcspAdvSecuritySsp.service', d)}"
FILES_ccsp-common-startup_append += " \
           ${sbindir}/deviceinfo.sh \
           "
FILES_${PN}_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'aker', '${systemd_unitdir}/system/aker.service', '', d)}"
FILES_${PN}_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'aker', '${systemd_unitdir}/system/aker.service.d/aker.conf', '', d)}"

FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '${systemd_unitdir}/system/RdkWanManager.service', '${systemd_unitdir}/system/CcspWanAgent.service', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', '${systemd_unitdir}/system/RdkXdslManager.service', '${systemd_unitdir}/system/CcspDSLAgent.service ${systemd_unitdir}/system/CcspXTMAgent.service', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '${systemd_unitdir}/system/RdkVlanManager.service', '${systemd_unitdir}/system/CcspVLANAgent.service', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '${systemd_unitdir}/system/RdkTelcoVoiceManager.service', '${systemd_unitdir}/system/CcspTelcoVoipAgent.service', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '${systemd_unitdir}/system/RdkTelcoVoiceManager.path', '', d)}"

FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', '${systemd_unitdir}/system/RdkXdslManager.service.d/RdkXdslManager.conf', '${systemd_unitdir}/system/CcspDSLAgent.service.d/CcspDSLAgent.conf ${systemd_unitdir}/system/CcspXTMAgent.service.d/CcspXTMAgent.conf', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '${systemd_unitdir}/system/RdkVlanManager.service.d/RdkVlanManager.conf', '${systemd_unitdir}/system/CcspVLANAgent.service.d/CcspVLANAgent.conf', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '${systemd_unitdir}/system/RdkWanManager.service.d/RdkWanManager.conf', '${systemd_unitdir}/system/CcspWanAgent.service.d/CcspWanAgent.conf', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '${systemd_unitdir}/system/RdkTelcoVoiceManager.service.d/RdkTelcoVoiceManager.conf', '${systemd_unitdir}/system/CcspTelcoVoipAgent.service.d/CcspTelcoVoipAgent.conf', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '${systemd_unitdir}/system/ifacemanager_vlan.service', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '${systemd_unitdir}/system/ifacemanager_telcovoice.service', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', '${systemd_unitdir}/system/ifacemanager_xdsl.service', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '${systemd_unitdir}/system/RdkFwUpgradeManager.service', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', '${systemd_unitdir}/system/RdkPppManager.service', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '/usr/rdk/voicemanager/telcovoice_config_default_ITA.json', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '/usr/rdk/voicemanager/telcovoice_config_default_ROI.json', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', '/usr/rdk/voicemanager/telcovoice_config_default_UK.json', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', '${systemd_unitdir}/system/RdkLedManager.service', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', '${systemd_unitdir}/system/RdkLedManager.service.d/RdkLedManager.conf', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', '${systemd_unitdir}/system/onewifi.service', '${systemd_unitdir}/system/ccspwifiagent.service', d)}"
