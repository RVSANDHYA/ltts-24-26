FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += "file://DisableXDNSIPv4.patch"

