FILESEXTRAPATHS_prepend := "${THISDIR}/ccsp-webui:"

SRC_URI += "\
    git://${RDK_GIT}/rdk/rdkb/components/sdk/devices/sky/hub4/webui;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};destsuffix=git/source/Styles/hub4;name=sky-hub4 \
"

SRC_URI += "file://password_requirements_jst.patch;patchdir=../../.."
SRC_URI += "file://gateway_jst.patch;patchdir=../../.."
SRC_URI += "file://Sky.png"
SRC_URI += "file://Sky_Wifi.png"
SRC_URI += "file://webgui_config.sh;patchdir=../../.."

SRCREV_sky-hub4 = "${AUTOREV}"

DEPENDS += "chrpath-replacement-native safec"
EXTRANATIVEPATH += "chrpath-native"

CFLAGS_append = " \
    -I${STAGING_INCDIR}/libsafec \
    "

LDFLAGS_append = " \
    -lsafec-3.5 \
    "

CFLAGS_remove = "-DSAFEC_DUMMY_API"

do_compile_append () {
if ${@bb.utils.contains('MACHINE_IMAGE_NAME','SR300','false','true',d)}; then
   if ${@bb.utils.contains('MACHINE_IMAGE_NAME','SE501','false','true',d)}; then
      if ${@bb.utils.contains('MACHINE_IMAGE_NAME','WNXL11BWL','false','true',d)}; then
        if ${@bb.utils.contains('MACHINE_IMAGE_NAME','SR300-OneWifi','false','true',d)}; then
            if ${@bb.utils.contains('MACHINE_IMAGE_NAME','SR213','false','true',d)}; then
                # Compile any web locales
                oe_runmake -C ${S}/../../locales
            fi
        fi
      fi
   fi
fi
}

do_install_append () {
	# Add locales directory
	install -d ${D}/usr/www2/locales/it/LC_MESSAGES
	install -d ${D}/usr/www2/locales/it/actionHandler
	install -d ${D}/usr/www2/locales/it/cmn/js/lib

	# Copy in our locale
	install -m 644 ${S}/../../locales/it_IT.utf8/cmn/js/gateway.js ${D}/usr/www2/locales/it/cmn/js/gateway.js
	install -m 644 ${S}/../../locales/it_IT.utf8/cmn/js/lib/jquery.radioswitch.js ${D}/usr/www2/locales/it/cmn/js/lib/jquery.radioswitch.js
	install -m 644 ${S}/../../locales/it_IT.utf8/cmn/js/utilityFunctions.js ${D}/usr/www2/locales/it/cmn/js/utilityFunctions.js
	install -m 644 ${S}/../../locales/it_IT.utf8/cmn/js/lib/jquery.alerts.js ${D}/usr/www2/locales/it/cmn/js/lib/jquery.alerts.js
	install -m 644 ${S}/../../locales/it_IT.utf8/cmn/js/lib/bootstrap-waitingfor.js ${D}/usr/www2/locales/it/cmn/js/lib/bootstrap-waitingfor.js

	# Copy in our Sky specific UI pages
	install -m 755 ${S}/../hub4/code/sky-italia/jst/includes/*.jst ${D}/usr/www2/includes
	install -m 755 ${S}/../hub4/code/sky-italia/jst/*.jst ${D}/usr/www2
	install -m 755 ${S}/../hub4/code/sky-italia/jst/cmn/js/*.js ${D}/usr/www2/cmn/js
	install -m 755 ${S}/../hub4/code/sky-italia/jst/actionHandler/*.jst ${D}/usr/www2/actionHandler

	# Copy in our partner logos
	install -d ${D}/usr/www2/cmn/syndication/img
	install -m 644 ${WORKDIR}/Sky.png ${D}/usr/www2/cmn/syndication/img/Sky.png
	install -m 644 ${WORKDIR}/Sky_Wifi.png ${D}/usr/www2/cmn/syndication/img/Sky_Wifi.png

	# Copy in our css
	install -m 755 ${S}/../hub4/code/sky-italia/jst/cmn/css/self-heal.css ${D}/usr/www2/cmn/css

	# Adding all dynamic contents appended to lighttpd.conf in below script
	install -d ${D}/${sysconfdir}/
	install -m 0755 ${WORKDIR}/webgui_config.sh ${D}${sysconfdir}/webgui_config.sh
}

do_install_append_morty() {
    install -d ${D}${libdir}/locale
}

FILES_${PN} += "${sysconfdir}/webgui_config.sh"
FILES_${PN}-ccsp += " \
    ${libdir}/locale/* \
    /usr/www2/locales/it_IT.utf8/LC_MESSAGES/* \
    /usr/www2/locales/it_IT.utf8/cmn/js/* \
	/usr/www2/cmn/syndication/img/* \
"


