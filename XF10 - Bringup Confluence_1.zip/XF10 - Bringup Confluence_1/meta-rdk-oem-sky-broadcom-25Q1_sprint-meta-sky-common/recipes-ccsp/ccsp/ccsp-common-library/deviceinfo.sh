#!/bin/sh

usage()
{
    echo "Usage: deviceinfo.sh -[mo|sn|fw|ms|mu|cmac|cip|cipv6|emac|eip|eipv6|lmac|lip|lipv6|optimization|mesh_enable|comodo_enabled]"
    echo "       -mo:    Model number"
    echo "       -sn:    Serial number"
    echo "       -fw:    Firmware version"
    echo "       -ms:    Mesh State"
    echo "       -mu:    Mesh URL"
    echo "       -cmac:  CM MAC"
    echo "       -cip:   CM IP"
    echo "       -cipv6: CM IPv6"
    echo "       -emac:  WAN MAC"
    echo "       -eip:   WAN IP"
    echo "       -eipv6: WAN IPv6"
    echo "       -lmac:  LAN MAC"
    echo "       -lip:   LAN IP"
    echo "       -lipv6: LAN IPv6"
    echo "       -eb_enable: ETHBACKHAUL ENABLE"
    echo "       -eb_disable: ETHBACKHAUL DISABLE"
    echo "       -mode: Current Operational Mode - Gateway or ExtenderMode"
    echo "       -off_chan: Off channel scan status(enabled/disabled)"
    echo "       -rebootreason: Reason for the last Reboot"
    echo "       -optimization: mesh optimzation (disable = 0 default mode, fully controlled by the cloud), (monitor = 1 Transitional mode, local optimization code to be validated with cloud, still fully controller by cloud), (enable = 2 Fully device controlled))"
    echo "       -mesh_enable: mesh rfc"
    echo "       -comodo_enabled : is ca used is comodo"
    exit 1
}

if [ $# -ne 1 ]; then
	usage;
fi

case $1 in
    -mo)
        grep -a "MODEL" /tmp/serial.txt | cut -d"=" -f2
        shift 1
        ;;

    -sn)
        grep -a "SERIAL" /tmp/serial.txt | cut -d"=" -f2
        shift 1
        ;;

    -fw)
        grep "imagename:" /version.txt | cut -d":" -f2
        shift 1
        ;;

    -ms)
        syscfg get mesh_state
        shift 1
        ;;

    -mu)
        syscfg get mesh_url
        shift 1
        ;;

    -cmac)
        wan_if=`syscfg get wan_physical_ifname`
        mac=`cat /sys/class/net/$wan_if/address | tr '[a-f]' '[A-F]' `
        if [ -z "$mac" ] && [ -f "/sys/class/net/atm0/address" ]; then
            mac=$(cat /sys/class/net/atm0/address | tr '[a-f]' '[A-F]')
        fi 
        echo $mac	    
        shift 1
        ;;

    -cip)
        echo "0.0.0.0"
        shift 1
        ;;

    -cipv6)
        echo "0:0:0:0:0:0:0:0"
        shift 1
        ;;

    -emac)
        wan_if=`syscfg get wan_physical_ifname`
        mac=`cat /sys/class/net/$wan_if/address | tr '[a-f]' '[A-F]' `
        if [ -z "$mac" ] && [ -f "/sys/class/net/atm0/address" ]; then
            mac=$(cat /sys/class/net/atm0/address | tr '[a-f]' '[A-F]')
        fi
        echo $mac	    
        shift 1
        ;;

    -eip)
        ifconfig erouter0 | grep "inet addr:" | cut -d":" -f2 | cut -d" " -f1
        shift 1
        ;;

    -eipv6)
        ifconfig erouter0 | grep "Scope:Global" | cut -d"r" -f2 | cut -d" " -f2| cut -d"/" -f1
        shift 1
        ;;

    -lmac)
        ifconfig brlan0 | grep HWaddr | cut -d"r" -f4 | cut -d" " -f2
        shift 1
        ;;

    -lip)
        ifconfig brlan0 | grep "inet addr:" | cut -d":" -f2 | cut -d" " -f1
        shift 1
        ;;

    -lipv6)
        ifconfig brlan0 | grep "inet6 addr" | cut -d"r" -f2 | cut -d" " -f2| cut -d"/" -f1
        shift 1
        ;;

    -eb_enable)
        sysevent set meshethbhaul-up 0
        shift 1
        ;;

    -eb_disable)
        sysevent set meshethbhaul-down 0
        shift 1
        ;;

    -mode)
        mode=`syscfg get Device_Mode`
        if [ "$mode" == "1" ]; then
            echo "Extender"
        else
            echo "Gateway"
        fi
        shift 1
        ;;

    -comodo_enabled)
        ca=`syscfg get comodo_ca_enable`
        echo "$ca"
        shift 1
        ;;

    -off_chan)
        off_chan_status=`psmcli get Device.DeviceInfo.X_RDK_RFC.Feature.OffChannelScan.Enable`
        echo "$off_chan_status"
        shift 1
        ;;

    -rebootreason)
        reason="`syscfg get X_RDKCENTRAL-COM_LastRebootReason`"
        echo "$reason"
        shift 1
        ;;

    -optimization)
        mode=`syscfg get mesh_optimized_mode`
        if [ "$mode" == "1" ]; then
            echo "monitor"
        elif [ "$mode" == "2" ]; then
            echo "enable"
        else
            echo "disable"
        fi
        shift 1
        ;;

    -mesh_enable)
       mesh=`syscfg get mesh_enable`
       echo "$mesh"
       shift 1
       ;;

    *)
        usage;
        ;;

esac

exit 0

