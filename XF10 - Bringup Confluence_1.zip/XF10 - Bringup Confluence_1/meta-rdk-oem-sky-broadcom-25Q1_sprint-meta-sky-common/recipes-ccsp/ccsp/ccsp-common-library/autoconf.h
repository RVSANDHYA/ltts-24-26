#define CONFIG_VENDOR_NAME "Sky CP Ltd"
#define CONFIG_VENDOR_ID "0x0019FB"
#define CONFIG_TI_GW_DESCRIPTION "Sky Internet Gateway Device"
