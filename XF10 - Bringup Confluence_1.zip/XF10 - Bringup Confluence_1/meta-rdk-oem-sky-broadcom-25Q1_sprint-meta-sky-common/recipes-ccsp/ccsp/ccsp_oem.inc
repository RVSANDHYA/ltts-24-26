SUMMARY = "common inc for ccsp modules."

CFLAGS_append = " -UNTPD_ENABLE -D_COSA_BCM_ARM_ -U_ANSC_LITTLE_ENDIAN_ -D_ENABLE_BAND_STEERING_ -D_BEACONRATE_SUPPORT -DFEATURE_802_1P_COS_MARKING -DNAT46_KERNEL_SUPPORT  -DETH_4_PORTS -DENABLE_ETH_WAN "

CFLAGS_append_skyhub4-os-wanmanager = "-DFEATURE_RDKB_WAN_MANAGER"
CFLAGS_append_skyhub4-l07 = "-DFEATURE_RDKB_WAN_MANAGER -DFEATURE_MAPT -DFEATURE_MAPT_DEBUG"
CFLAGS_remove_skyhub4-os-wanmanager = "-DFEATURE_MAPT"
CFLAGS_append_skysr300 = " -DFEATURE_RDKB_WAN_MANAGER -DFEATURE_MAPT -DFEATURE_MAPT_DEBUG"
CFLAGS_append_skyse501 = " -DFEATURE_RDKB_WAN_MANAGER"
CFLAGS_remove_skyse501 = " -DFEATURE_MAPT"

CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR300',' -D_BRIDGE_UTILS_BIN_ ','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR203',' -DETH_STATS_ENABLED -D_BRIDGE_UTILS_BIN_ ','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SE501',' -D_BRIDGE_UTILS_BIN_ ','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','WNXL11BWL',' -D_BRIDGE_UTILS_BIN_ ','',d)}"
CFLAGS_append = "${@bb.utils.contains('MACHINE_IMAGE_NAME','SR213',' -D_BRIDGE_UTILS_BIN_ -DFEATURE_RDKB_WAN_MANAGER -DFEATURE_MAPT -DFEATURE_MAPT_DEBUG ','',d)}"

EXTRA_OECONF_append  ?= "${@bb.utils.contains('DISTRO_FEATURES', 'kirkstone', ' ', ' --with-ccsp-platform=bcm --with-ccsp-arch=arm ', d)}"
