FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

CFLAGS_append  = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '', '-DFEATURE_RDKB_WAN_AGENT', d)}"
CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'feature_mapt', '-DFEATURE_MAPT', '', d)}"
CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', '-DRDK_ONEWIFI', '', d)}"

CFLAGS_append += " -DSKY_FEATURE_SELFHEAL"

do_compile_prepend() {
	sed -i '2i <?define _COSA_BCM_ARM_=True?>'  ${S}/config-arm/TR181-USGv2.XML
	sed -i '2i <?define _ENABLE_DSL_SUPPORT_=True?>'  ${S}/config-arm/TR181-USGv2.XML
	sed -i '2i <?define _HUB4_PRODUCT_REQ_=True?>'  ${S}/config-arm/TR181-USGv2.XML
}

do_compile_prepend_skyhub4-os-wanmanager() {
	sed -i '2i <?define FEATURE_RDKB_WAN_MANAGER=True?>'  ${S}/config-arm/TR181-USGv2.XML
}

do_compile_prepend_skyhub4-l07() {
       sed -i '2i <?define FEATURE_RDKB_WAN_MANAGER=True?>'  ${S}/config-arm/TR181-USGv2.XML

       if ${@bb.utils.contains('DISTRO_FEATURES', 'feature_mapt', 'true', 'false', d)}; then
          sed -i '2i <?define FEATURE_MAPT=True?>' ${S}/config-arm/TR181-USGv2.XML
       fi
}

do_compile_prepend_skysr300() {
        sed -i '2i <?define FEATURE_RDKB_WAN_MANAGER=True?>'  ${S}/config-arm/TR181-USGv2.XML

       if ${@bb.utils.contains('DISTRO_FEATURES', 'feature_mapt', 'true', 'false', d)}; then
          sed -i '2i <?define FEATURE_MAPT=True?>' ${S}/config-arm/TR181-USGv2.XML
       fi
}

do_compile_prepend_skysr213() {
       if ${@bb.utils.contains('DISTRO_FEATURES', 'feature_mapt', 'true', 'false', d)}; then
          sed -i '2i <?define FEATURE_MAPT=True?>' ${S}/config-arm/TR181-USGv2.XML
       fi
}

do_install_append(){
    # Config files and scripts
    install -d ${D}/fss
    install -d ${D}/fss/gw
    install -d ${D}/fss/gw/usr
    install -d ${D}/fss/gw/usr/sbin
    install -d ${D}${sysconfdir}
    
    install -m 644 ${S}/config-arm/CcspDmLib.cfg ${D}${exec_prefix}/ccsp/pam/CcspDmLib.cfg
    install -m 644 ${S}/config-arm/CcspPam.cfg -t ${D}${exec_prefix}/ccsp/pam
    install -m 644 ${S}/config-arm/TR181-USGv2.XML -t ${D}${exec_prefix}/ccsp/pam
    install -m 755 ${S}/scripts/email_notification_monitor.sh ${D}${exec_prefix}/ccsp/pam/email_notification_monitor.sh
    ln -sf /sbin/ip.iproute2 ${D}/fss/gw/usr/sbin/ip
    install -m 755 ${S}/arch/intel_usg/boards/arm_shared/scripts/calc_random_time_to_reboot_dev.sh ${D}${sysconfdir}/calc_random_time_to_reboot_dev.sh
}
