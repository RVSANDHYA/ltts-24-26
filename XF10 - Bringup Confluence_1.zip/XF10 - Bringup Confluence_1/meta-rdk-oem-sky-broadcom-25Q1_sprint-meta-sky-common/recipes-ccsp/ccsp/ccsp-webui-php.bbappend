FILESEXTRAPATHS_prepend := "${THISDIR}/ccsp-webui:"

SRC_URI += "\
    git://${RDK_GIT}/rdk/rdkb/components/sdk/devices/sky/hub4/webui;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};destsuffix=git/source/Styles/hub4;name=sky-hub4 \
"

SRC_URI += "file://password_requirements.patch;patchdir=../.."
SRC_URI += "file://Sky.png"
SRC_URI += "file://Sky_Wifi.png"

SRCREV_sky-hub4 = "${AUTOREV}"

DEPENDS += "chrpath-replacement-native"
EXTRANATIVEPATH += "chrpath-native"

do_compile_append () {
    # Compile any web locales
    oe_runmake -C ${S}../locales
}

do_install_append () {
	## Replace cpgc with configparamgen
	sed -i -- 's/cpgc.*/configparamgen/g' ${D}/etc/webgui.sh
	## remove cosa.so from ARM specific paths
	rm -f ${D}/fss/gw/usr/ccsp/cosa.so
	
	## copy cosa.so to /usr/lib
	install -d ${D}/usr/lib/
	install ${B}/modules/cosa.so ${D}/usr/lib/
	chrpath -d ${D}/usr/lib/cosa.so
	install -d ${D}/fss/gw/usr/sbin
	ln -sf /usr/ccsp/confPhp ${D}/fss/gw/usr/sbin/confPhp
	install -d ${D}/usr/sbin
	ln -sf /usr/ccsp/confPhp ${D}/usr/sbin/confPhp
	# Add locales directory
	install -d ${D}/usr/www/locales/it_IT.utf8/LC_MESSAGES
	install -d ${D}/usr/www/locales/it_IT.utf8/actionHandler
	install -d ${D}/usr/www/locales/it_IT.utf8/cmn/js/lib

	# Copy in our locale
    install -m 644 ${S}../locales/it_IT.utf8/LC_MESSAGES/rdkb.mo ${D}/usr/www/locales/it_IT.utf8/LC_MESSAGES/rdkb.mo
    install -m 644 ${S}../locales/it_IT.utf8/cmn/js/gateway.js ${D}/usr/www/locales/it_IT.utf8/cmn/js/gateway.js
    install -m 644 ${S}../locales/it_IT.utf8/cmn/js/lib/jquery.radioswitch.js ${D}/usr/www/locales/it_IT.utf8/cmn/js/lib/jquery.radioswitch.js
    install -m 644 ${S}../locales/it_IT.utf8/cmn/js/utilityFunctions.js ${D}/usr/www/locales/it_IT.utf8/cmn/js/utilityFunctions.js
    install -m 644 ${S}../locales/it_IT.utf8/cmn/js/lib/jquery.alerts.js ${D}/usr/www/locales/it_IT.utf8/cmn/js/lib/jquery.alerts.js
    install -m 644 ${S}../locales/it_IT.utf8/cmn/js/lib/bootstrap-waitingfor.js ${D}/usr/www/locales/it_IT.utf8/cmn/js/lib/bootstrap-waitingfor.js
            
    # Copy in our Sky specific UI pages
    install -m 755 ${S}../Styles/hub4/code/sky-italia/includes/*.php ${D}/usr/www/includes
    install -m 755 ${S}../Styles/hub4/code/sky-italia/cmn/img/* ${D}/usr/www/cmn/img
    install -m 755 ${S}../Styles/hub4/code/sky-italia/*.php ${D}/usr/www
    install -m 755 ${S}../Styles/hub4/code/sky-italia/cmn/js/*.js ${D}/usr/www/cmn/js
    install -m 755 ${S}../Styles/hub4/code/sky-italia/actionHandler/*.php ${D}/usr/www/actionHandler
    
    # Copy in our partner logos
    install -d ${D}/usr/www/cmn/syndication/img
    install -m 644 ${WORKDIR}/Sky.png ${D}/usr/www/cmn/syndication/img/Sky.png
    install -m 644 ${WORKDIR}/Sky_Wifi.png ${D}/usr/www/cmn/syndication/img/Sky_Wifi.png
}

do_install_append_morty() {
    install -d ${D}${libdir}/locale
}

FILES_${PN}-ccsp += " \
    ${libdir}/locale/* \
    ${exec_prefix}/ccsp/confPhp \
    /usr/www/locales/it_IT.utf8/LC_MESSAGES/* \
    /usr/www/locales/it_IT.utf8/cmn/js/* \ 
	/usr/www/cmn/syndication/img/* \
"
