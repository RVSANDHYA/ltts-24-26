FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"
CFLAGS_append  = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '-DFEATURE_RDKB_WAN_MANAGER', '-DFEATURE_RDKB_WAN_AGENT', d)}"
do_compile_prepend () {
	if ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', 'true', 'false', d)}; then
    		sed -i '2i <?define FEATURE_RDKB_WAN_MANAGER=True?>' ${S}/config/TR181-EthAgent.xml
        else
        	sed -i '2i <?define FEATURE_RDKB_WAN_AGENT=True?>' ${S}/config/TR181-EthAgent.xml
   	fi
}
