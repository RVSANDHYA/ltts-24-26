SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-dhcpv4c"
RPROVIDES_${PN} = "hal-dhcpv4c"

DEPENDS += "rdkb-halif-dhcp sky-headers ccsp-common-library utopia"

SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=dhcpv4hal"

SRCREV_dhcpv4hal = "${AUTOREV}"
SRCREV_FORMAT = "dhcpv4hal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/dhcpv4c"

CFLAGS_append = " -I${STAGING_INCDIR}/ccsp "
CFLAGS_append = " -I${STAGING_INCDIR}/sysevent "
CFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' -DUDHCPC_SWITCH', '', d)}"
inherit autotools coverity
