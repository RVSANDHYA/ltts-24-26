SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-dsl"
RPROVIDES_${PN} = "hal-dsl"

DEPENDS += "halinterface sky-headers runtime-libs ccsp-common-library cjson"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=dslhal"

SRCREV_dslhal = "${AUTOREV}"
SRCREV_FORMAT = "dslhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/dsl"

CFLAGS_append = " \
               -I ${STAGING_INCDIR} \
               -I ${STAGING_INCDIR}/ccsp \
               -I ${STAGING_INCDIR}/sysevent \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/sky/userspace/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
               -DSKY_RDKB -DSKY \
               "

do_configure[depends] += "sky-headers:do_install"
do_configure[depends] += "halinterface:do_install"

FILES_${PN} += " \
                ${bindir}/* \
                ${libdir}/* \
               "

inherit autotools coverity
