SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-platform"
RPROVIDES_${PN} = "hal-platform"

DEPENDS += "virtual/kernel rdkb-halif-platform sky-headers ccsp-common-library runtime-libs"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=platformhal"

SRCREV_platformhal = "${AUTOREV}"
SRCREV_FORMAT = "platformhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/platform"

CFLAGS_append = " -I${STAGING_INCDIR}/ccsp \
    -I${STAGING_INCDIR}/bcm963xx/ \
    -I${STAGING_INCDIR}/shared/opensource/include/bcm963xx/ \
    -I${STAGING_INCDIR}/bcm \
    -I${STAGING_INCDIR}/private/include/ \
    -I${STAGING_INCDIR}/public/include/ \
    -I${STAGING_INCDIR}/public/include/linux \
    -DSKY -DSKY_LED_AND_GPIO -DCONFIG_SKY_ETHAN "

inherit autotools coverity

do_configure[depends] += "virtual/kernel:do_install"
do_configure[depends] += "${MLPREFIX}runtime-libs:do_install"

do_install_append () {
        install -d ${STAGING_INCDIR}/
        install -m 0744 ${S}/sky_platform.h ${STAGING_INCDIR}
}

