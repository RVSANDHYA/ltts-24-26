SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-firewall"
RPROVIDES_${PN} = "hal-firewall"

DEPENDS += "halinterface sky-headers ccsp-common-library"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=firewallhal"

SRCREV_firewallhal = "${AUTOREV}"
SRCREV_FORMAT = "firewallhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/firewall"

CFLAGS_append = " -I${STAGING_INCDIR}/ccsp "

inherit autotools coverity
