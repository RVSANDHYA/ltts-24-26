SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-voice"
RPROVIDES_${PN} = "hal-voice"

DEPENDS_append_skyhub4-os-wanmanager = "virtual/kernel halinterface sky-headers ccsp-common-library runtime-libs"
DEPENDS_append_skyhub4 = "virtual/kernel halinterface sky-headers ccsp-common-library runtime-libs"
DEPENDS_append_skyhub4-l07 = "virtual/kernel halinterface sky-headers ccsp-common-library runtime-libs"
DEPENDS_append_skyhub4-l07-nowldm = "virtual/kernel halinterface sky-headers ccsp-common-library runtime-libs mdm-layer"
DEPENDS_append_skyhub45 = "virtual/kernel halinterface sky-headers ccsp-common-library runtime-libs mdm-layer"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=halvoice"

SRCREV_halvoice = "${AUTOREV}"
SRCREV_FORMAT = "halvoice"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/voice"


CFLAGS_append = " -I${STAGING_INCDIR}/ccsp \
    -I${STAGING_INCDIR} \
    -I${STAGING_INCDIR}/public/include \
    -I${STAGING_INCDIR}/private/include \
    -I${STAGING_INCDIR}/public/include/linux \
    -I ${STAGING_INCDIR}/userspace/private/include/ \
    -I ${STAGING_INCDIR}/userspace/public/include/ \
    -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
    -I ${STAGING_INCDIR}/bcm963xx \
    -I ${STAGING_INCDIR}/bcmdrivers/broadcom/include/bcm963xx \
    -I ${STAGING_INCDIR}/shared/opensource/include/bcm963xx \
    -DSKY -DBUILD_FOR_SKY -DSKY_RDKB \
"

do_configure[depends] += "${MLPREFIX}sky-headers:do_install \
                          ${MLPREFIX}runtime-libs:do_install \
                          virtual/kernel:do_install \
"	
do_install_append() {
    install -d ${D}/usr/ccsp/voipagent
    install -m 644 ${S}/telcovoip_config_default.json ${D}/usr/ccsp/voipagent/telcovoip_config_default.json
}
FILES_${PN} += "usr/ccsp/voipagent"
FILES_${PN} += "usr/ccsp/voipagent/telcovoip_config_default.json"

inherit cmake coverity
