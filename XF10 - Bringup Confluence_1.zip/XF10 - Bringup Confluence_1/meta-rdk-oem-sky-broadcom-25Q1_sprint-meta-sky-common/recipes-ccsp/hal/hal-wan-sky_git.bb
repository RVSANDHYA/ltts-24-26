SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-wan"
RPROVIDES_${PN} = "hal-wan"

DEPENDS += "rdkb-halif-wan sky-headers runtime-libs ccsp-common-library"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=wanhal"

SRCREV_wanhal = "${AUTOREV}"
SRCREV_FORMAT = "wanhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/wan"

CFLAGS_append = " \
               -I ${STAGING_INCDIR} \
               -I ${STAGING_INCDIR}/ccsp \
               -I ${STAGING_INCDIR}/sysevent \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/sky/userspace/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
               -DSKY_RDKB -DSKY -DJSON_RPC_SUPPORT_ENABLED \
               "

do_configure[depends] += "${MLPREFIX}sky-headers:do_install"

inherit autotools coverity
