SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-wifi"
RPROVIDES_${PN} = "hal-wifi"

FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

#halwifi required wlcsm library which is being built from runtime-libs. So
#added runtime-libs dependency for halwifi.
DEPENDS += "halinterface sky-headers ccsp-common-library virtual/kernel sky-wlan-bin runtime-libs"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=wifihal"

SRCREV_wifihal = "${AUTOREV}"
SRCREV_FORMAT = "wifihal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/wifi"

# Add flags to support mesh wifi if the feature is available.
CFLAGS_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'meshwifi', '-DENABLE_FEATURE_MESHWIFI', '', d)}"
CFLAGS_append = " -I${STAGING_INCDIR}/ccsp "
LDFLAGS_append = " \
        -lsecure_wrapper \
       "

INSANE_SKIP_${PN} += "dev-deps"


do_configure[depends] += "virtual/kernel:do_install ${MLPREFIX}sky-wlan-bin:do_install"

inherit autotools coverity
