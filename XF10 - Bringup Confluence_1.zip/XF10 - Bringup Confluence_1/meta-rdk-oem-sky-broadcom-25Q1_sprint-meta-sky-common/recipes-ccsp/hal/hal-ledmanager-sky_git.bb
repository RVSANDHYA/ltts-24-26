SUMMARY = "LED HAL for RDK components"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

PROVIDES = "hal-ledmanager"
RPROVIDES_${PN} = "hal-ledmanager"

DEPENDS += "virtual/kernel halinterface sky-headers runtime-libs hal-platform"

SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=ledmanager-hal"

SRCREV_ledmanager-hal = "${AUTOREV}"
SRCREV_FORMAT = "ledmanager-hal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/ledmanager-hal"

CFLAGS_append = " \
	-I${STAGING_INCDIR}/ccsp \
	-I ${STAGING_INCDIR}/bcm963xx/ \
	-I ${STAGING_INCDIR}/private/include \
"
CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', '-DLEDMGR_WEBCONFIG', '', d)} "

inherit autotools

do_configure[depends] += "virtual/kernel:do_install"
do_configure[depends] += "runtime-libs:do_install"

do_install_append () {
    # Config files and scripts
    install -d ${D}${exec_prefix}/rdk/rdkledmanager
    install -m 644 ${S}/config/led_config_it.json ${D}/usr/rdk/rdkledmanager
    install -m 644 ${S}/config/led_config_gb.json ${D}/usr/rdk/rdkledmanager
    if ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', 'true', 'false', d)}; then
         # JSON schemas
        install -m 644 ${S}/config/webconfig_led_config_it.json ${D}/usr/rdk/rdkledmanager
        install -m 644 ${S}/config/webconfig_led_config_gb.json ${D}/usr/rdk/rdkledmanager
        install -d ${D}/${sysconfdir}/rdk/schemas
        install -m 644 ${S}/config/led_config_brightness_schema.json ${D}/${sysconfdir}/rdk/schemas
        install -m 644 ${S}/config/led_config_full_schema.json ${D}/${sysconfdir}/rdk/schemas
        install -m 644 ${S}/config/led_config_onOff_schema.json ${D}/${sysconfdir}/rdk/schemas
    fi
}

FILES_${PN} = " \
   ${exec_prefix}/rdk/rdkledmanager/led_config_it.json \
   ${exec_prefix}/rdk/rdkledmanager/led_config_gb.json \
   ${exec_prefix}/lib/libledmanager.so.0.0.0 \
   ${exec_prefix}/lib/libledmanager.so.0 \
   ${bindir}/* \
"

FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', ' ${exec_prefix}/rdk/rdkledmanager/webconfig_led_config_gb.json ', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', ' ${exec_prefix}/rdk/rdkledmanager/webconfig_led_config_it.json ', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', ' ${sysconfdir}/rdk/schemas/led_config_brightness_schema.json ', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', ' ${sysconfdir}/rdk/schemas/led_config_full_schema.json ', '', d)}"
FILES_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'webconfigled', ' ${sysconfdir}/rdk/schemas/led_config_onOff_schema.json ', '', d)}"

PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"

