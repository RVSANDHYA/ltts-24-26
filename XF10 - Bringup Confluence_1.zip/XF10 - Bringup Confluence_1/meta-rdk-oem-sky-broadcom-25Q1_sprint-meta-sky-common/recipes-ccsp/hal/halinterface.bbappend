FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += "${@bb.utils.contains("DISTRO_FEATURES", "halversion3", '','file://sky_halinterface_wifi_apply.patch', d)} "

