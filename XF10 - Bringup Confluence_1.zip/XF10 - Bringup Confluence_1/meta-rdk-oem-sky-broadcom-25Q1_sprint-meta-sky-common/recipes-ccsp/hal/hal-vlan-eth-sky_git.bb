SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-vlan-eth"
RPROVIDES_${PN} = "hal-vlan-eth"

DEPENDS += "halinterface sky-headers ccsp-common-library runtime-libs"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=vlanethhal"

SRCREV_vlanethhal = "${AUTOREV}"
SRCREV_FORMAT = "vlanethhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/vlan_eth"

CFLAGS_append = " -I${STAGING_INCDIR}/ccsp \
                  -I${STAGING_INCDIR}/private/include/ "

inherit autotools coverity
