SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

PROVIDES = "hal-ethsw"
RPROVIDES_${PN} = "hal-ethsw"

DEPENDS += "virtual/kernel rdkb-halif-ethsw sky-headers runtime-libs json-c"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=ethswhal"

SRCREV_ethswhal = "${AUTOREV}"
SRCREV_FORMAT = "ethswhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/ethsw"

CFLAGS_append = " \
               -I ${STAGING_INCDIR}/ccsp \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/private/include/linux \
               -I ${STAGING_INCDIR}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR}/shared/opensource/include/bcm963xx \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/userspace/public/include \
               -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
               -I ${STAGING_INCDIR}/bcm963xx/ \
               "
do_configure[depends] += "virtual/kernel:do_install"
do_configure[depends] += "${MLPREFIX}sky-headers:do_install"

inherit autotools coverity
