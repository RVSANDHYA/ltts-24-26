SUMMARY = "HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../../LICENSE;md5=175792518e4ac015ab6696d16c4f607e"

FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

PROVIDES = "hal-cm"
RPROVIDES_${PN} = "hal-cm"

DEPENDS += "virtual/kernel rdkb-halif-cm"
DEPENDS += " utopia"

SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/device/sky/hub4;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=cmhal"

SRCREV_cmhal = "${AUTOREV}"
SRCREV_FORMAT = "cmhal"

PV = "${RDK_RELEASE}+git${SRCPV}"

S = "${WORKDIR}/git/source/cm"

CFLAGS_append = " -I${STAGING_INCDIR}/ccsp "
CFLAGS_append = " -I${STAGING_INCDIR}/sysevent "

inherit autotools

PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"

do_install_append () {
        install -d ${D}${sysconfdir}/sky
        install -m 0744 ${S}/scripts/factory_reset.sh ${D}${sysconfdir}/sky
}

FILES_${PN} += "${sysconfdir}/sky/factory_reset.sh"

