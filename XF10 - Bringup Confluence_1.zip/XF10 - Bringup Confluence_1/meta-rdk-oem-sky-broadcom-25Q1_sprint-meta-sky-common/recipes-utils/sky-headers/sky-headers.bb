DESCRIPTION = "SKY userspace libs"
LICENSE = "CLOSED"

DEPENDS += "openssl virtual/kernel"
SRC_URI_skyhub4 = "${BROADCOM_SDK_GIT}/router/63138/smp_apps;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4-os-wanmanager = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4-l07 = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4-l07-nowldm = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub45 = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

PR = "r1"
S = "${WORKDIR}/git"

SRCREV = "${AUTOREV}"
do_configure[noexec] = "1"
do_compile[noexec] = "1"

do_install() {
    install -d ${STAGING_INCDIR}/public/include
    install -d ${STAGING_INCDIR}/private/include

    cp -fr ${S}/public/include/* ${STAGING_INCDIR}/public/include/
    cp -fr ${S}/private/include/* ${STAGING_INCDIR}/private/include/
    cp -a ${S}/private/libs/xchg ${STAGING_INCDIR}/private/include
}
