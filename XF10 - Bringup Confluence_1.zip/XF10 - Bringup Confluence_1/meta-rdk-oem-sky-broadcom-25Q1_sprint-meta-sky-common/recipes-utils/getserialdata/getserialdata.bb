DESCRIPTION = "Serial Data Application"
LICENSE = "CLOSED"

FILEXTRAPATHS_prepend := "${THISDIR}/files:"

DEPENDS += " virtual/kernel sky-headers "

SRC_URI = "file://getserialdata.c"


CFLAGS_append = " \
               -I ${STAGING_INCDIR}/ \
	       -I ${STAGING_INCDIR}/bcm963xx/ \
               -I ${STAGING_INCDIR}/shared/opensource/include/bcm963xx/ \
	       -I ${THISDIR}/files \
               -DSKY -DCONFIG_SKY_ETHAN \ 
               "
inherit pkgconfig

do_configure[depends] += "virtual/kernel:do_install"

do_compile () {

    ${CC} ${WORKDIR}/getserialdata.c ${CFLAGS} -o ${WORKDIR}/getserialdata
}

do_install () {

    install -d ${D}${bindir}
    install -m 755 ${WORKDIR}/getserialdata  ${D}${bindir}   

}

FILES_${PN} += " \
        ${bindir}/* \
    "
