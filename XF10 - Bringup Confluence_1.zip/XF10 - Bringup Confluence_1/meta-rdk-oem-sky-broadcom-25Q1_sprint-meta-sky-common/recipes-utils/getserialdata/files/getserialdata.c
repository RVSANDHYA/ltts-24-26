/*****************************************************************************
 * Copyright, All rights reserved, for internal use only
*
* FILE: getserialdata.c
*
* PROJECT: SkyHub4 RDK
*
* MODULE: 
*
* Date Created: 14/03/2019
*
* Description:  This file contains utility functins to write the serial data
* the system CFG database at boot. 
*
* Notes:
*
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "getserialdata.h"

#define MAX_STRING_LENGTH 128
#define MAX_VAPS 16
#define PRIVATE_WIFI_2G 1
#define PRIVATE_WIFI_5G 2
#define MESH_WIFI_BH_2G 13
#define MESH_WIFI_BH_5G 14

/* Function Prototypes */
static int skyPlatform_serial_init(void);

static void writeFile(void);

int main(void)
{

    int retry=3;
    int rc;

    while (retry > 0)
    {
      if (skyPlatform_serial_init() >= 0)
          break;
      retry--;
    }

    if (retry > 0)
     {
         writeFile();
     } else
     {
        printf("ERROR : Could not read NVRAM\n");
     }
    return 0;
}


/** @brief write the serial information to /tmp/
 *         
 *  The function is called by the upper layers. /tmp/serial.tx file
 *  is created with the SERIAL structure. 
 *  
 *
 *  @return return none
 */

static void writeFile(void)
{

  char outString[MAX_STRING_LENGTH];
  int fd;
  int number;

  fd = open("/tmp/serial.txt", O_CREAT | O_WRONLY);
  if (fd < 0)
    {
      printf("ERROR - Could not write serial data file\r\n");
      return;
    }


  sprintf(outString,"BUILD=%s\r\n",SerialData.BuildString);
  write(fd,outString,strlen(outString));

  sprintf(outString,"BASEMAC=%s\r\n",SerialData.BaseMac);
  write(fd,outString,strlen(outString));

  sprintf(outString,"ADSLUSER=%s\r\n",SerialData.ADSLUser);
  write(fd,outString,strlen(outString));

  sprintf(outString,"ADSLPASS=%s\r\n",SerialData.ADSLPass);
  write(fd,outString,strlen(outString));

  sprintf(outString,"FACTORYSSID=%s\r\n", SerialData.factorySSID);
  write(fd,outString,strlen(outString));

  sprintf(outString,"WIFIPASSWORD=%s\r\n",SerialData.wifiPassword);
  write(fd,outString,strlen(outString));

  sprintf(outString,"SERIAL=%s\r\n",SerialData.factorySerialNumber);
  write(fd,outString,strlen(outString));

  SerialData.factorySerialNumber[2] = 0;
  number = (int)strtol(SerialData.factorySerialNumber, NULL, 16);
  if ((number == 0xCF) || (number == 0xD7))
  {
     sprintf(outString,"REGION=IT\r\nTIMEZONE=Europe/CET\r\n");
     write(fd,outString,strlen(outString));
  } else
  {
     sprintf(outString,"REGION=GB\r\nTIMEZONE=Europe/London\r\n");
     write(fd,outString,strlen(outString));
  }

  sprintf(outString,"HARDWAREVERSION=%s\r\n",SerialData.factoryHardwareVersion);
  write(fd,outString,strlen(outString));

  sprintf(outString,"MODEL=%s\r\n",SerialData.factoryModel);
  write(fd,outString,strlen(outString));


  /*
   * Set up all of the APs
   */
  for (int i=1;i<=MAX_VAPS;i++) {
	  if (i == PRIVATE_WIFI_2G) {
		  sprintf(outString,"WPSPIN=%s\r\n",SerialData.WPSPin);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"WPS_ENABLE=2\r\n");
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_RADIO_ID=%d\r\n", (i%2?0:1));
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_SSID=%s\r\n", SerialData.factorySSID);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"PSK_KEY=%s\r\n", SerialData.wifiPassword);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_ENABLE=1\r\n");
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_WMMEN=1\r\n");
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_HIDESSID=0\r\n");
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_SECMODE=WPA\r\n");
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_CYPHER=CCMP\r\n");
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_WPA_%d=3\r\n", i);
		  write(fd,outString,strlen(outString));

	  } else if (i == PRIVATE_WIFI_5G) {
		  sprintf(outString,"WPSPIN_%d=%s\r\n", i, SerialData.WPSPin);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"WPS_ENABLE_%d=2\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_RADIO_ID_%d=%d\r\n", i, (i%2?0:1));
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_SSID_%d=%s\r\n", i, SerialData.factorySSID);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"PSK_KEY_%d=%s\r\n", i, SerialData.wifiPassword);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_ENABLE_%d=1\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_WMMEN_%d=1\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_HIDESSID_%d=0\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_SECMODE_%d=WPA\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_CYPHER_%d=CCMP\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_WPA_%d=3\r\n", i);
		  write(fd,outString,strlen(outString));
	  } else {
		  sprintf(outString,"WPSPIN_%d=%s\r\n", i, SerialData.WPSPin);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"WPS_ENABLE_%d=0\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_RADIO_ID_%d=%d\r\n", i, (i%2?0:1));
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_SSID_%d=OutOfService\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"PSK_KEY_%d=1234567890\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_ENABLE_%d=0\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_WMMEN_%d=0\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_HIDESSID_%d=1\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_SECMODE_%d=WPA\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_CYPHER_%d=CCMP\r\n", i);
		  write(fd,outString,strlen(outString));
		  sprintf(outString,"AP_WPA_%d=3\r\n", i);
		  write(fd,outString,strlen(outString));
	  }
  }
  close(fd);
}

/** @brief Perform the IOCTL to the lower drivers
 *         
 *  The function is called by the upper layers. To perform
 *  the specific IOCTL
 *  
 *  @return return ioctl result. 0 for OK, negative for fail.
 */

static int platform_do_ioctl(int boardIoctl,BOARD_IOCTL_ACTION action,char *string,unsigned int strLen,unsigned int offset,void *data)
{
    BOARD_IOCTL_PARMS ioctlParms;
    int boardFd = 0;
    int rc = -1;  // ERROR STATE 
    
    boardFd = open(BOARD_DEVICE_NAME, O_RDWR);

    if ( boardFd != -1 )
    {
        ioctlParms.string = string;
        ioctlParms.strLen = strLen;
        ioctlParms.offset = offset;
        ioctlParms.action = action;
        ioctlParms.buf    = data;
        ioctlParms.result = -1;

        rc = ioctl(boardFd, boardIoctl, &ioctlParms);
        close(boardFd);
     }
     
   return rc;
}


/** @brief Initialise the files for serial number
 *         
 *  The function is called by the upper layers. /tmp/serial.dat file
 *  is created with the SERIAL structure. If it exists, then nothing is 
 *  done.
 *
 *  @return return ioctl result. 0 for OK, negative for fail.
 */

static int skyPlatform_serial_init(void) 
{ 
    int rc;
    memset(&SerialData,0,sizeof(SerialData));
    rc = platform_do_ioctl(BOARD_IOCTL_FLASH_READ, SERIALISATION,(char *)&SerialData, sizeof(SERIALISATION_DATA), 0, 0); 

    return rc; 
}


