DESCRIPTION = "SKY userspace libs"
LICENSE = "CLOSED"

#DEPENDS += "openssl virtual/kernel libsyswrapper sky-wlan-bin sky-headers"
DEPENDS_skyhub4 += "openssl virtual/kernel libsyswrapper sky-wlan-bin json-c"
DEPENDS_skyhub4-os-wanmanager += "openssl virtual/kernel libsyswrapper sky-wlan-bin json-c sky-headers json-schema-validator wldm"
DEPENDS_skyhub4-l07           += "openssl virtual/kernel libsyswrapper sky-wlan-bin json-c sky-headers json-schema-validator wldm"
DEPENDS_skyhub4-l07-nowldm += "openssl virtual/kernel libsyswrapper sky-wlan-bin json-c sky-headers"
DEPENDS_skyhub45 += "openssl virtual/kernel libsyswrapper sky-wlan-bin json-c sky-headers wldm"


#SRC_URI_skyhub4-os-wanmanager = "${BROADCOM_SDK_GIT}/router/63138/smp_apps;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4 = "${BROADCOM_SDK_GIT}/router/63138/smp_apps;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4-os-wanmanager = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4-l07 = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub4-l07-nowldm = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"
SRC_URI_skyhub45 = " ${BROADCOM_SDK_GIT}/router/smpapps/L07/bcmsw;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

do_configure[depends] += "${MLPREFIX}sky-headers:do_install"


S = "${WORKDIR}/git/"

SRCREV = "${AUTOREV}"

EXTRA_OECMAKE += "-DBUILD_LIBS=ON"
EXTRA_OECMAKE += "-DBUILD_TEST_APP=ON"

inherit cmake pkgconfig

require recipes-ccsp/ccsp/ccsp_oem.inc

CFLAGS_append = " \
               -I ${S}/public/include \
               -I ${S}/public/include/linux \
               -I ${S}/private/include \
               -I ${S}/private/include/linux \
               -I ${S}/private/libs/wlcsm/include \
               -I ${S}/private/libs/omcisdk/core/inc \
               -I ${S}/private/libs/omcisdk/core/onudata/ \
               -I ${S}/private/libs/omcisdk/core/handler/ \
               -I ${S}/private/libs/omcisdk/core/pm/ \
               -I ${S}/private/libs/omcisdk/core/pm_drv/ \
               -I ${S}/private/libs/omcisdk/cmninc \
               -I ${STAGING_INCDIR}/ \
               -I ${STAGING_INCDIR}/net \
               -I ${STAGING_INCDIR}/bdmf/framework/ \
               -I ${STAGING_INCDIR}/bdmf/system/ \
               -I ${STAGING_INCDIR}/bdmf/system/sim/ \
               -I ${STAGING_INCDIR}/rdpa_gpl \
               -I ${STAGING_INCDIR}/rdpa_user \
               -I ${STAGING_INCDIR}/bcm963xx \
               -I ${STAGING_INCDIR}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR}/bcmdrivers/broadcom/char/pmd/impl1/fw_img/ \
               -I ${STAGING_INCDIR}/bcmdrivers/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR}/shared/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR}/shared/opensource/include/drv/phys/ \
               -I ${STAGING_INCDIR}/shared/opensource/flash/ \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/userspace/public/include/ \
               -I ${STAGING_INCDIR}/private/include/ \
               -I ${STAGING_INCDIR}/public/include/ \
               -I ${STAGING_INCDIR}/userspace/private/include/wl \
               -I ${STAGING_INCDIR}/userspace/private/include/devctrl_if/ \
               -I ${STAGING_INCDIR}/json-c \
               -I ${S}/public/include/linux/ \
               -I ${S}/private/libs/mdk/cdk/include/ \
               -I ${S}/private/libs/mdk/bmd/include/ \
               -I ${S}/private/libs/mdk/phy/include/ \
               -I ${S}/private/libs/mdk/cdk/arch/ \
               -DSKY_RDKB \
               -DSKY \
               -DBRCM_VOICE_SUPPORT \
               ${BCM_FLAGS} \
               "
PR = "r1"

CFLAGS_append  = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', '-DFEATURE_RDKB_WAN_MANAGER', '', d)}"

do_configure_prepend () {

    rm -rf ${S}/private/libs/mdk/cdk/include/cdk/arch/
    rm -rf ${S}/private/libs/mdk/phy/include/phy/chip/
    rm -rf ${S}/private/libs/mdk/phy/sym/chip/
    rm -rf ${S}/private/libs/mdk/bmd/include/bmdi/arch/

    mkdir ${S}/private/libs/mdk/cdk/include/cdk/arch/
    mkdir ${S}/private/libs/mdk/phy/include/phy/chip/
    mkdir ${S}/private/libs/mdk/phy/sym/chip/
    mkdir ${S}/private/libs/mdk/bmd/include/bmdi/arch/

    cp ${S}/private/libs/mdk/phy/PKG/chip/bcm5464/*.h ${S}/private/libs/mdk/phy/include/phy/chip/
    cp ${S}/private/libs/mdk/cdk/PKG/arch/robo/*.h ${S}/private/libs/mdk/cdk/include/cdk/arch/
    cp ${S}/private/libs/mdk/cdk/PKG/arch/robo/shell/*.h ${S}/private/libs/mdk/cdk/include/cdk/arch/
    cp ${S}/private/libs/mdk/bmd/PKG/arch/robo/*.h ${S}/private/libs/mdk/bmd/include/bmdi/arch/
    cp ${S}/private/libs/mdk/phy/PKG/chip/bcm5464/bcm5464_sym.c ${S}/private/libs/mdk/phy/sym/chip/

}


FILES_${PN} += " \
        ${libdir}/* \
"

INSANE_SKIP_${PN} += "dev-deps"

FILES_SOLIBSDEV = ""
INSANE_SKIP_${PN} += "dev-so"
PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"
