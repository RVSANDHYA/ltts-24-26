SUMMARY = "OpenSSL library from Broadcom L07 SDK including patches for Voice"

LICENSE = "openssl"
LIC_FILES_CHKSUM = "file://LICENSE;md5=d343e62fc9c833710bbbed25f27364c8"


SRC_URI = "https://www.openssl.org/source/openssl-1.1.1b.tar.gz"
SRC_URI[md5sum] = "4532712e7bcc9414f5bce995e4e13930"
SRC_URI[sha256sum] = "5c557b023230413dfb0756f3137a13e6d726838ccd1430888ad15bfb2b43ea4b"

SRC_URI += "file://armcap.patch"
SRC_URI += "file://lib_config.patch"

INHIBIT_PACKAGE_DEBUG_SPLIT = "1"

S = "${WORKDIR}/openssl-1.1.1b"

do_configure() {    
    ./Configure linux-bcmarm \
        --prefix=${S} \
        --openssldir=${S} \
          no-hw shared \
          no-md2 \
          no-mdc2 \
          no-rc2 \
          no-idea \
          no-unit-test \
          no-cast \
          no-bf \
          -DL_ENDIAN \
          -DHAVE_CRYPTODEV \
          --with-rand-seed=devrandom \
          -Os \
          -march=armv7-a \
          -fomit-frame-pointer \
          -mno-thumb-interwork \
          -mabi=aapcs-linux \
          -marm \
          -fno-common \
          -ffixed-r8 \
          -msoft-float \
          -D__ARM_ARCH_7A__ \
          -Werror=return-type \
          -Werror=uninitialized \
          -Wno-date-time
}

do_install_append() {
    install -d ${D}${libdir}/openssl-1.1.1b
    install -m 755 ${S}/libcrypto.so.1.1 ${D}${libdir}/openssl-1.1.1b
    install -m 755 ${S}/libssl.so.1.1 ${D}${libdir}/openssl-1.1.1b
    ln -s -r ${D}${libdir}/openssl-1.1.1b/libcrypto.so.1.1 ${D}${libdir}/openssl-1.1.1b/libcrypto.so
    ln -s -r ${D}${libdir}/openssl-1.1.1b/libssl.so.1.1 ${D}${libdir}/openssl-1.1.1b/libssl.so 
}

INSANE_SKIP_${PN} = "dev-so"
FILES_${PN} += "${libdir}/openssl-1.1.1b/*"
