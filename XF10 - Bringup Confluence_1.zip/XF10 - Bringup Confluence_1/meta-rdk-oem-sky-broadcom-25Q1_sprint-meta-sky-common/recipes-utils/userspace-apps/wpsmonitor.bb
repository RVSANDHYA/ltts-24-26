DESCRIPTION = "wps-monitor application"
LICENSE = "CLOSED"

DEPENDS += " virtual/kernel runtime-libs rdk-logger utopia userspace-apps"

SRC_URI = "git://${RDK_GIT}/rdk/rdkb/components/sdk/devices/sky/hub4/wpsmonitor;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

INSTALL_DIR="${D}"
EXT_CPU_ARCH_NAME="arma9"
EXTRALIBDIR="."
#PROD_TAG
#PARALLEL_MAKE=""

S = "${WORKDIR}/git/"

BUILD_DIR="${WORKDIR}"
SRCREV = "${AUTOREV}"
EXTRA_OEMAKE = ' BUILD_DIR="${WORKDIR}" INSTALL_DIR="${INSTALL_DIR}" ARCH="arm" EXT_CPU_ARCH_NAME="${EXT_CPU_ARCH_NAME}" EXTRALIBDIR="${EXTRALIBDIR}" CC="${CC}" '

inherit systemd logging externalsrc pkgconfig
LDFLAGS += " -L ${STAGING_LIBDIR} "
ISSYSTEMD = "${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'true', 'false', d)}"
TARGET_CC = "-Wl, --no-undefined"
TARGET_CFLAGS = " \
                -I ${S}/include/bcmcrypto/ \
                -I ${STAGING_INCDIR} \
                -I ${STAGING_INCDIR}/private/include/ \
                -I ${STAGING_INCDIR}/private/userspace/include/wlcsm \
                -I ${STAGING_INCDIR}/bcmdrivers/broadcom/include/bcm963xx \
                -I ${STAGING_INCDIR}/shared/opensource/include/bcm963xx \
                -I ${STAGING_INCDIR}/bcm963xx \
                -I ${STAGING_INCDIR}/bdmf/system/linux \
                -I ${STAGING_INCDIR}/syscfg \
                -I ${STAGING_INCDIR}/sysevent \
                -I ${STAGING_INCDIR}/userspace/private/include/wl/ \
                -I ${STAGING_INCDIR}/userspace/private/include/ \
                -I ${STAGING_INCDIR}/bcmdrivers/broadcom/include \
                ${BCM_FLAGS} -DBUILD_FOR_SKY -DBCM_RDP -DBCMUPNP -DBCMWPA2 -DBCMWPSAP -DBCMWPSAPSTA -DDSLCPE_NOCMS -DBRCM_UTILITY_CMDS -DBRCM_WLAN -DINCLUDE_BREAKPAD \
                -DDSLCPE_NG -DDSLCPE_WLCSM_EXT -D__linux__ -DLINUX -DMDM_SHARED_MEM  -D_REENTRANT -DSKY -DSKY_BFD_IMPLEMENTATION  \
                -DWPS_ADDCLIENT_WWTP -DWPS_AP_M2D -DWPS_ROUTER -DWPS_UPNP_DEVICE \
                -fPIC -fno-common -fstack-protector-all -Wall -Werror=return-type -Werror=uninitialized -Wno-date-time \
               "

#-DDSLCPE
#-DSKY -DBUILD_FOR_SKY -DVOIP_POC -DSKY_RDKB -DDSLCPE_NOCMS \
#-DBCMUPNP -DBCMWPA2 -DBCMWPSAP -DBCMWPSAPSTA -DCHIP_63138 -DCONFIG_SKY_MODEL_SR200 -DDSLCPE_1905 -DDSLCPE_ENDIAN \
#-DDSLCPE_NG -DDSLCPE_WLCSM_EXT -D__linux__ -DLINUX -DNOCMS -DSKY -DUPNP_WFA_DEVICE \
#-DWPS_ADDCLIENT_WWTP -DWPS_AP_M2D -DWPS_ROUTER -DWPS_UPNP_DEVICE 
#-I ${STAGING_INCDIR}/public/include/
#-I ${STAGING_INCDIR}/public/include/linux


inherit breakpad-wrapper
DEPENDS+= " breakpad breakpad-wrapper"

BREAKPAD_BIN_append = " wps_monitor"

LDFLAGS_append_skyhub4-os-wanmanager = " -lbreakpadwrapper -lpthread -lstdc++"
LDFLAGS_append_skyhub4 = " -lbreakpadwrapper -lpthread -lstdc++"
LDFLAGS_append_skyhub4-l07 = " -lbreakpadwrapper -lpthread -lstdc++"

# generating minidumps
PACKAGECONFIG_append_skyhub4-os-wanmanager = " breakpad"
PACKAGECONFIG_append_skyhub4 = " breakpad"
PACKAGECONFIG_append_skyhub4-l07 = " breakpad"


do_configure[depends] += "virtual/kernel:do_install"

do_compile() {
    echo building wps_monitor
    oe_runmake -C ${S} wps_monitor
}

do_clean () {
    echo cleaning wps_monitor
    oe_runmake -C ${S} clean
}

do_install () {
    install -d ${D}${bindir}
    install -d ${D}${libdir}
    install -m 755 ${S}/libwps.so ${D}${libdir}/
    install -m 755 ${S}/wps_monitor ${D}${bindir}/
}

SOLIBS = ".so"
FILES_SOLIBSDEV = ""

FILES_${PN} += " \
    ${libdir}/libwps.so \
    ${bindir}/wps_monitor \
    "

#SYSTEMD_SERVICE_${PN} += " ${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'wps.service', '', d)}"
#FILES_${PN}_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'systemd', '${systemd_unitdir}/system/wps.service', '', d)}"

PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"

