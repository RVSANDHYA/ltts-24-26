DESCRIPTION = "SKY imagetool"
LICENSE = "CLOSED"

DEPENDS += "smplinux sky-headers"
SRC_URI = "git://${RDK_GIT}/rdk/rdkb/components/sdk/devices/sky/hub4/imagetool;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

S = "${WORKDIR}/git/private/apps/"

SRCREV = "${AUTOREV}"

inherit cmake pkgconfig

CFLAGS_append = " \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/private/include/linux \
               -I ${STAGING_INCDIR}/ \
               -I ${STAGING_INCDIR}/bdmf/framework/ \
               -I ${STAGING_INCDIR}/rdpa_gpl \
               -I ${STAGING_INCDIR}/bcm963xx \
               -I ${STAGING_INCDIR}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR}/shared/opensource/include/bcm963xx \
               -I ${STAGING_INCDIR}/sky/shared/opensource/include \
               -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
               -I ${STAGING_INCDIR}/sky/userspace/private/include/ \
               -I ${WORKDIR}/git/public/include/linux/ \
               -I ${WORKDIR}/git/public/include/ \
               -I ${WORKDIR}/git/private/include/ \
               "
PR = "r1"

do_configure[depends] += "virtual/kernel:do_install ${MLPREFIX}sky-headers:do_install"

FILES_${PN} += " \
        ${bindir}/* \
"
