DESCRIPTION = "Recipe to install prebuilt memaccess binary and to create its symlinks"
LICENSE = "CLOSED"
FILEXTRAPATHS_prepend := "${THISDIR}/files:"

SRC_URI += "https://${NEXUS_SKY_HUB4}/tools/memaccess/2.1/memaccess-2.1.tar.gz;name=memaccess-2_1"
SRC_URI[memaccess-2_1.md5sum] = "4630956ee930e5665ec2e4b5a95de894"
SRC_URI[memaccess-2_1.sha256sum] = "21bf259d90a3cb1a4fca5e50c66dbac4f06540cb3e1777efcf0cc2ec0222053e"

S = "${WORKDIR}"

do_configure[noexec] ="1"
do_compile[noexec] ="1"


do_install() {
    install -d ${D}${bindir}

    #Install memaccess binary.
    install -m 0755 ${S}/memaccess ${D}${bindir}
   
    # Creating symbolic links to memaccess application.
    # We have created sw and dw symlinks to memaccess. 
    # These commands needs to be available in the device,
    # for the HW compliance test.
    ln -sf ${bindir}/memaccess ${D}${bindir}/dw
    ln -sf ${bindir}/memaccess ${D}${bindir}/sw

}


# Avoid QA Issue: No GNU_HASH in the elf binary
INSANE_SKIP_${PN} = "ldflags"
INSANE_SKIP_${PN}-dev = "ldflags"
INSANE_SKIP_${PN} += "already-stripped"

FILES_${PN} = " \
    ${bindir}/* \
    "
