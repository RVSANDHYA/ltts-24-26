DESCRIPTION = "Recipe to install prebuilt mcpd binary and its associated shared lib"
LICENSE = "CLOSED"
FILEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += "https://${NEXUS_SKY_HUB4}/tools/sky-mcpd-app/2.1/sky-mcpd-app-2.1.tar.gz;name=sky-mcpd-app-2.1"
SRC_URI[sky-mcpd-app-2.1.md5sum] = "8eea7cac7c32c5222f942ddf37c8b8e2"
SRC_URI[sky-mcpd-app-2.1.sha256sum] = "4d222de4851b51d37a2ddcdd2d534336ac9cc3619ee23583b76a00a46962357d"

#Include configuration and service file.
SRC_URI += "file://sky-mcpd-app.service"
SRC_URI += "file://mcpd.conf"

S = "${WORKDIR}"

do_configure[noexec] ="1"
do_compile[noexec] ="1"

inherit systemd

do_install() {
    install -d ${D}${bindir}
    install -d ${D}${libdir}
    install -d ${D}${sysconfdir}
    install -d ${D}${systemd_unitdir}/system

    #Install mcpd binary.
    install -m 0755 ${S}/mcpd ${D}${bindir}
    install -m 0755 ${S}/mcpctl ${D}${bindir}
    install -m 0755 ${S}/libbcmmcast.so ${D}${libdir}/

    install -m 0755 ${S}/mcpd.conf ${D}${sysconfdir}
    install -m 0755 ${S}/sky-mcpd-app.service ${D}${systemd_unitdir}/system
}

SYSTEMD_SERVICE_${PN} += "sky-mcpd-app.service"
SYSTEMD_AUTO_ENABLE_${PN} = "enable"

# Avoid QA Issue: No GNU_HASH in the elf binary
INSANE_SKIP_${PN} += "already-stripped"

SOLIBS = ".so"
FILES_SOLIBSDEV = ""


FILES_${PN} = " \
    ${bindir}/* \
    ${libdir}/* \
    ${sysconfdir}/* \
    ${systemd_unitdir}/system/* \
    "
