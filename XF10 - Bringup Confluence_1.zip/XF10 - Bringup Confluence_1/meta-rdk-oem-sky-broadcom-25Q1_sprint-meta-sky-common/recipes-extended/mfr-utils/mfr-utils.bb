SUMMARY = "Sky mfr utilities"
LICENSE = "CLOSED"

FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += " \
	file://mfr-utils.tgz \
"

S = "${WORKDIR}"

SRCREV = "${AUTOREV}"

do_configure[noexec] = "1"
do_compile[noexec] = "1"

do_install () {

    install -d ${D}${bindir}
    install -d ${D}${base_libdir}

    install -m 0755 ${WORKDIR}/bin/* ${D}${bindir}/
    install -m 0755 ${WORKDIR}/lib/* ${D}${base_libdir}/
}

INSANE_SKIP_${PN} += "already-stripped"
INSANE_SKIP_${PN} += "ldflags"
INSANE_SKIP_${PN}-dev += "ldflags"

FILES_${PN} += " \
	${bindir}/* \
	${base_libdir}/* \
"
