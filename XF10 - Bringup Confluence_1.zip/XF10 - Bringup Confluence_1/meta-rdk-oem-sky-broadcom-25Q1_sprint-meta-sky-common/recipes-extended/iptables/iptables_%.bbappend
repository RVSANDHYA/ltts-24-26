SRC_URI += "file://0001-add-port-triggering-support.patch"

EXTRA_OECONF_remove = " --with-kernel=${STAGING_KERNEL_DIR}"
