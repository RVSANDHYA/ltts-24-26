EXTRA_OECONF_append = " --enable-ert --enable-platform --enable-nonCM"

CFLAGS_append = " \
    -I=${includedir}/libsafec/ \
    "

FILES_${PN} += "${prefix}/ccsp/"
FILES_${PN} += "/etc/*"
FILES_${PN} += "${tdkdir}/*"
