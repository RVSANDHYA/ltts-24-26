FILESEXTRAPATHS_prepend := "${THISDIR}/${BPN}:"

SYSINTB_DEVICE = "sky/hub4"

