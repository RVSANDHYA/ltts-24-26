FILESEXTRAPATHS_prepend := "${THISDIR}:"

SRC_URI_append_class-target = " \
           file://0005-opkg_sky_changes.patch "

PACKAGECONFIG_append_class-target = " curl ssl-curl openssl" 
