
PACKAGES =+ " mtd-utils-flash "

FILES_mtd-utils-flash = "${sbindir}/flash*"