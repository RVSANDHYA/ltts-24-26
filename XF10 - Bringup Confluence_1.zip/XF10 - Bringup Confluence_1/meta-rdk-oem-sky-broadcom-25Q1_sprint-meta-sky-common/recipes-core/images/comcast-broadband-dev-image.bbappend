IMAGE_INSTALL_append = " \
    packagegroup-rdk-wanmanager \
"

