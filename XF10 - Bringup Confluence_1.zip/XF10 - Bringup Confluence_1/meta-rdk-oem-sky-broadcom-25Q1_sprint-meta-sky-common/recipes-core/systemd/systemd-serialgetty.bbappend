FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += "file://serial-getty@.service"

do_install_append () {
    install -d ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/serial-getty@.service ${D}${systemd_unitdir}/system/
}
 
RDEPENDS_${PN} = "systemd"

# This is a machine specific file
FILES_${PN} = "${systemd_unitdir}/system/*.service ${sysconfdir}"