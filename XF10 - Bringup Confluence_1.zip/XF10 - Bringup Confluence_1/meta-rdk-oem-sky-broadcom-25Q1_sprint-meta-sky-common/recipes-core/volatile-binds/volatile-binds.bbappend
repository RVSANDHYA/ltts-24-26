#
# Patch template for volatile-binds services. We need to add a dependency
# on a different service.
#
FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
# Adding services to do mount-copybind to specific files and directories.
VOLATILE_BINDS = "\
    /var/volatile/lib /var/lib\n\
"
VOLATILE_BINDS_append = "\
    /var/volatile/dibbler /opt/dibbler\n\
    /tmp/dibbler /etc/dibbler\n\
    /tmp/dropbear /etc/dropbear\n\
    /var/volatile/media /media\n\
    /var/volatile/spoolcron /var/spool/cron\n\
    /var/volatile/www /www\n\
    /var/volatile/xupnp /etc/xupnp\n\
    /var/volatile/minidumps /minidumps size=2m\n\
    /var/volatile/flash /mnt/flash\n\
    /var/volatile/wlan/nvram /etc/wlan/nvram/\n\
    /var/volatile/locale /usr/lib/locale\n\
"

VOLATILE_BINDS_append_daisy = "\
    /tmp/locale.conf /etc/locale.conf\n\
"

VOLATILE_BINDS_append_morty = "\
    /tmp/locale.conf /etc/default/locale\n\
    /var/volatile/share/locale /usr/share/locale\n\ 
"
