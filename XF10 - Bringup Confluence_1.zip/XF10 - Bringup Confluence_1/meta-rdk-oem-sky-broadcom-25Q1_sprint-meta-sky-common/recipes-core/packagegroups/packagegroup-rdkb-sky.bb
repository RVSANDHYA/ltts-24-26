SUMMARY = "Sky RDKB package group"

LICENSE = "CLOSED"

inherit packagegroup

PACKAGES = "packagegroup-rdkb-sky"

# Sky RDKB components
RDEPENDS_packagegroup-rdkb-sky_append = " \
    ${BRCM_WIFI} \
    runtime-libs \
    userspace-apps \
    sky-userspace \
    getserialdata \
    hal-wan-sky \
    sky-wlmngr-prebuilt \
    sky-memaccess-app \
    ecryptfs-utils \
    wpsmonitor \
    sky-mcpd-app \
    mapt-util \
    wifi-enrolee-pin-app \
    voice \
    voicecli \
    tinyproxy \
    hal-dsl-sky \
    json-c \
    hal-xtm-sky \
    hal-vlan-eth-sky \
    sp-oops-extract \
    "
RDEPENDS_packagegroup-rdkb-sky_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' json-schema-validator', '', d)} "
RDEPENDS_packagegroup-rdkb-sky_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'fwupgrade_manager', ' hal-fwupgrade-sky', '', d)} "
RDEPENDS_packagegroup-rdkb-sky_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'ppp rp-pppoe', '', d)} "
RDEPENDS_packagegroup-rdkb-sky_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', ' hal-ledmanager-sky', '', d)} "

BRCM_WIFI ?= "${@bb.utils.contains("DISTRO_FEATURES", "broadcom-wifi-src", "broadcom-wifi-src", "sky-wlan-bin", d)}"

RDEPENDS_packagegroup-rdkb-sky_append_morty = " \
    tzcode \
    "

#RDEPENDS_packagegroup-rdkb-sky_append_daisy = " \
#    tinyproxy \
#    "

