SUMMARY = "Sky RDKB WanManager package group"

LICENSE = "CLOSED"

inherit packagegroup

PACKAGES = "packagegroup-rdk-wanmanager"

RDEPENDS_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' rdk-wanmanager rdk-vlanmanager json-hal-lib', '', d)} "
RDEPENDS_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'ipoe_health_check', 'ipoe-health-check', '', d)} "
RDEPENDS_${PN}_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_xdsl_ppp_manager', 'rdkxdslmanager rdk-ppp-manager', '', d)} "

