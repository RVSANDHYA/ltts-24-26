
# Opensource components used in RDK-B
RDEPENDS_packagegroup-rdk-oss-broadband_append = "\
	mtd-utils-flash \
	e2fsprogs \
	e2fsprogs-e2fsck \
	e2fsprogs-mke2fs \
	e2fsprogs-tune2fs \
	dibbler-server \
	dibbler-client \
	\
"
RDEPENDS_packagegroup-rdk-oss-broadband_append_daisy = "\
    STLport \
"

RDEPENDS_packagegroup-rdk-oss-broadband_remove = "\
	wireless-tools \
	net-snmp-client \
	net-snmp-server \
	net-snmp-mibs \
	net-snmp-server-snmpd \
"
