#GWPROVAPP = "ccsp-gwprovapp-dsl"
#CM_AGENT = "ccsp-dsl-agent"
# TODO : Have to uncomment above lines when dsl agent is ready
GWPROVAPP = " "
CM_AGENT = " "

# Removing components which are not required for hub4
RDEPENDS_packagegroup-rdk-ccsp-broadband_remove = " \
    ccsp-mta-agent \
    ccsp-mta-agent-ccsp \
    ccsp-moca \
    ccsp-moca-ccsp \
    ccsp-tr069-pa \
    ccsp-tr069-pa-ccsp \
    ccsp-hotspot \
    ccsp-hotspot-kmod \
    hal-moca \
    touchstone \
    icontrolkey \
    hostapd \
    ccsp-snmp-pa \
    ccsp-snmp-pa-ccsp \
"
# ccsp-home-security is required for XLE WNXL11BWL
RDEPENDS_packagegroup-rdk-ccsp-broadband_remove += " ${@bb.utils.contains('MACHINE_IMAGE_NAME', 'WNXL11BWL', ' ', ' ccsp-home-security ',d)}"

RDEPENDS_packagegroup-rdk-ccsp-broadband_append = " \
    tzdata \
    crashupload \
    quagga-ripd \
    quagga-ripngd \
    quagga \
    liboauth \
    ${@bb.utils.contains('DISTRO_FEATURES', 'lxy',' lxy ',' cpg-libs ',d)} \
    cpgu \
    cpgc \
    mountutils \
    sshkeys \
    lnfcerts \
    hostapd \
    harvester \
    icontrolkey \
    syslog-ng \
    ccsp-adv-security \
    cujo-agent-oem \
    ntp \
    gw-lan-refresh \
    eglibc \
    eglibc-utils \
    conntrack-tools \
    rdm \
    rbus-device \
"

#RDEPENDS_packagegroup-rdk-ccsp-broadband_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'rdktelcovoicemanager', '', d)} "
#RDEPENDS_packagegroup-rdk-ccsp-broadband_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', 'rdktelcovoicemanager', 'ccsp-telcovoip-agent', d)} "
RDEPENDS_packagegroup-rdk-ccsp-broadband_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'fwupgrade_manager', 'rdk-fwupgrade-manager', '', d)} "
RDEPENDS_packagegroup-rdk-ccsp-broadband_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdk_ledmanager', 'rdk-ledmanager', '', d)} "

