SUMMARY = "Sky RDKB telco voice package group"

LICENSE = "CLOSED"

inherit packagegroup

PACKAGES = "packagegroup-rdkb-sky-voice"

RDEPENDS_${PN} = "                      \
                 rdktelcovoicemanager   \
                 ifacemanager-telcovoice \
                 voice  \
                 voicecli           \
                 json-hal-lib           \
                 json-schema-validator  \
                 cjson   \
                 "

