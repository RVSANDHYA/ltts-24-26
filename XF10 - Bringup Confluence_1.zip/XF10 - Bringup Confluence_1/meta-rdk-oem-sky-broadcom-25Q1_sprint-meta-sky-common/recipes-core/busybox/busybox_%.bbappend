FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

DEPENDS += "rdk-logger"

CFLAGS += " \
    -I${STAGING_INCDIR} \
      -DFEATURE_SUPPORT_RDKLOG \
"

SRC_URI += " \
   file://busybox-sendarp.patch \
   file://50default \
   file://syslogdYearAdd.patch \
   file://syslogdYearAdd.cfg \
   file://nc_enable.cfg \
   file://addfile.cfg \
   "
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://Add-Hub4-Specific-Patch-For-Udhcpc.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://SkyHub-SocketMark.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://Add-Sky-Option43-Validation-For-Udhcpc.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://Fix-Rebind-Timeout-For-Udhcpc.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://Add-Release-Pckt-and-Remove-IP-Req-After-Lease.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://sky_ihc_renew.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://No-Release-When_WanMgr_Crashes.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://sky_udhcpc_rdklogs_enable.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://sky-no-v4-release.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://sky_udhcpc_interface_specific_logs.patch ', '', d)}"
SRC_URI += " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_wan_manager', ' file://sky_udhcpc_discover_delay_interval_modification.patch ', '', d)}"

do_install_append() {
        install -d ${D}${sysconfdir}/udhcpc.d
        install -m 0755 ${WORKDIR}/50default ${D}${sysconfdir}/udhcpc.d
        rm  ${D}${systemd_unitdir}/system/busybox-syslog.service
        rm  ${D}${systemd_unitdir}/system/busybox-klogd.service
}

FILES_${PN}-syslog_remove += "${systemd_unitdir}/system/busybox-syslog.service ${systemd_unitdir}/system/busybox-klogd.service"

SYSTEMD_SERVICE_${PN}-syslog_remove += "busybox-syslog.service"

