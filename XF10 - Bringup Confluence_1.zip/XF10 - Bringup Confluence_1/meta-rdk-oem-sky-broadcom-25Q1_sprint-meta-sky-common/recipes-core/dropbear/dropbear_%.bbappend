FILESEXTRAPATHS_prepend := "${THISDIR}/dropbear:"
SRC_URI += "file://dropbear@.service "

EXTRA_OECONF += " --disable-lastlog "

#Enable dropbear service for the LAN side SSH access.
do_install_append () {
    
    if [ -f ${D}${systemd_unitdir}/system/dropbear.socket ]; then
        install -d ${D}${systemd_unitdir}/system/sockets.target.wants
        ln -sf ${D}${systemd_unitdir}/system/dropbear.socket ${D}${systemd_unitdir}/system/sockets.target.wants/dropbear.socket
    fi

    install -d ${D}${systemd_unitdir}/system
    install -m 0755 ${WORKDIR}/dropbear@.service ${D}${systemd_unitdir}/system/
}

SYSTEMD_SERVICE_${PN} = "dropbear.socket"
SYSTEMD_AUTO_ENABLE_${PN} = "enable"
