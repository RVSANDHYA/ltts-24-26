FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += "\
    file://SUPPORTED \
    file://locale.conf \
"

do_install_append () {
    rm -rf ${D}/usr/include/nfs
    install -d ${D}${libdir}/locale
    install -d ${D}${datadir}/i18n
    install -m 644 -p -D ${WORKDIR}/locale.conf ${D}${sysconfdir}/locale.conf
    install -m 644 ${WORKDIR}/SUPPORTED ${D}${datadir}/i18n/SUPPORTED
}


FILES_${PN} += "${sysconfdir}/locale.conf"
FILES_${PN} += "${libdir}/locale"
FILES_${PN} += "${datadir}/i18n/SUPPORTED"