FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

do_install_append () {
    # Install all the headers needed for sky userspace application
    install -d ${STAGING_INCDIR}/userspace/public/include
    install -d ${STAGING_INCDIR}/userspace/private/include
    # To store wlcsm required header files.
    install -d ${STAGING_INCDIR}/userspace/private/include/wl
    install -d ${STAGING_INCDIR}/userspace/private/include/proto
    install -d ${STAGING_INCDIR}/userspace/private/include/devctrl_if
    install -d ${STAGING_INCDIR}/sky/shared/opensource/include
    install -d ${STAGING_INCDIR}/sky/userspace/public/include
    install -d ${STAGING_INCDIR}/sky/userspace/private/include
    cp -fr ${S}/sky/shared/opensource/include/* ${STAGING_INCDIR}/sky/shared/opensource/include
    cp -fr ${S}/sky/userspace/public/include/* ${STAGING_INCDIR}/sky/userspace/public/include
    cp -fr ${S}/sky/userspace/private/include/* ${STAGING_INCDIR}/sky/userspace/private/include
    install -m 644 ${S}/userspace/public/include/*.h ${STAGING_INCDIR}/userspace/public/include
    install -m 644 ${S}/userspace/private/include/*.h ${STAGING_INCDIR}/userspace/private/include
    install -m 644 ${S}/shared/opensource/include/bcm963xx/boardparms.h ${STAGING_INCDIR}/userspace/private/include
    install -m 644 ${S}/userspace/private/libs/wlcsm/include/*.h ${STAGING_INCDIR}/userspace/private/include
    install -m 644 ${S}/bcmdrivers/broadcom/char/wlcsm_ext/impl1/include/*.h ${STAGING_INCDIR}/userspace/private/include
    # wlcsm required headers.
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl26/main/src/include/*.h ${STAGING_INCDIR}/userspace/private/include/wl
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl26/main/src/shared/bcmwifi/include/*.h ${STAGING_INCDIR}/userspace/private/include/wl
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl26/main/src/router/shared/*.h ${STAGING_INCDIR}/userspace/private/include/wl
    install -m 644 ${S}/userspace/private/apps/wlan/wlcsm_dm/include/*.h ${STAGING_INCDIR}/userspace/private/include/wl
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl26/main/src/common/include/devctrl_if/*.h ${STAGING_INCDIR}/userspace/private/include/devctrl_if
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl26/main/src/common/include/proto/*.h ${STAGING_INCDIR}/userspace/private/include/proto/
}
