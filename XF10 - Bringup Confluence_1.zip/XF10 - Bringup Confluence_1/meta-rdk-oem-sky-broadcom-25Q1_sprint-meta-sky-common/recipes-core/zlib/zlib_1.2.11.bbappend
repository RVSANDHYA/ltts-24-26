# Removing the patch for skyhub since validation is pending.
# Once verified patch will be applied back to skyhub devices as part of RDKB-44622

SRC_URI_remove += " file://CVE-2018-25032_fix.patch"
