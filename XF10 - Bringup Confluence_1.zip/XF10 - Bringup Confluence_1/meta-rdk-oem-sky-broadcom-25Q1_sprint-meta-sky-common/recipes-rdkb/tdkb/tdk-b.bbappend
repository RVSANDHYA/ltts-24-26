DEPENDS_remove = " hal-cm ccsp-cm-agent hal-mta ccsp-mta-agent"
RDEPENDS_${PN}_remove = " ccsp-cm-agent"
