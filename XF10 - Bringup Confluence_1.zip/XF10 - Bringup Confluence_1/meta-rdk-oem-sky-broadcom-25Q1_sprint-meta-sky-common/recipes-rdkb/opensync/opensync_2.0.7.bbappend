FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
SRC_URI_append_tchxb8 += "file://wifi_apply.patch;patchdir=../platform/rdk"
SRC_URI_append_tchxb8 += "file://wifi_context_init.patch;patchdir=../platform/rdk"
