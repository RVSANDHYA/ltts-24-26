FILESEXTRAPATHS_prepend := "${THISDIR}/files:"
SRC_URI_append += "file://dbus_reboot_hang.patch"

