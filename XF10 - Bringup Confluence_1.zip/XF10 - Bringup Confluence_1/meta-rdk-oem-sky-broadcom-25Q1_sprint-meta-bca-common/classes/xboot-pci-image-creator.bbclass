# To create monolithic image using image_builder utility for Sky Xboot.

# Set model name as MACHINE_IMAGE_NAME
MODEL_NAME = "${MACHINE_IMAGE_NAME}"
DTB_NAME   = "${BRCM_SOC_PROFILE}.dtb"
PCI_CONFIG_PATH = "${RDKROOT}/meta-rdk-oem-sky-broadcom/meta-bca-common/classes/xboot-pciconfigs"
PCI_CONFIG_FILE   = "${BRCM_SOC_PROFILE}.ini"
SCRIPT_PATH = "${RDKROOT}/generic/xboot/image_builder"
IMG_STAGING_PATH = "${SCRIPT_PATH}/images"
IMAGE_NAME_PREFIX ="${MODEL_NAME}"
PACKAGETYPE = "PCI"

DEPENDS_append += " xboot-imagebuilder virtual/kernel u-boot-mkimage-native xboot-bl-bins"

#To do: Commenting the prepare_image to avoid Kernel compilation in eSDK workspace
do_create_xboot_image[depends] += "${@bb.utils.contains('WITHIN_EXT_SDK','1','','virtual/kernel:do_prepare_image',d)}"

do_create_xboot_image[depends] += " xboot-imagebuilder:do_install"
do_create_xboot_image[depends] += " xboot-bl-bins:do_install"
do_create_xboot_image[lockfiles] = "${TMPDIR}/create_xboot_image.lock"

# BL firmare configuration.
BL_FW_CONFIG = "BL_FIRMWARECONFIG.ini"
BL_BINS = "${RDKROOT}/generic/xboot/bl_bins"

fakeroot do_create_bl_fw() {
    echo "creating bootloader firmware binary"
    mkdir -p ${IMG_STAGING_PATH}
    ${SCRIPT_PATH}/CreateFirmwareSection.py --config ${PCI_CONFIG_PATH}/${BL_FW_CONFIG} --imagePath ${BL_BINS} --outfile ${IMG_STAGING_PATH}/bl_firmware.bin
}


fakeroot do_create_minimal_fs() {
    #create minimal filesystem
    mkdir -p ${IMAGE_ROOTFS}/minidumps
    mkdir -p ${IMAGE_ROOTFS}/rdklogs
    mkdir -p ${IMAGE_ROOTFS}/nvram
    mkdir -p ${IMAGE_ROOTFS}/nvram2
    mkdir -p ${IMAGE_ROOTFS}/data

    echo  "tmpfs           /var        tmpfs   size=128m         0       0" >> ${IMAGE_ROOTFS}/etc/fstab
    echo  "tmpfs           /mnt        tmpfs   size=16k,noexec                 0    0" >> ${IMAGE_ROOTFS}/etc/fstab
    echo  "tmpfs           /rdklogs    tmpfs   mode=0755,nodev,nosuid,size=30M 0    0" >> ${IMAGE_ROOTFS}/etc/fstab
    echo  "tmpfs           /minidumps  tmpfs   mode=0777,nodev,nosuid,size=2M  0    0" >> ${IMAGE_ROOTFS}/etc/fstab
}

fakeroot do_create_xboot_image() {

    kernel="${DEPLOY_DIR_IMAGE}/vmlinux-${MACHINE}.stripped.bin"
    dtb="${DEPLOY_DIR_IMAGE}/${DTB_NAME}"

    if [ -f ${IMGDEPLOYDIR}/${IMAGE_NAME}${IMAGE_NAME_SUFFIX}.squashfs-xz ]; then
        rootfs="${IMGDEPLOYDIR}/${IMAGE_NAME}${IMAGE_NAME_SUFFIX}.squashfs-xz"
    else
        # Yocto  mksquashfs tools replaces ${DATE} with None.
        SQUASH_IMAGE_NAME=`echo ${IMAGE_NAME} | sed -E 's/_[0-9]+s/_Nones/g'`
        rootfs="${IMGDEPLOYDIR}/${SQUASH_IMAGE_NAME}${IMAGE_NAME_SUFFIX}.squashfs-xz"
    fi

    # Bootargs
    if [ "${@bb.utils.contains("IMAGE_FEATURES", "prod", 'true', 'false', d)}" = "true" ]
    then
        SKY_IMAGE_VARIANT="PROD"
        # Leave an empty space in bootargs list.
        bootargs_conf=" console=null test=mmcblk "
    else
        SKY_IMAGE_VARIANT="DEV"
        # Leave an empty space in bootargs list.
        bootargs_conf=" test=mmcblk "
    fi

    # Generate uboot uImage vmlinux.bin
    mkimage -T kernel -A ARM -O Linux -a 0x00608000 -e 0x00608000 -n Linux -C none -d ${kernel} ${DEPLOY_DIR_IMAGE}/vmlinux.uboot
    kerneluboot="${DEPLOY_DIR_IMAGE}/vmlinux.uboot"

    mkdir -p ${IMG_STAGING_PATH}

    cp -f "${kerneluboot}" ${IMG_STAGING_PATH}/kernel.bin
    cp -f "${rootfs}" ${IMG_STAGING_PATH}/rootfs.bin
    cp -f "${dtb}" ${IMG_STAGING_PATH}/dtb.bin
    touch ${IMG_STAGING_PATH}/version.txt
    echo ${MODEL_NAME} > ${IMG_STAGING_PATH}/version.txt

    # Generate bootargs.txt
    echo "$bootargs_conf" > ${IMG_STAGING_PATH}/bootargs.txt

    # xboot configuration.
    echo "" > ${IMG_STAGING_PATH}/xboot_config.txt

    # Include BL Firmware.
    if [ -d ${BL_BINS} ];then
        do_create_bl_fw
    fi


    # Creating Monolithic image
    cd ${SCRIPT_PATH}
    ${SCRIPT_PATH}/build_image.py \
        --config ${PCI_CONFIG_PATH}/${PCI_CONFIG_FILE} \
        --Manifest_ModelName ${MODEL_NAME} \
        --Manifest_CodeVersion ${IMAGE_NAME} \
        --Manifest_PackageType ${PACKAGETYPE} \
        --outfile ${DEPLOY_DIR_IMAGE}/${IMAGE_NAME}.bin

    rm -rf ${IMG_STAGING_PATH}

    # create sym links to the images
    ln -sf "${IMAGE_NAME}.bin" "${DEPLOY_DIR_IMAGE}/${IMAGE_LINK_NAME}.bin"

    md5sum ${DEPLOY_DIR_IMAGE}/${IMAGE_NAME}.bin >> ${DEPLOY_DIR_IMAGE}/${IMAGE_NAME}.bin.md5sum
}

do_create_xboot_image[nostamp] = "1"
do_create_minimal_fs[nostamp] = "1"

addtask create_minimal_fs after do_rootfs before do_build
addtask do_create_xboot_image before do_build after do_image_complete
