FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI_append = "file://01_Rename_APIs_To_Fix_Symbol_conflict_SKYH4_3823.patch \
                  file://02_Enable_Trailing_Characters_Flag.patch \
                                 "
