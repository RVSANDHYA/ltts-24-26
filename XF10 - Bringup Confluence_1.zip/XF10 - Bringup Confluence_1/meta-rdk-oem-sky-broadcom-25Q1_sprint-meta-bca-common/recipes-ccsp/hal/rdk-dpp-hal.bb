SUMMARY = "DPP HAL for RDK CCSP components"
HOMEPAGE = "http://github.com/belvedere-yocto/hal"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://../LICENSE;md5=5d50b1d1fb741ca457897f9e370bc747"

PROVIDES = "rdk-dpp-hal"
RPROVIDES_${PN} = "rdk-dpp-hal"

DEPENDS += "cjson"

DEPENDS += "openssl halinterface"
SRC_URI = "${RDKB_CCSP_ROOT_GIT}/hal/rdk-wifi-hal;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=rdk-dpp-hal"

SRCREV_rdk-dpp-hal = "${AUTOREV}"
SRCREV_FORMAT = "rdk-dpp-hal"

PV = "${RDK_RELEASE}+git${SRCPV}"
S = "${WORKDIR}/git/feature_dpp/"

# Add flags to support mesh wifi if the feature is available.
CFLAGS_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'meshwifi', '-DENABLE_FEATURE_MESHWIFI', '', d)}"
CFLAGS_append = " -I=${includedir}/ccsp "

inherit autotools coverity
