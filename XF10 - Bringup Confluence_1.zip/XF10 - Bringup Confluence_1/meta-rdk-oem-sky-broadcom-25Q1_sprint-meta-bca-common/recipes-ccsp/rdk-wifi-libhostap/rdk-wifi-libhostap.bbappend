FILESEXTRAPATHS_prepend:="${THISDIR}/files:"

CFLAGS_append = " \
    -DCONFIG_DRIVER_BRCM \
    -DCONFIG_DRIVER_BRCM_MAP \
"

SRC_URI += "file://openssl_no_md4-2_9.patch"

LD_FLAGS_append += " -L${STAGING_LIBDIR}/openssl-1.1.1b -L${STAGING_LIBDIR}"