FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"
CFLAGS_append = " -DRDKLOGGER_SUPPORT_WIFI -D_WIFI_AX_SUPPORT_ -DWIFI_HAL_VERSION_3"
CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'dfs', '-DCONFIG_DFS', '', d)}"

SRC_URI += " \
             file://CcspWifi.conf \
           "

do_install_append() {
    install -d ${D}${sysconfdir}
    install -d ${D}${systemd_unitdir}/system/ccspwifiagent.service.d
    install -D -m 0644 ${WORKDIR}/CcspWifi.conf ${D}${systemd_unitdir}/system/ccspwifiagent.service.d/CcspWifi.conf
    # Config files and scripts
    install -d ${D}${exec_prefix}/ccsp/wifi
    install -m 755 ${S}/scripts/radiohealth.sh ${D}/usr/ccsp/wifi/radiohealth.sh
    install -m 755 ${S}/scripts/radiohealth_log.sh ${D}/usr/ccsp/wifi/radiohealth_log.sh
}

FILES_${PN}_append = " \
            ${sysconfdir} \
            ${systemd_unitdir}/system/ccspwifiagent.service.d/CcspWifi.conf \
            ${exec_prefix}/ccsp/wifi/radiohealth.sh \
            ${exec_prefix}/ccsp/wifi/radiohealth_log.sh \
                     "
