DEPENDS += " rdk-wifi-libhostap rdk-wifi-hal"

CFLAGS_append += "\ 
             -DWIFI_HAL_VERSION_3 \
             -DRDK_ONEWIFI \
             -DFEATURE_SUPPORT_PASSPOINT \
             -D_WIFI_AX_SUPPORT_ \
"
CFLAGS_remove = "-DWIFI_CAPTIVE_PORTAL"

LDFLAGS_append = " \
    -lutctx \
"

RDEPENDS_${PN} += " rdk-wifi-libhostap rdk-wifi-hal" 

