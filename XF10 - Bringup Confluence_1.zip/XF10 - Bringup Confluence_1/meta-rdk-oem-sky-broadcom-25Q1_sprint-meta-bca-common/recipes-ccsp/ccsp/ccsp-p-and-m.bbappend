do_compile_prepend() {
    if ${@bb.utils.contains('DISTRO_FEATURES', 'bridgeUtilsBin', 'true', 'false', d)}; then
        sed -i '2i <?define _BRIDGE_UTILS_BIN_=True?>'  ${S}/config-arm/TR181-USGv2.XML
    fi
}
