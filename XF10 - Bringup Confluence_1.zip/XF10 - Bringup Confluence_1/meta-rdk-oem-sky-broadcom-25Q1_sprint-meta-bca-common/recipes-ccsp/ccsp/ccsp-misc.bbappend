DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','halinterface','',d)}"
DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','hal-bridgeutil','',d)}"

DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','breakpad','',d)}"
DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','breakpad-wrapper','',d)}"

DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','ovs-agent','',d)}"
EXTRA_OECONF += "${@bb.utils.contains("DISTRO_FEATURES", "bridgeUtilsBin", " --enable-bridgeUtilsBin=yes ", " ", d)}"


LDFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin',' -lOvsAgentApi ',' ',d)}"
LDFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin',' -lbreakpadwrapper ',' ',d)}"
LDFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin',' -lpthread ',' ',d)}"
LDFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin',' -lstdc++ ',' ',d)}"
LDFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin',' -lm ',' ',d)}"
LDFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin',' -lcjson ',' ',d)}"

BREAKPAD_BIN_append += "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','bridgeUtils','',d)}"

# generating minidumps
inherit breakpad-wrapper
PACKAGECONFIG_append = "${@bb.utils.contains('DISTRO_FEATURES','bridgeUtilsBin','breakpad',' ',d)}"
