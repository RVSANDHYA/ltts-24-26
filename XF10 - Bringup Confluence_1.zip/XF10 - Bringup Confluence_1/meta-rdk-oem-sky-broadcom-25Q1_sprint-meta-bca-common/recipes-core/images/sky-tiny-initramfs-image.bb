SUMMARY = "Initramfs image for kernel"
DESCRIPTION = "Small image capable of booting a device."
# LICENSE = "CLOSED"

BAD_RECOMMENDATIONS += "busybox-syslog"

# Do not pollute the initrd image with rootfs features
IMAGE_FEATURES = ""

#Keep extra language files from being installed
IMAGE_LINGUAS = ""

# Core minimal initramfs parameters  
IMAGE_FSTYPES = "${INITRAMFS_FSTYPES}"
IMAGE_TYPES = "${INITRAMFS_FSTYPES}"

INITRAMFS_FSTYPES_remove = "cpio.gz tar.gz"
INITRAMFS_FSTYPES = "cpio.xz"

inherit core-image

IMAGE_ROOTFS_SIZE = "4096"
IMAGE_ROOTFS_EXTRA_SPACE = "0"

ROOTFS_BOOTSTRAP_INSTALL = ""

DEPENDS_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'sbom', 'zstd-native', '', d)}"

PACKAGE_INSTALL = "util-linux-mount liblzma busybox udev ${ROOTFS_BOOTSTRAP_INSTALL} e2fsprogs"
do_install[nostamp] = "1"
do_rootfs[nostamp] = "1"
do_build[nostamp] = "1"


fakeroot update_rootfs() {
    install -m 755 ${THISDIR}/${PN}/sky-init ${IMAGE_ROOTFS}
    cd "${IMAGE_ROOTFS}"

    #create the required directories
    mkdir -p proc sys system tmp

    # Remove all unneeded files
    for file in "lib/"*; do
        case $(basename "$file") in
        ld.so*|ld-*.so) ;;
        libc*.so*) ;;
        libm*.so*) ;;
        libn*.so*) ;;
        libdl*.so*) ;;
        libblk*.so*) ;;
        libpthread*.so*) ;;
        libr*.so*) ;;
        libtinfo*.so*) ;;
        libu*.so*) ;;
        *) rm -fv "$file" || true ;;
        esac
    done

    rm -rfv etc/udhcpc.d
    rm -rfv etc/systemd/system/multi-user.target.wants/
    rm -rfv usr/lib/opkg
    rm -rfv usr/lib/libkm*
    rm -rfv lib/rdk lib/security lib/modules
    rm -rfv lib/libnss_dns-2.24.so
    rm -rfv lib/libnsl*
    rm -rfv lib/libresolv*
    rm -rfv lib/libnss_compat*
    rm -rfv lib/libnss_files*
    rm -rfv lib/udev
    rm -rfv usr/lib/libacl*
    rm -rfv usr/lib/libattr*
    rm -rfv lib/libnss_dns*
    rm -rfv rdklogger
    rm -rf fss
    rm -fv rdklogctrl
    rm -fv /usr/bin/rdklogctrl
}

ROOTFS_POSTPROCESS_COMMAND += "update_rootfs; "

VCC_IMAGE_FILE_LIST = "sky-tiny-initramfs-image-skysr213.cpio.xz"
