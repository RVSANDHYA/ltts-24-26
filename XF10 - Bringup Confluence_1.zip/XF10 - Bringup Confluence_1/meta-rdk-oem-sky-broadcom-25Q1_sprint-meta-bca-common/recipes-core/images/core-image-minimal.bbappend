SUMMARY = "Core Minimal Image"

inherit rdk-image

#PCI image creation class.
inherit xboot-pci-image-creator

IMAGE_FEATURES_remove = "read-only-rootfs"

ROOTFS_PKGMANAGE_BOOTSTRAP  = "run-postinsts"

IMAGE_INSTALL += " ${ROOTFS_PKGMANAGE_BOOTSTRAP} \
                   ${CORE_IMAGE_EXTRA_INSTALL} \
                   kernel-modules \
                   bca-bootassist \
                "

BB_HASH_IGNORE_MISMATCH = "1"

IMAGE_NAME[vardepsexclude] = "DATETIME"
