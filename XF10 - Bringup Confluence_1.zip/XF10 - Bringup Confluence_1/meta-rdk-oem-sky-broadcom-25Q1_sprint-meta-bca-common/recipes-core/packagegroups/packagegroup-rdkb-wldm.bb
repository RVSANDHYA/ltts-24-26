SUMMARY = "Sky RDKB package group"
LICENSE = "CLOSED"


inherit packagegroup
PACKAGES = "packagegroup-rdkb-wldm"



# Sky RDKB components
RDEPENDS_packagegroup-rdkb-wldm_append = " \
        wldm \
        "
