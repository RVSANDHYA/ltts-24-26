SUMMARY = "BCA Common Package Group"
LICENSE = "CLOSED"


inherit packagegroup
PACKAGES = "packagegroup-bca-common"

# BOOPS
RDEPENDS_packagegroup-bca-common_append = " \
        boops-k \
        boops \
        "

#Boot assistant scripts and services.
RDEPENDS_packagegroup-bca-common_append = " \
       bca-bootassist \
       "

# BCA Userspace Libraries/Applications.
RDEPENDS_packagegroup-bca-common_append = " \
    bca-userspace-libs-prebuilts \
    bca-userspace-libs \
    bca-userspace-apps-prebuilts \
    bca-userspace-apps \
    getserialdata \
"

# BCA WLAN Prebuilts
RDEPENDS_packagegroup-bca-common_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'broadcom-wifi-src', '', ' bca-wlan-prebuilt ', d)}"

# Voice.
RDEPENDS_packagegroup-bca-common_append = " ${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager', ' bca-mdm-layer bca-dal-layer bca-voice bca-voicecli ', '', d)}"
