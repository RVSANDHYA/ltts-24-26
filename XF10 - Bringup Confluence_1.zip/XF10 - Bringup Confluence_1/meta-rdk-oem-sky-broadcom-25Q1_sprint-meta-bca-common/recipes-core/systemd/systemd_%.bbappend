FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += " file://timedatectl_sync_status.patch "

do_install_append () {    
    rm -f ${D}${base_libdir}/udev/rules.d/80-drivers.rules
}

# Add timedated to enable timedatectl
PACKAGECONFIG[timedated] = "--enable-timedated"

# Add localed to enable localectl
PACKAGECONFIG[localed] = "--enable-localed"
