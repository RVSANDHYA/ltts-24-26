#!/bin/bash


#Get serialisation data
base_mac=`cat /tmp/serial.txt | grep BASEMAC | cut -d "=" -f 2 | tr -d '\r\n' | sed 's/\(..\)/\1:/g' | cut -c -17`
ssid=`cat /tmp/serial.txt | grep FACTORYSSID | cut -d "=" -f 2 | tr -d '\r\n'`
wifipassword=`cat /tmp/serial.txt | grep WIFIPASSWORD | cut -d "=" -f 2 | tr -d '\r\n'`
wps_pin=`cat /tmp/serial.txt | grep "WPSPIN=" | cut -d "=" -f 2 | tr -d '\r\n'`
#region=`cat /tmp/serial.txt | grep REGION | cut -d "=" -f 2 | tr -d '\r\n'`
#checkFile is used for factory restore
checkFile="/data/.sky_config_set.done"
#default_file_orig sky generic configuration file for nvram
default_file_orig="/etc/sky/default_cfg.txt"
#nvram_cfg_file is the backup configuration to be used for checksum
nvram_cfg_file="/data/nvram_cfg.txt"
#nvram_restore_cfg is used for wifi restore nvram
nvram_restore_cfg="/data/.nvram_restore_cfg.txt"
#nvram_wireless_user_cfg is the default user configuration nvram file
nvram_bcm_user_cfg="/data/.user_nvram.setting"
nvram_fr_flag="/data/.do_fr_on_boot"

nvram_cfg_update_var () {
    local var=$1
    local value=$2
    local dst_file=$3
    sed -i "s/$var=.*/$var=$value/" $dst_file
}

cp $default_file_orig $nvram_restore_cfg

nvram_cfg_update_var wl0_ssid ${ssid} $nvram_restore_cfg
nvram_cfg_update_var wl0_wpa_psk $wifipassword $nvram_restore_cfg

nvram_cfg_update_var wl1_ssid ${ssid} $nvram_restore_cfg
nvram_cfg_update_var wl1_wpa_psk $wifipassword $nvram_restore_cfg

nvram_cfg_update_var wl2_ssid ${ssid} $nvram_restore_cfg
nvram_cfg_update_var wl2_wpa_psk $wifipassword $nvram_restore_cfg

nvram_cfg_update_var wps_device_pin $wps_pin $nvram_restore_cfg

# Once we have done the configuration on first boot, touch the done
# file for not executing this configuration setup.
if [ ! -e $checkFile ]; then
     # Copy the file to populate the nvram
     cp $nvram_restore_cfg $nvram_cfg_file
     touch $checkFile 
     echo "sky default wireless configuration done"
fi


# Default Mesh APs
echo "Defaulting 2.4GHz Mesh APs"
sed -i -- 's/wl0.6_ssid=.*$/wl0.6_ssid=we.piranha.off/' $nvram_cfg_file
sed -i -- 's/wl0.6_wpa_psk=.*$/wl0.6_wpa_psk=welcome8/' $nvram_cfg_file
sed -i -- 's/wl0.6_bss_enabled=.*$/wl0.6_bss_enabled=1/' $nvram_cfg_file

echo "Defaulting 5GHz Mesh APs"
sed -i -- 's/wl1.6_ssid=.*$/wl1.6_ssid=we.piranha.off/' $nvram_cfg_file
sed -i -- 's/wl1.6_wpa_psk=.*$/wl1.6_wpa_psk=welcome8/' $nvram_cfg_file
sed -i -- 's/wl1.6_bss_enabled=.*$/wl1.6_bss_enabled=1/' $nvram_cfg_file


#if .user_nvram.setting is not present,  loadfile nvram_cfg.txt
if [  ! -e $nvram_bcm_user_cfg ]; then
    echo "$nvram_bcm_user_cfg  is not present, load the file $nvram_cfg_file"
    touch $nvram_bcm_user_cfg
    nvram load -t  $nvram_cfg_file
    nvram commit
fi

#if .do_fr_on_boot is present, do nvram reset.
if [ -e $nvram_fr_flag ]; then
    echo "$nvram_fr_flag  is present, doing nvram reset"
    cp $nvram_restore_cfg $nvram_cfg_file
    nvram load -t  $nvram_cfg_file
    nvram commit
    rm -rf  $nvram_fr_flag
fi

# Make sure all nvram_cfg changes are written to nvram
sync

ifconfig wl0 up
wl -i wl0 up

# Settings For wifi compliance
wl -i wl0 spatial_policy 1
wl -i wl0 phy_lesi 1

ifconfig wl1 up
wl -i wl1 up

# SKYH4-1418:5G Interface disappering due to PCI issue.

interface_up=$(wl -i wl1 ver)
SOURCE="wl1:"
PCIE_BOOT_STATUS_FILE=/data/pcie_boot_status
COUNTER=$[$(cat $PCIE_BOOT_STATUS_FILE)]

if echo "$interface_up" | grep -q "$SOURCE"; then
  echo "5G WiFi available - continuing"
  echo 0 > $PCIE_BOOT_STATUS_FILE
else
  if [ $COUNTER -gt 3 ]
  then
      #Do Nothing , continue in this state, so that we can get the status of the box
       echo "`date +"%y%m%d-%T.%6N"` SKYHUB4_PCIE_BRING_UP_FAILED :: 5G wifi not UP!, MAX RETRY 3 reached." >> /nvram2/logs/Consolelog.txt.0
       echo "BAD KERNEL Boot.......,PCIE NOT UP!"
  else
      COUNTER=$[$(cat $PCIE_BOOT_STATUS_FILE) + 1]
       echo "`date +"%y%m%d-%T.%6N"` SKYHUB4_PCIE_BRING_UP_FAILED :: 5G wifi not UP!,REBOOTING..." >> /nvram2/logs/Consolelog.txt.0
       echo "5G WiFi not available - rebooting!"
#      /sbin/reboot
  fi
fi

# Settings For wifi compliance
wl -i wl1 spatial_policy 1
wl -i wl1 phy_lesi 1

# Set dongle console polling interval to 100ms
dhd -i wl0 dconpoll 100
dhd -i wl1 dconpoll 100
dhd -i wl2 dconpoll 100
