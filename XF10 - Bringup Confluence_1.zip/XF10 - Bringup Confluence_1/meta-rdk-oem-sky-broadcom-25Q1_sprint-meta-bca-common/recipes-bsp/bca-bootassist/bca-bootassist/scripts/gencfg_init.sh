#!/bin/bash

echo 1 > /proc/sys/net/ipv4/ip_dynaddr
echo 1 > /proc/sys/net/ipv6/conf/all/forwarding

L3WANIFACE_NAME=erouter0

#To get serialised data.
if [ -e /usr/bin/xboot_imagetool ];then
    /usr/bin/xboot_imagetool -c dump-serial-data
else
    getserialdata
fi

BOX_TYPE=`cat /etc/device.properties | grep -inr "BOX_TYPE" | cut -d "=" -f 2`

#Get base mac address from serialisation data.
base_mac=`cat /tmp/serial.txt | grep BASEMAC | cut -d "=" -f 2 | tr -d '\r\n' | sed 's/\(..\)/\1:/g' | cut -c -17`
mac_offset=1
if [ "$BOX_TYPE" = "WNXL11BWL" ];
then
    eth0_mac=`cat /tmp/serial.txt | grep -inr ETHERNET_MAC_ADDRESS | cut -d "=" -f 2 | tr -d '\r\n' | sed 's/\(..\)/\1:/g' | cut -c -17`
    eth1_mac=`cat /tmp/serial.txt | grep -inr ETHERNET1_MAC_ADDRESS | cut -d "=" -f 2 | tr -d '\r\n' | sed 's/\(..\)/\1:/g' | cut -c -17`
fi

ip link set mtu 1500 dev bcmsw

for intf in `(cd /sys/class/net ; echo eth*)`
do
  #update mac address.
  if [ "$BOX_TYPE" = "WNXL11BWL" ];
  then
      case $intf in
          eth0)
              ip link set dev $intf address $eth0_mac
              ;;
          eth1)
              ip link set dev $intf address $eth1_mac
              ;;
     esac
  else
      ip link set dev $intf address $base_mac
  fi
  if ifconfig $intf up >/dev/null 2>/dev/null
  then
    if type tmctl 2> /dev/null > /dev/null
    then
      tmctl porttminit --devtype 0 --if $intf --flag 1
    fi
  fi
done

#erouter0 dummy bridge.
brctl addbr $L3WANIFACE_NAME
last=`echo $base_mac | cut -f6 -d ':'`
last=`echo $(( 16#$last + 3 ))`
newbase_mac="${base_mac:0:15}`printf '%X\n' $last`"
echo "Setting erouter0 mac to $newbase_mac"
ip link set $L3WANIFACE_NAME address $newbase_mac
ip link set dev $L3WANIFACE_NAME up

# Bringup the wireless interfaces
if [ -e /etc/sky/wireless_bringup.sh ]
then
    /etc/sky/wireless_bringup.sh
fi

[ -e /bin/ecbd ] && ecbd&

if [ -e /bin/wlssk ] 
then
	wlssk&
	sleep 10
fi

# calling "rtpolicy" to apply RT settings for the kthreads and apps that have already started
if [ -e /usr/bin/rtpolicy ]
then
	rtpolicy auto ALL >> /var/rtpolicy.log 2>&1
fi

if [ -e /usr/bin/mcpd ]
then
    /usr/bin/mcpd &
fi

# set tcp_be_liberal when acceleartion is enabled
if [ -e /proc/sys/net/netfilter/nf_conntrack_tcp_be_liberal ]; then
    echo 1 > /proc/sys/net/netfilter/nf_conntrack_tcp_be_liberal
fi
#Start log monitor script
if [ -e /etc/sky/monitor_log.sh ]
then
    /etc/sky/monitor_log.sh &
fi
