#!/bin/sh
KERNELVER=`uname -r`
WLNANDMFG_FILE=/proc/nvram/wl_nand_manufacturer
if [ -e $WLNANDMFG_FILE ]; then
SYSTEM_INFO_INDICATOR=$(cat  $WLNANDMFG_FILE )
else
SYSTEM_INFO_INDICATOR=0
fi
SYSTEM_UBOOT=$(($SYSTEM_INFO_INDICATOR & 8))
if [ $SYSTEM_UBOOT -gt 0 ]; then
	MFG_NVRAM_MODE_FILEPATH=/proc/environment/mfg_nvram_mode
else
	MFG_NVRAM_MODE_FILEPATH=/proc/brcm/blxparms/mfg_nvram_mode
fi
if  [ -e $MFG_NVRAM_MODE_FILEPATH ]; then
	mfg_nvram_mode=$(cat $MFG_NVRAM_MODE_FILEPATH)
else
	mfg_nvram_mode=0
fi

MTDOOPS_PART=/proc/environment/mtdoops
if [ -e $MTDOOPS_PART ]; then
	mtdoops=$(cat $MTDOOPS_PART)
	rec_size=65536
	log_shift=$(gunzip -c /proc/config.gz | grep CONFIG_LOG_BUF_SHIFT | cut -d '=' -f 2)
	rec_size=$((2**$log_shift))
	mtdsize=$(cat /proc/mtd  | grep $mtdoops | cut -d ' ' -f3)
	if [ "$mtdsize" != "" ]; then   
		mtdsize=$((0x${mtdsize}))
		if [ $rec_size -gt $mtdsize ]; then
			rec_size=$mtdsize
		fi
	else
		mtdoops=""
	fi		
else
	mtdoops=""
fi

trap "" 2


case "$1" in
	start)
		echo "Loading drivers and kernel modules... "
		echo

# Syntax
# line
# conditon
# condition
# for
# -BUILD_FEATURE_A
# will
# -!BUILD_FEATURE_B
# will

# mtdoops
if [ "$mtdoops" != "" ]; then
echo "load mtdoops driver: mtd partition $mtdoops record size $rec_size"
fi

# bcmlibs
insmod /lib/modules/$KERNELVER/extra/bcmlibs.ko  

# KNVRAM
insmod /lib/modules/$KERNELVER/extra/bcm_knvram.ko  

# UBUS

insmod /lib/modules/$KERNELVER/extra/bdmf.ko  
insmod /lib/modules/$KERNELVER/extra/rdpa_gpl.ko  

#I2C 

# PON
insmod /lib/modules/$KERNELVER/extra/bcm_pondrv.ko  
insmod /lib/modules/$KERNELVER/extra/smtc.ko  

# MPM

# BPM

# VLAN
insmod /lib/modules/$KERNELVER/extra/bcmvlan.ko  

# RDPA
insmod /lib/modules/$KERNELVER/extra/rdpa_gpl_ext.ko  
if test -e  /lib/modules/$KERNELVER/extra/rdpa_prv.ko
then
  if echo $(/usr/bin/pspctl dump OperationMode) | grep -q 'FC'
  then
    insmod /lib/modules/$KERNELVER/extra/rdpa.ko  
    echo 'FC operation mode loaded!'
  else
    insmod /lib/modules/$KERNELVER/extra/rdpa_prv.ko  
    echo 'Provision operation mode loaded!'
  fi
else
  insmod /lib/modules/$KERNELVER/extra/rdpa.ko  
fi

# RDPA_User
insmod /lib/modules/$KERNELVER/extra/rdpa_usr.ko  

insmod /lib/modules/$KERNELVER/extra/rdpa_mw.ko  

# General
insmod /lib/modules/$KERNELVER/extra/bcm_license.ko  

# Ingress
# Must
insmod /lib/modules/$KERNELVER/extra/bcm_ingqos.ko  

# RDPA
insmod /lib/modules/$KERNELVER/extra/rdpa_cmd.ko  

insmod /lib/modules/$KERNELVER/extra/pktflow.ko  
insmod /lib/modules/$KERNELVER/extra/cmdlist.ko  
if [ $mfg_nvram_mode -eq 0 ]; then
echo "No need for adsl driver"
fi

# insert

# enet


insmod /lib/modules/$KERNELVER/extra/bcm_enet.ko  
# moving
insmod /lib/modules/$KERNELVER/extra/pktrunner.ko  
insmod /lib/modules/$KERNELVER/extra/bcmmcast.ko  

# EAPFWD:

if [ $mfg_nvram_mode -gt 0 ]; then
echo "Manufacture mode, load driver done!"
exit 0
fi

#load SATA/AHCI

# PCIe
insmod /lib/modules/$KERNELVER/extra/bcm_pcie_hcd.ko  

# pcie

# WLAN
insmod /lib/modules/$KERNELVER/extra/wfd.ko  

# NetXL

#Voice 


#load usb
insmod /lib/modules/$KERNELVER/extra/bcm_bca_usb.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/ehci-hcd.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/ehci-platform.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/ehci-pci.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/ohci-hcd.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/ohci-platform.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/ohci-pci.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/xhci-hcd.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/host/xhci-plat-hcd.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/class/usblp.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/storage/usb-storage.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/storage/uas.ko  
#The following
#we need
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/serial/usbserial.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/serial/usb_wwan.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/usb/serial/option.ko  
#kernel/drivers/usb/serial/cp210x.ko 
#kernel/drivers/usb/serial/ftdi_sio.ko 
#kernel/drivers/usb/serial/pl2303.ko 
insmod /lib/modules/$KERNELVER/kernel/drivers/net/mii.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/net/usb/usbnet.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/net/usb/qmi_wwan.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/net/usb/cdc_ncm.ko  
insmod /lib/modules/$KERNELVER/kernel/drivers/net/usb/cdc_mbim.ko  

# other


insmod /lib/modules/$KERNELVER/extra/bcm_thermal.ko  

# presecure

# LTE


 test -e /etc/sky/rdpa_init.sh && /etc/sky/rdpa_init.sh

# disable ipv6 on archer dummy netdevice
if [ -e /proc/sys/net/ipv6/conf/archer/disable_ipv6 ]; then
	echo 1 > /proc/sys/net/ipv6/conf/archer/disable_ipv6
fi

# Enable the PKA driver.
 test -e /sys/devices/platform/bcm_pka/enable && echo 1 > /sys/devices/platform/bcm_pka/enable

echo "======== load-other-bcm-drivers.sh ================="
# Insmod remaining BCM drivers
/etc/sky/load-other-bcm-drivers.sh
echo "======== load-other-bcm-drivers.sh ================="
# Insmod dummy interface
echo "======== load dummy interface ================="
/sbin/modprobe dummy

exit 0
		;;

	stop)
		echo "removing bcm base drivers not implemented yet..."
		exit 1
		;;

	*)
		echo "bcmbasedrivers: unrecognized option $1"
		exit 1
		;;

esac


