#!/bin/sh

source /etc/utopia/service.d/log_capture_path.sh

if [ -f "/tmp/time_offset_lock" ]
then
    echo_t "sync_timeoffset.sh: sky_update_timeoffset.sh execution in progress."
    exit 0
fi

NTP_SYNC_STATUS=`sysevent get ntp_time_sync`
DHCP_TIME_OFFSET=`sysevent get dhcpv4_time_offset`

echo_t "NTP_SYNC_STATUS :$NTP_SYNC_STATUS"
echo_t "DHCP_TIME_OFFSET :$DHCP_TIME_OFFSET"

if [ "1" = "$NTP_SYNC_STATUS" ] && [ "unset" = "$DHCP_TIME_OFFSET" ] ; then
    echo_t "sync_timeoffset.sh : Started time syncing from cronjob"
    sh /etc/sky/sky_update_timeoffset.sh &
fi
