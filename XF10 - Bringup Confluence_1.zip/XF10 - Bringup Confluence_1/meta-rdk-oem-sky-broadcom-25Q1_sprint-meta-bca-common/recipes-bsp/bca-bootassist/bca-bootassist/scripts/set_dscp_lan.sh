#! /bin/sh

WAN_STATUS=$(sysevent get wan-status)

if [ "$WAN_STATUS" != "started" ]; then
    exit 0
fi

if [ ! -f "/tmp/.query_list" ]; then
     /etc/sky/rxtx_query.sh
fi

#check if feature is enabled
DSCP1_ENABLE=$(syscfg get DscpEnabledList_1)
DSCP2_ENABLE=$(syscfg get DscpEnabledList_2)

if [ "$DSCP1_ENABLE" == "" ]  && [ "$DSCP2_ENABLE" == "" ]; then
    #feature disabled. set_dscp.sh should be called only if clients exists
    if [ ! -f /tmp/dscp_clients_exist ]; then
        exit 0
    fi
fi

#Try to detect new clients 3 times per minute and add the query id in flow table

LOCK_FILE="/tmp/fcctl_dscp.lock"

#Try to detect new clients 3 times per minute and add the query id in flow table
#if lock is unavailable try each second
flock -n "$LOCK_FILE" /etc/sky/set_dscp.sh
SET_STATUS_1=$?
sleep 19
flock -n "$LOCK_FILE" /etc/sky/set_dscp.sh
SET_STATUS_2=$?
sleep 19
flock -n "$LOCK_FILE" /etc/sky/set_dscp.sh
SET_STATUS_3=$?
#if we failed to get lock for each 19 sec intervals, this script and LMLite hal might be running
#at the same 19 seconds interval. check if lock is available for the next few seconds before crontab
#finishes this script

if [ "$SET_STATUS_1" = "1" ] && [ "$SET_STATUS_2" = "1" ] && [ "$SET_STATUS_3" = "1" ]; then
    iter=1
    while [ $iter -le 5 ]
    do
        sleep 1
        iter=$(( iter + 1 ))
        flock -n "$LOCK_FILE" /etc/sky/set_dscp.sh
        SET_STATUS=$?
        if [ "$SET_STATUS" = "0" ]; then
            break
        fi
    done
fi

