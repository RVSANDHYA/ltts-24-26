#!/bin/sh

source /etc/utopia/service.d/log_capture_path.sh

timeoffset_temp_file=/tmp/update_timeoffset.txt
touch "/tmp/time_offset_lock"

zone=`cat /tmp/serial.txt | grep TIMEZONE | cut -f2 -d "="`
zone=${zone%$'\r'}
year=`date +%Y`
cet_timezone_name="Europe/CET"

    if [ "$zone" == "$cet_timezone_name" ]
    then
        timezone="CET";
    else
        timezone="Europe/London"
    fi

zdump -v "$timezone" > $timeoffset_temp_file

dst_begin_month=`cat $timeoffset_temp_file | grep $year | grep 'isdst=1' | head -n 1 | cut -f4 -d " "`

    if [ "$dst_begin_month" == "Mar" ]
    then
        dst_begin_month="03"
    fi

dst_begin_day=`cat $timeoffset_temp_file | grep $year | grep 'isdst=1' | head -n 1 | cut -f5 -d " "`
dst_begin_time=`cat $timeoffset_temp_file | grep $year | grep 'isdst=1' | head -n 1 | cut -f6 -d " "`
dst_begin_time_in_sec=`date -d "$year-$dst_begin_month-$dst_begin_day $dst_begin_time" '+%s'`

dst_end_month=`cat $timeoffset_temp_file | grep $year | grep 'isdst=1' | tail -n 1 | cut -f4 -d " "`

    if [ "$dst_end_month" == "Oct" ]
    then
        dst_end_month="10"
    fi

dst_end_day=`cat $timeoffset_temp_file | grep $year | grep 'isdst=1' | tail -n 1 | cut -f5 -d " "`
dst_end_time=`cat $timeoffset_temp_file | grep $year | grep 'isdst=1' | tail -n 1 | cut -f6 -d " "`
dst_end_time_in_sec=`date -d "$year-$dst_end_month-$dst_end_day $dst_end_time" '+%s'`

current_time_in_sec=`date +%s`

    if [ "$current_time_in_sec" -ge "$dst_begin_time_in_sec" ] && [[ "$current_time_in_sec" -le "$dst_end_time_in_sec" ]]
    then
        echo_t "Day light saving time is active"
        offset=`cat $timeoffset_temp_file | grep "$(date +%Y)" | grep 'isdst=1' | head -n 1 | cut -d "=" -f4`
    else
        echo_t "Day light saving time is off"
        offset=`cat $timeoffset_temp_file | grep "$(date +%Y)" | grep 'isdst=0' | head -n 1 | cut -d "=" -f4`
    fi

rm -f $timeoffset_temp_file

sysevent set ipv4-timeoffset @$offset

rm "/tmp/time_offset_lock"
