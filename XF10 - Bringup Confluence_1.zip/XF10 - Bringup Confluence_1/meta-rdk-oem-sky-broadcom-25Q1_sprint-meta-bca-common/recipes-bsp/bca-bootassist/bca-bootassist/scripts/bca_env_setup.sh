#!/bin/sh
##########################################################################
#
# Copyright 2019 Broadcom
#
##########################################################################

#a workaround for the systemd can't sense ttyS0 state via udev
systemctl daemon-reload
systemctl stop serial-getty@ttyS0.service
systemctl start serial-getty@ttyS0.service


############################## NF Settings ################################
/etc/sky/system-config.sh start
