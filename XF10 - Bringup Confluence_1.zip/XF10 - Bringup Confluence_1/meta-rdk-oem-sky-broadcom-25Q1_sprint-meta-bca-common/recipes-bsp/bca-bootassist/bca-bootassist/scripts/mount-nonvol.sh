#!/bin/sh

# Create nvram partitions for RDK.
function mount_nvram_part() {
    echo ">>>>> eMMC nvram partition <<<<<"
    # Check if the symbolic link to the eMMC nvm partition exists
    if [ -L /dev/nvm ]; then
        echo ">>>>> Mounting eMMC nvram Partition <<<<<"
        mount -t ext4 /dev/nvm /nvram -rw;
        if [ ! $? -eq 0 ]; then
            echo ">>>>> Formatting eMMC nvram Partition <<<<<"
            mke2fs -t ext4 -F /dev/nvm;
            mount -t ext4 /dev/nvm /nvram -rw;
        fi
     else
        echo ">>>>> No nvm partion exists in eMMC, mount it on /data <<<<<"
        if [ ! -d "/data/nvram1" ];then
            echo "Cannot find nvram1 !! Creating directory."
            mkdir /data/nvram1
        fi
        #mapping to Nvram points
        mount --bind /data/nvram1 /nvram
     fi

    echo ">>>>> eMMC nvram2 partition <<<<<"
    # Check if the symbolic link to the eMMC nvm2 partition exists
    if [ -L /dev/nvm2 ]; then
        echo ">>>>> Mounting eMMC nvram2 Partition <<<<<"
        mount -t ext4 /dev/nvm2 /nvram2 -rw;
        if [ ! $? -eq 0 ]; then
            echo ">>>>> Formatting eMMC nvram2 Partition <<<<<"
            mke2fs -t ext4 -F /dev/nvm2;
            mount -t ext4 /dev/nvm2 /nvram2 -rw;
        fi
     else
        echo ">>>>> No nvm2 partion exists in eMMC, mount it on /data <<<<<"
        if [ ! -d "/data/nvram2" ];then
            echo "Cannot find nvram2 !! Creating directory."
            mkdir /data/nvram2
        fi
        #mapping to Nvram points
        mount --bind /data/nvram2 /nvram2
     fi
}

#===========================================================================================================
# Mount /nvram and /nvram2 partions for RDKB.
# If eMMC has /dev/nvm and /dev/nvm2 partitions, use those mount points for /nvram and /nvram2, else mount
# it on /data partition.
#===========================================================================================================
mount_nvram_part
