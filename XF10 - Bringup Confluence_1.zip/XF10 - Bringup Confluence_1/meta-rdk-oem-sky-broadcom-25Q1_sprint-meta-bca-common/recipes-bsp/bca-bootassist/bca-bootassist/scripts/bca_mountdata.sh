#!/bin/sh

source /etc/sky/mount-data.inc

echo ">>>>> Starting mdev <<<<<"
/sbin/mdev -s
echo ">>>>> Mounting /data partition start <<<<<"
mount_data 
echo ">>>>> Mounting /data partition end<<<<<"

# create dst dir for "/nvram -> /data/rdkb_nvram"
mkdir -p /data/rdkb_nvram
touch /data/rdkb_nvram/rbus_support

# remount SRC_DIR as tmpfs, and keep initial files in it
dir_remount()
{
  SRC_DIR="$1"
  SIZE="$2"
  TMP_DIR="/tmp/`basename $SRC_DIR`_tmp"
  cp -a $SRC_DIR $TMP_DIR
  mount -t tmpfs -o size=$SIZE tmpfs $SRC_DIR
  cp -a $TMP_DIR/* $SRC_DIR
  rm -rf $TMP_DIR
}

dir_remount "/var" "128m"
dir_remount "/home" "64m"
dir_remount "/opt"  "64m"

