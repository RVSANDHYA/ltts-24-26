#!/bin/sh

if [ -f /etc/device.properties ] ; then
    source /etc/device.properties
fi

case "$1" in
	start)
		echo "Configuring system..."
		# these are some miscellaneous stuff without a good home
		ifconfig lo 127.0.0.1 netmask 255.0.0.0 broadcast 127.255.255.255 up
		echo 1 > /proc/sys/kernel/print-fatal-signals

        echo > /var/udhcpd/udhcpd.leases
		
        # Basically copy the old coredump files to /data/core.last/
		# Set the /proc/sys/kernel/core_pattern to /data/core.new/core_%e
		if [ ! -z "$ENABLE_APP_COREDUMPS" ]; then
			# No cordump file if the remaining of /data is less than 4M.
			data_left=`df /data | grep /data | (read a b c d e f; echo $d)`
			if [ "$data_left" -gt "4000" ]; then
				CORE_DIR_NEW=/data/core.new
				CORE_DIR_LAST=/data/core.last
				if [ ! -d $CORE_DIR_NEW ]; then
					mkdir $CORE_DIR_NEW
				else
					nfiles=`ls $CORE_DIR_NEW/`
					if [ "$nfiles" != "" ]; then
						if [ ! -d $CORE_DIR_LAST ]; then
							mkdir $CORE_DIR_LAST
						else
							rm -f $CORE_DIR_LAST/*
						fi
						mv $CORE_DIR_NEW/* $CORE_DIR_LAST/.
					fi
				fi
				echo "${CORE_DIR_NEW}/core_%e" > /proc/sys/kernel/core_pattern
			fi
		fi
		if [ -n "$BRCM_SCHED_RT_RUNTIME" ]; then
			echo $BRCM_SCHED_RT_RUNTIME > /proc/sys/kernel/sched_rt_runtime_us
		fi
		if [ -n "$BRCM_SCHED_RT_PERIOD" ]; then
			echo $BRCM_SCHED_RT_PERIOD > /proc/sys/kernel/sched_rt_period_us
		fi
		echo 0 > /proc/sys/vm/swappiness

		# set tcp_be_liberal when acceleartion is enabled
		if [ -e /proc/sys/net/netfilter/nf_conntrack_tcp_be_liberal ]; then
			echo 1 > /proc/sys/net/netfilter/nf_conntrack_tcp_be_liberal
		fi

		# set panic_on_rcu_stall to avoid indefinite hang due to RCU stall
		if [ "$BOX_TYPE" = "WNXL11BWL" ] && [ -e /proc/sys/kernel/panic_on_rcu_stall ]; then
			echo 1 > /proc/sys/kernel/panic_on_rcu_stall
		fi

		# enlarge min_free_kbytes for the OOM issue happens during wifi usb-stress testing
		sysctl -qw vm.min_free_kbytes=8192
		echo "Configuring system OK"

		exit 0
		;;

	stop)
		echo "Unconfig system not implemented..."
		exit 1
		;;

	*)
		echo "$0: unrecognized option $1"
		exit 1
		;;

esac

