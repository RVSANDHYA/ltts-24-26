#!/bin/sh

modprobe nf_conntrack nf_conntrack_helper=1
modprobe xt_TCPMSS
modprobe xt_SKIPLOG
modprobe xt_mac
modprobe ipt_MASQUERADE
modprobe xt_REDIRECT
modprobe xt_state

modprobe nf_conntrack_proto_gre
modprobe nf_nat_proto_gre

modprobe nf_conntrack_pptp
modprobe nf_conntrack_h323
modprobe nf_conntrack_ftp
modprobe nf_conntrack_sip
modprobe nf_conntrack_rtsp
modprobe nf_conntrack_irc
modprobe nf_conntrack_tftp

modprobe nf_nat_pptp
modprobe nf_nat_h323
modprobe nf_nat_ftp
modprobe nf_nat_sip
modprobe nf_nat_rtsp
modprobe nf_nat_irc
modprobe nf_nat_tftp

lsmod | grep "nfnetlink_queue"

if [ $? -eq 1 ]; then
    modprobe nfnetlink_queue
fi
