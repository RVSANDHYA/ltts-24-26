#! /bin/sh

function delete_fcctl_dscp_table()
{
    if [ -f /tmp/dscp_clients_exist ]; then
        #Delete all fcctl entries for client mac
        for mac in $(cat /tmp/dscp_clients_exist); do
            del_list=$(fcctl flwstats p | grep -i "mac=$mac" | awk -F":" '{ print $1 }')
            for query_id in ${del_list}; do 
                fcctl flwstats d "$query_id"
            done
        done
        rm -f /tmp/dscp_clients_exist
    fi
    #Delete wan query IDs

    if [ -n "$PHY_NAME" ]; then
        phy_query_id_up=$(fcctl flwstats p | grep -i "rxdscp=all dstphy=$PHY_NAME" | awk -F":" '{ print $1 }')
        phy_query_id_down=$(fcctl flwstats p | grep -i "txdscp=all srcphy=$PHY_NAME" | awk -F":" '{ print $1 }')

        if [ -n "$phy_query_id_up" ]; then
            fcctl flwstats d "$phy_query_id_up"
        fi

        if [ -n "$phy_query_id_down" ]; then
            fcctl flwstats d "$phy_query_id_down"
        fi
    fi
}

function add_clients()
{
    #Get connected client list for both v4 and v6
    ip nei show | grep brlan0 | grep -v FAILED | grep -v "^fe80:" | grep -v "^fd" | grep -v "^fc" | cut -d' ' -f 5 | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}' > /tmp/connected_lan_mac
    sort -u /tmp/connected_lan_mac | tr '[a-z]' '[A-Z]' > /tmp/connected_lan_mac_sorted
    #Initialise existing list
    if [ ! -f /tmp/dscp_clients_exist ]; then
        touch /tmp/dscp_clients_exist
    else
        sort -u /tmp/dscp_clients_exist | tr '[a-z]' '[A-Z]' > /tmp/dscp_clients_exist_sorted
        cat /tmp/dscp_clients_exist_sorted > /tmp/dscp_clients_exist
    fi
    #Detect newly connected clients
    diff /tmp/dscp_clients_exist /tmp/connected_lan_mac_sorted | grep "^+" | grep -v "+++" | cut -d'+' -f2 > /tmp/connected_lan_mac
    #detect disconnected clients
    diff /tmp/dscp_clients_exist /tmp/connected_lan_mac_sorted | grep "^-" |  cut -d'-' -f2 > /tmp/deleted_lan_mac
    #update existing list
    cat /tmp/connected_lan_mac_sorted > /tmp/dscp_clients_exist
    for mac in $(cat /tmp/connected_lan_mac); do
        #upstream
        fcctl flwstats n srcmac $mac dstphy $PHY_NAME rxdscp all
        #downstream
        fcctl flwstats n dstmac $mac srcphy $PHY_NAME txdscp all
    done
    for mac in $(cat /tmp/deleted_lan_mac); do
        del_list=$(fcctl flwstats p | grep -i "mac=$mac" | awk -F":" '{ print $1 }')
        for query_id in ${del_list}; do 
            fcctl flwstats d "$query_id"
        done
    done
    #clean all tmp files
    rm -f /tmp/dscp_clients_exist_sorted
    rm -f /tmp/connected_lan_mac_sorted
    rm -f /tmp/connected_lan_mac
    rm -f /tmp/deleted_lan_mac

}

WAN_STATUS=$(sysevent get wan-status)

if [ "$WAN_STATUS" = "started" ]; then
    if [ -f "/sys/class/net/atm0/address" ]; then
        PHY_NAME=atm0
    elif [ -f "/sys/class/net/ptm0/address" ]; then
        PHY_NAME=ptm0
    else
        PHY_NAME=eth0
    fi
else
    exit 0
fi

if [ -z "$PHY_NAME" ]; then
    exit 0
fi

#check if feature is enabled

DSCP1_ENABLE=$(syscfg get DscpEnabledList_1)
DSCP2_ENABLE=$(syscfg get DscpEnabledList_2)

if [ "$DSCP1_ENABLE" == "" ]  && [ "$DSCP2_ENABLE" == "" ]; then
    #feature disabled
    delete_fcctl_dscp_table
    exit 0
fi

#At this point one of the interfaces , either 1 or 2 is completely enabled
add_clients
