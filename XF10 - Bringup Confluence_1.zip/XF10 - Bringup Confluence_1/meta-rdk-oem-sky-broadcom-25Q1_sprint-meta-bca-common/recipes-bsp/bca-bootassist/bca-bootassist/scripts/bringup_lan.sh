#!/bin/sh
. /etc/device.properties
echo "bring_lan.sh script is called to bringup LAN bridge" > /dev/console

ovs_enable=`syscfg get mesh_ovs_enable`

if [ "$BOX_TYPE" = "SE501" ] ||  [ "$BOX_TYPE" = "WNXL11BWL" ]
then
    if [ "x$ovs_enable" = "xtrue" ]; then
        echo "OVS enable in CPE, make sure ovsdb-server is running in CPE"
        # Looking for ovsdb server started. If not wait atleast 20sec as max.
        CNT=1
        while [ $CNT -lt 20 ]
        do
            if ! grep opensync /proc/`pidof ovsdb-server |cut -d ' ' -f1`/cmdline
            then
                sleep 1
                CNT=$((CNT + 1))
                echo "$CNT"
            else
                echo "OVSDB server is running in CPE"
                break
            fi
        done
    fi
    echo "Start brlan0 initialization" > /dev/console
    sysevent set multinet-up 1
fi
