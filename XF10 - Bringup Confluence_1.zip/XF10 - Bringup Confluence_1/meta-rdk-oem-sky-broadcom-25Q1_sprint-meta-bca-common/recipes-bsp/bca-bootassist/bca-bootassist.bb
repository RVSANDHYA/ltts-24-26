SUMMARY = "HUB Initialization sky and services"
SECTION = "base"
LICENSE = "CLOSED"

FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"
SRC_URI = "file://scripts/ "
SRC_URI += "file://systemd/ "

SRCREV = "${AUTOREV}"
S = "${WORKDIR}"

RDEPENDS_${PN} += "bash"

do_configure[noexec] = "1"

inherit systemd

SYSTEMD_SERVICE_${PN} += "bca-base-drivers.service"
SYSTEMD_SERVICE_${PN} += "bca-gre-tunnels.service"
SYSTEMD_SERVICE_${PN} += "bca-wifi-driver.service"
SYSTEMD_SERVICE_${PN} += "bca-wifi-hndmfg.service"
SYSTEMD_SERVICE_${PN} += "bca-wifi-hndnvram.service"
SYSTEMD_SERVICE_${PN} += "bca-bdmf.service"
SYSTEMD_SERVICE_${PN} += "bca-env-setup.service"
SYSTEMD_SERVICE_${PN} += "bca-mountdata.service"
SYSTEMD_SERVICE_${PN} += "bca-static-nodes.service"
SYSTEMD_SERVICE_${PN} += "bca-wdt.service"
SYSTEMD_SERVICE_${PN} += "mount-nonvol.service"
SYSTEMD_SERVICE_${PN} += "bringup-lan.service"

do_install () {
    install -d ${D}${sysconfdir}/sky
    install -d ${D}${sysconfdir}/rt_policy_info.d/
    install -d ${D}${systemd_unitdir}/system
    install -d ${D}${systemd_unitdir}/system/sysinit.target.wants/
    install -d ${D}${systemd_unitdir}/system/multi-user.target.wants
    install -d ${D}${bindir}

    # Install init sky
    install -m 0755 ${WORKDIR}/scripts/bca_env_setup.sh                ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/bca_mountdata.sh                ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/bcm-base-drivers.sh             ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/bcm-wlan-drivers.sh             ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/default_cfg.txt                 ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/gencfg_init.sh                  ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/gre-tunnel-drivers.sh           ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/hndmfg.sh                       ${D}${sysconfdir}/sky/
    sed -i -- 's/KERNEL_NVRAM_FILE_NAME/kernel_nvram.setting/g' ${D}${sysconfdir}/sky/hndmfg.sh
    install -m 0755 ${WORKDIR}/scripts/hndnvram.sh                     ${D}${sysconfdir}/sky/
    sed -i -- 's/KERNEL_NVRAM_FILE_NAME/kernel_nvram.setting/g' ${D}${sysconfdir}/sky/hndnvram.sh
    install -m 0755 ${WORKDIR}/scripts/load-other-bcm-drivers.sh       ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/make_static_devnodes.sh         ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/mount-data.inc                  ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/mount-nonvol.sh                 ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/rdpa_init.sh                    ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/sky_update_timeoffset.sh        ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/sync_timeoffset.sh              ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/system-config.sh                ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/wireless_bringup.sh             ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/bringup_lan.sh                  ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/set_dscp_lan.sh                 ${D}${sysconfdir}/sky/
    install -m 0755 ${WORKDIR}/scripts/set_dscp.sh                     ${D}${sysconfdir}/sky/

    install -m 0755 ${WORKDIR}/scripts/make_mmc_links.sh               ${D}${sysconfdir}/
    install -m 0755 ${WORKDIR}/scripts/mdev.conf                       ${D}${sysconfdir}/
    install -m 0755 ${WORKDIR}/scripts/get_rootfs_dev.sh               ${D}${sysconfdir}/

    install -m 0755 ${WORKDIR}/scripts/rt_policy_info.d/rt_settings_apps.txt ${D}${sysconfdir}/rt_policy_info.d/
    install -m 0755 ${WORKDIR}/scripts/rt_policy_info.d/rt_settings_interrupts.txt ${D}${sysconfdir}/rt_policy_info.d/
    install -m 0755 ${WORKDIR}/scripts/rt_policy_info.d/rt_settings_kthreads.txt ${D}${sysconfdir}/rt_policy_info.d/
    install -m 0755 ${WORKDIR}/scripts/rt_policy_info.d/rt_settings_metadata ${D}${sysconfdir}/rt_policy_info.d/
    install -m 0755 ${WORKDIR}/scripts/rt_policy_info.d/symbol_table.txt ${D}${sysconfdir}/rt_policy_info.d/
    install -m 0755 ${WORKDIR}/scripts/rt_policy_info.d/rtpolicy ${D}${bindir}/

    # Service Installation
    install -m 0644 ${WORKDIR}/systemd/bca-base-drivers.service        ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-bdmf.service                ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-env-setup.service           ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-gencfg-init.service         ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-gre-tunnels.service         ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-mountdata.service           ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-static-nodes.service        ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-wdt.service                 ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-wifi-driver.service         ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-wifi-hndmfg.service         ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bca-wifi-hndnvram.service       ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/mount-nonvol.service            ${D}${systemd_unitdir}/system/
    install -m 0644 ${WORKDIR}/systemd/bringup-lan.service             ${D}${systemd_unitdir}/system/

    # Make soft link to services.
    ln -sf ../bca-base-drivers.service  ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-bdmf.service          ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-env-setup.service     ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-gencfg-init.service   ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-gre-tunnels.service   ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-mountdata.service     ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-static-nodes.service  ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-wdt.service           ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-wifi-driver.service   ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-wifi-hndmfg.service   ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bca-wifi-hndnvram.service ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../mount-nonvol.service      ${D}${systemd_unitdir}/system/sysinit.target.wants/
    ln -sf ../bringup-lan.service       ${D}${systemd_unitdir}/system/multi-user.target.wants/
}

FILES_${PN} += " \
    ${sysconfdir}/* \
    ${sysconfdir}/sky/* \
    ${systemd_unitdir}/system/* \
"
