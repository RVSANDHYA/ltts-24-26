DESCRIPTION = "BRCM wldm"
LICENSE = "CLOSED"

# Common Bca cflags.
require recipes-utils/bca-userspace/bca_common.inc

DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES', 'broadcom-wifi-src', ' bca-userspace-libs', ' bca-userspace-libs bca-wlan-prebuilt', d)}"
RDEPENDS_${PN}_append = "${@bb.utils.contains('DISTRO_FEATURES', 'broadcom-wifi-src', ' bca-userspace-libs-prebuilts',' bca-wlan-prebuilt bca-userspace-libs-prebuilts', d)}"

EXTRA_OECMAKE += "-DADA_BUILD_WLDM=ON"
FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI = "${RDKB_COMPONENTS_ROOT_GIT}/thirdparty/broadcom/components/libwldm;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH} \ 
            file://001-Compilation_libwldm.patch \
            "

S = "${WORKDIR}/git/"
SRCREV = "${AUTOREV}"
inherit systemd

SOLIBS = ".so"
FILES_SOLIBSDEV = ""


LDFLAGS += " -L ${STAGING_LIBDIR} "
ISSYSTEMD = "${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'true', 'false', d)}"
CFLAGS_append = " \
               -I ${S} \
               -I ${STAGING_INCDIR_SHARED} \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include \
           -I ${STAGING_INCDIR_SHARED}/userspace/private/math/include \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/wifi \
               -I ${STAGING_INCDIR_SHARED}/userspace/public/include \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include/proto \
               -I ${STAGING_INCDIR}/private/include \
               -DSKY -DBUILD_FOR_SKY -DSKY_RDKB -D__CONFIG_DHDAP__ -DCONFIG_DHDAP -DAX_SUPPORT\
           ${BCM_FLAGS} -DCMWIFI_RDKB_COMCAST -DCONFIG_HOSTAPD -DADA_BUILD_WLDM -DWIFI_HAL_VERSION_3 -DWLDM_21_2 \
               "
do_configure_append() {
    cp -rf ${STAGING_DIR_SHARED}/bcmdrivers/wifi/*.c ${S}
    cp -rf ${STAGING_DIR_SHARED}/bcmdrivers/wifi/*.h ${S}
}
do_compile() {
    make -C ${S} libwldm
}

do_install_append () {
    install -d ${D}${libdir}
    install -m 755 ${S}/libwldm.so ${D}${libdir}
    install -m 755 ${S}/libwldm.so ${STAGING_LIBDIR}
    install -d ${STAGING_INCDIR_SHARED}/wldm
    install -m 755 ${S}/*.h ${STAGING_INCDIR_SHARED}/wldm/
}

FILES_${PN}_append = " \
		${libdir}/libwldm.so \
		"

do_configure[depends] += "${@bb.utils.contains('DISTRO_FEATURES', 'broadcom-wifi-src', '${MLPREFIX}bca-userspace-libs:do_install', '${MLPREFIX}bca-userspace-libs:do_install ${MLPREFIX}bca-wlan-prebuilt:do_install', d)}"
PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"
