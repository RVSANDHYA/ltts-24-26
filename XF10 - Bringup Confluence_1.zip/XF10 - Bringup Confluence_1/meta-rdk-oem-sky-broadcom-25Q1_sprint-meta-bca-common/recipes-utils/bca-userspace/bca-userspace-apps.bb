DESCRIPTION = "BCA Userspace application - 504L03"
LICENSE = "CLOSED"

require bca_common.inc

DEPENDS= " virtual/kernel bca-userspace-libs libnfnetlink libnetfilter-queue expat utopia json-c wpa-supplicant bca-userspace-libs-prebuilts"
DEPENDS += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager','bca-mdm-layer','', d)}"

RDEPENDS_${PN} += "bash wpa-supplicant"

SRC_URI= "${BROADCOM_SDK_GIT}/bca/userspace;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

S = "${WORKDIR}/git/"
SRCREV = "${AUTOREV}"

EXTRA_OECMAKE += "-DBUILD_APPS=ON -DFEATURE_RDKB_WAN_MANAGER=ON"
EXTRA_OECMAKE += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager','-DFEATURE_RDKB_TELCOVOICE_MANAGER=ON','', d)}"
EXTRA_OECMAKE += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2','-DFEATURE_RDKB_VOICE_DM_TR104_V2=ON','', d)}"
inherit cmake systemd

LDFLAGS += " -L ${STAGING_LIBDIR}"
ISSYSTEMD = "${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'true', 'false', d)}"

CFLAGS_append = " \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/bcmcrypto/include/\
               -I ${S}/public/include \
               -I ${S}/public/include/linux \
               -I ${S}/private/include \
               -I ${S}/private/include/linux \
               -I ${S}/public/libs/bcm_util \
               -I ${S}/public/libs/bcm_flashutil \
               -I ${S}/public/libs/json_hal_server \
               -I ${S}/private/libs/bcm_generic_hal \
               -I ${S}/private/libs/bcm_generic_dsl_hal \
               -I ${S}/private/libs/ssk_util \
               -I ${S}/private/libs/json_hal_server_glue \
               -I ${S}/public/libs/sys_util \
               -I ${S}/private/libs/mdm_cli \
               -I ${S}/private/libs/bcm_comp_md \
               -I ${S}/private/libs/bcm_voice_hal \
               -I ${STAGING_INCDIR_SHARED} \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include \
               -I ${STAGING_INCDIR_SHARED}/wlcsm \
               -I ${STAGING_INCDIR_SHARED}/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/drv/phys/ \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include/ \
               -I ${STAGING_INCDIR_SHARED}/userspace/public/include \
               -I ${STAGING_INCDIR_SHARED}/public/libs/bcm_util \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/linux \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include/wl/ \
               -I ${STAGING_INCDIR_SHARED}/bdmf/framework/ \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/ \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/sim/ \
               -I ${STAGING_INCDIR_SHARED}/rdpa_gpl \
               -I ${STAGING_INCDIR_SHARED}/rdpa_user \
               -I ${S}/public/include/linux/ \
               -I ${S}/private/libs/rut_util/ \
               -I ${S}/private/apps/wlan/nas/ \
               -I ${S}/private/apps/wlan/nas/nas_fbt/ \
               -I ${S}/private/apps/wlan/eapd/ \
               -I ${S}/private/libs/staged/ \
               -I ${S}/private/libs/wlsysutil/ \
               -I ${S}/public/libs/bcm_boardctl/ \
               -I ${S}/private/libs/nvram/ \
               -I ${S}/gpl/apps/urlfilterd/libnetfilter_queue/include \
               -I ${S}/gpl/apps/urlfilterd/libnfnetlink/include \
               -I ${STAGING_INCDIR}/sysevent \
               -I ${STAGING_INCDIR}/syscfg \
               -I ${STAGING_INCDIR_SHARED}/json-c \
               -I ${STAGING_INCDIR}/json-c \
               -I ${STAGING_INCDIR}/private/include/ \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/ieee1905/include/ \
               -I ${STAGING_INCDIR}/ceshared \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/math/include/ \
               -DSKY -DBUILD_FOR_SKY -DSKY_RDKB -DBUILD_RDKWIFI\
               ${BCM_FLAGS} \ -DINCLUDE_BREAKPAD \
               -DCOMPRESSED_CONFIG_FILE -DRDK_BUILD -DCMWIFI_RDKB\
               "

CXXFLAGS_append = " \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${S}/public/libs/expat/expat-2.1.0/lib/ \
		"

CFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2','-DFEATURE_RDKB_VOICE_DM_TR104_V2=ON','', d)}"

CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'dfs', '-DCONFIG_DFS', '', d)}"

CFLAGS_append += " ${@bb.utils.contains('DISTRO_FEATURES', 'OneWifi', '-DRDKB_ONE_WIFI', '', d)}"

do_configure[depends] += "virtual/kernel:do_install"
do_configure[depends] += "${MLPREFIX}bca-userspace-libs:do_install"
do_configure[depends] += "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_telcovoice_manager','${MLPREFIX}bca-mdm-layer:do_install','', d)}"

do_configure_prepend () {
    rm -rf ${S}/private/libs/mdk/cdk/include/cdk/arch
    mkdir -p ${S}/private/libs/mdk/cdk/include/cdk/arch
}

do_install_append () {
    install -d ${D}${sysconfdir}
    install -d ${D}${sysconfdir}/sky
    install -d ${D}${base_bindir_native}
   
    install -m 755 ${S}/public/libs/bcm_flashutil/commit.sh ${D}${sysconfdir}/sky/upgrade_commit.sh
    install -m 755 ${S}/public/apps/bdmf_shell/scripts/bs ${D}${bindir}/bs
    install -m 755 ${S}/public/apps/bdmf_shell/scripts/bsi ${D}${bindir}/bsi
    install -m 755 ${S}/public/apps/bdmf_shell/scripts/runner ${D}${bindir}/runner

    install -m 755 ${S}/public/apps/wdtctl/scripts/wdtd-basic.sh ${D}${sysconfdir}/sky/
    install -m 755 ${S}/public/apps/wdtctl/scripts/wdtd-fwupgrade.sh ${D}${sysconfdir}/sky/

    install -m 755 ${S}/private/apps/mcpd/mcpd.conf ${D}${sysconfdir}/

    ln -sf ${bindir}/xdslctl ${D}${bindir}/adsl
    ln -sf ${bindir}/xtmctl ${D}${bindir}/atm
    ln -sf ${bindir}/xtmctl ${D}${base_bindir_native}/xtmctl

    # Creating symbolic links to memaccess application.
    # We have created sw and dw symlinks to memaccess.
    # These commands needs to be available in the device,
    # for the HW compliance test.
    if [ -f ${D}${bindir}/memaccess ];then
        ln -sf ${bindir}/memaccess ${D}${bindir}/dw
        ln -sf ${bindir}/memaccess ${D}${bindir}/sw
        ln -sf ${bindir}/memaccess ${D}${bindir}/db
        ln -sf ${bindir}/memaccess ${D}${bindir}/fb
    fi

    if [ -f ${D}${bindir}/scratchpadctl ];then
        ln -sf ${bindir}/scratchpadctl ${D}${bindir}/pspctl
    fi

    # pwr utility.
    if [ -f ${D}${bindir}/pwrctl ];then
        ln -sf ${bindir}/pwrctl ${D}${bindir}/pwr
    fi

    # fc utility.
    if [ -f ${D}${bindir}/fcctl ];then
        ln -sf ${bindir}/fcctl ${D}${bindir}/fc
    fi
}
FILES_${PN} += " \
        ${bindir}/* \
        ${sysconfdir}/* \
        ${sysconfdir}/sky/* \
        ${base_bindir_native}/* \
    "
INSANE_SKIP_${PN} += "dev-deps"
INSANE_SKIP_${PN} += "file-rdeps"
PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"

DEPENDS += "breakpad breakpad-wrapper"

LDFLAGS += "-lbreakpadwrapper"

# generating minidumps
PACKAGECONFIG_append = " breakpad"
