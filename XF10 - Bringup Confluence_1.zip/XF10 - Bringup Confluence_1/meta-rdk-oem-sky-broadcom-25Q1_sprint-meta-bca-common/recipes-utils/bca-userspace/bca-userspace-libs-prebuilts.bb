DESCRIPTION = "Prebuilt Userspace  libs"
LICENSE = "CLOSED"
SRC_URI = "https://partners.artifactory.comcast.com/artifactory/sky_sr300/components/userspace/userspace-libs/2.11/userspace-libs-2.11.tar.gz;name=userspace_libs"
SRC_URI[userspace_libs.md5sum] =  "69fcec722b49a452d6f122ba6bfe71b0"
SRC_URI[userspace_libs.sha256sum] = "2c13498316cb7e8f1d8740468198d31d36a5be71f85d5d5bd8ba5540b66aca5d"

do_install() {
    install -d ${D}${libdir}
    install -m 0755 ${WORKDIR}/libcms_core.so ${D}${libdir}
    install -m 0755 ${WORKDIR}/libmdm_db.so ${D}${libdir}
    install -m 0755 ${WORKDIR}/libcms_qdm.so ${D}${libdir}
    install -m 0755 ${WORKDIR}/libcms_dal.so ${D}${libdir}
    install -m 0755 ${WORKDIR}/libceshared.so  ${D}${libdir}
    install -m 0755 ${WORKDIR}/libbshared.so   ${D}${libdir}
    install -m 0755 ${WORKDIR}/libshared.so    ${D}${libdir}
    install -m 0755 ${WORKDIR}/libieee1905.so  ${D}${libdir}
    install -m 0755 ${WORKDIR}/libbcmcrypto.so ${D}${libdir}
    install -m 0755 ${WORKDIR}/libi5api.so     ${D}${libdir}
    install -m 0755 ${WORKDIR}/libbcm.so       ${D}${libdir}
    install -m 0755 ${WORKDIR}/libcrypt.so.1   ${D}${libdir}
}

FILES_${PN} += " \
        ${libdir}/* \
"

INSANE_SKIP_${PN} = "ldflags"
INHIBIT_PACKAGE_DEBUG_SPLIT = "1"
INHIBIT_PACKAGE_STRIP = "1"
FILES_SOLIBSDEV = ""
INSANE_SKIP_${PN} += "dev-deps"
INSANE_SKIP_${PN} += "dev-so"
INSANE_SKIP_${PN} += "file-rdeps"
