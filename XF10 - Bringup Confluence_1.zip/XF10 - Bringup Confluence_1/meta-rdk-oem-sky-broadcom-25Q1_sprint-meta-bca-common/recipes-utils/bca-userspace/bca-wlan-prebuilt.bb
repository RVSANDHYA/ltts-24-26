Description="BCA WLAN Prebuilts - 504L03"
LICENSE="CLOSED"
FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"
DEPENDS += " bca-userspace-libs openssl libnl wpa-supplicant"
RDEPENDS_{PN} += " bca-userspace-libs openssl json-c libnl wpa-supplicant bca-userspace-libs-prebuilts"

SRC_URI = "https://partners.artifactory.comcast.com/artifactory/sky_sr300/components/wifi/504L03/bca-wlan-bin/2.6/bca-wlan-bin-2.6.tar.gz;name=bca_wlan_bin"
SRC_URI[bca_wlan_bin.md5sum] = "f2b919d687a702079cda67ca80261fe0"
SRC_URI[bca_wlan_bin.sha256sum] = "a48a9b1f17d32a661167f2ffa5236bdb1f32fd64372b71a2240fecc4242a12c3"

S = "${WORKDIR}"
do_configure[noexec] ="1"
do_compile[noexec] ="1"

do_install () {
    install -d ${D}${base_bindir}
    install -d ${D}${libdir}

    install -m 0755 ${S}/acs_cli2                ${D}${base_bindir}
    install -m 0755 ${S}/acsd2                   ${D}${base_bindir}
    install -m 0755 ${S}/appeventd               ${D}${base_bindir}
    install -m 0755 ${S}/aspmd                   ${D}${base_bindir}
    install -m 0755 ${S}/bsd                     ${D}${base_bindir}
    install -m 0755 ${S}/debug_monitor           ${D}${base_bindir}
    install -m 0755 ${S}/dhd                     ${D}${base_bindir}
    install -m 0755 ${S}/emf                     ${D}${base_bindir}
    install -m 0755 ${S}/envram                  ${D}${base_bindir}
    install -m 0755 ${S}/envrams                 ${D}${base_bindir}
    install -m 0755 ${S}/epi_ttcp                ${D}${base_bindir}
    install -m 0755 ${S}/eventd                  ${D}${base_bindir}
    install -m 0755 ${S}/hostapd                 ${D}${base_bindir}
    install -m 0755 ${S}/i5ctl                   ${D}${base_bindir}
    install -m 0755 ${S}/ieee1905                ${D}${base_bindir}
    install -m 0755 ${S}/igs                     ${D}${base_bindir}
    install -m 0755 ${S}/ssd                     ${D}${base_bindir}
    install -m 0755 ${S}/toad                    ${D}${base_bindir}
    install -m 0755 ${S}/wl                      ${D}${base_bindir}
    install -m 0755 ${S}/wlaffinity              ${D}${base_bindir}
    install -m 0755 ${S}/wl_server_socket        ${D}${base_bindir}
    install -m 0755 ${S}/wpa_cli                 ${D}${base_bindir}
    install -m 0755 ${S}/wpa_supplicant          ${D}${base_bindir}
    install -m 0755 ${S}/ceventd                 ${D}${base_bindir}
    install -m 0755 ${S}/ceventc                 ${D}${base_bindir}
    install -m 0755 ${S}/hostapd_cli             ${D}${base_bindir}
}

INSANE_SKIP_${PN} = "ldflags already-stripped"
PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"
SOLIBS = ".so"
FILES_SOLIBSDEV = ""
INSANE_SKIP_${PN} += "file-rdeps"

FILES_${PN} = " \
    ${base_bindir}/* \
    ${libdir}/* \ "
