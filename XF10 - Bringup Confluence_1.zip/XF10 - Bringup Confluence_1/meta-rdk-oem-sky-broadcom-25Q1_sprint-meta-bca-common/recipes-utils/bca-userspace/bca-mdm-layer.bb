SUMMARY = "BCA - MDM layer library implementing the TR104 DM"
LICENSE = "CLOSED"

# Common Bca cflags.
require recipes-utils/bca-userspace/bca_common.inc

DEPENDS+= " msgpack-c bca-userspace-libs "

SRC_URI = "${RDKB_COMPONENTS_ROOT_GIT}/sdk/devices/sky/sr300/common;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=mdmlayer"

SRCREV = "${AUTOREV}"
PV = "${RDK_RELEASE}+git${SRCPV}"
S = "${WORKDIR}/git/private/libs/mdm_layer"

LDFLAGS += " -L ${STAGING_LIBDIR} "

EXTRA_OECMAKE += "-DFEATURE_RDKB_TELCOVOICE_MANAGER=ON -DFEATURE_RDKB_VOICE_DM_TR104_V2=ON"
CFLAGS_append = " \
               -I ${STAGING_INCDIR_SHARED} \
               -I ${STAGING_INCDIR_SHARED}/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR_SHARED}/public/include \
               -I ${STAGING_INCDIR_SHARED}/public/include/linux \
               -I ${STAGING_INCDIR_SHARED}/private/include \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast\
               "
CFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2','-DFEATURE_RDKB_VOICE_DM_TR104_V2=ON','', d)}"

do_configure[depends] += "${MLPREFIX}msgpack-c:do_install \
                          ${MLPREFIX}bca-userspace-libs:do_install "

inherit cmake coverity
