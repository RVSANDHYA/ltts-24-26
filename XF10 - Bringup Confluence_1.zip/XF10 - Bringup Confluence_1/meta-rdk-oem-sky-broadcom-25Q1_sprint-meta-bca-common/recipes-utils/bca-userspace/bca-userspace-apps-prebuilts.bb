DESCRIPTION = "Prebuilt Userspace  Apps"
LICENSE = "CLOSED"

SRC_URI_append += "https://partners.artifactory.comcast.com/artifactory/sky_sr300/components/userspace/userspace-apps/2.1/userspace-apps-2.1.tar.gz;name=userspace_apps"
SRC_URI[userspace_apps.md5sum] = "710b5828e9b5349bbc298e2271277703"
SRC_URI[userspace_apps.sha256sum] = "060acccbc3432bcf0c17170de65516351ea25cd4e241897c5171d7d93a391841"

do_install() {
    install -d ${D}${base_bindir}
    install -m 0755 ${WORKDIR}/tmsctl ${D}${base_bindir}
}

FILES_${PN} += " \
        ${base_bindir}/* \
"
