SUMMARY = "BCA Voice Dal layer"
LICENSE = "CLOSED"

# Common Bca cflags.
require recipes-utils/bca-userspace/bca_common.inc

DEPENDS += " bca-userspace-libs bca-mdm-layer utopia "

SRC_URI = "${RDKB_COMPONENTS_ROOT_GIT}/sdk/devices/sky/sr300/common;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=dallayer"

SRCREV = "${AUTOREV}"
PV = "${RDK_RELEASE}+git${SRCPV}"
S = "${WORKDIR}/git/private/libs/dal_layer"

EXTRA_OECMAKE += "-DFEATURE_RDKB_TELCOVOICE_MANAGER=ON -DFEATURE_RDKB_VOICE_DM_TR104_V2=ON"

LDFLAGS += " -L ${STAGING_LIBDIR} "

CFLAGS_append = " \
               -I ${STAGING_INCDIR_SHARED} \
               -I ${STAGING_INCDIR}/private/libs/xchg/bos/publicInc \
               -I ${STAGING_INCDIR_SHARED}/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR_SHARED}/public/include \
               -I ${STAGING_INCDIR_SHARED}/public/include/linux \
               -I ${STAGING_INCDIR_SHARED}/private/include \
               -I ${STAGING_INCDIR}/sysevent \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${S}/public/include \
               -I ${S}/public/include/linux \
               -I ${S}/private/include \
               -I ${S}/private/include/linux \
               -DVRG_COUNTRY_CFG_AUSTRALIA -DVRG_COUNTRY_CFG_BELGIUM -DVRG_COUNTRY_CFG_BRAZIL -DVRG_COUNTRY_CFG_CHILE \
               -DVRG_COUNTRY_CFG_CHINA  -DVRG_COUNTRY_CFG_CZECH -DVRG_COUNTRY_CFG_DENMARK -DVRG_COUNTRY_CFG_ETSI \
               -DVRG_COUNTRY_CFG_FINLAND -DVRG_COUNTRY_CFG_FRANCE -DVRG_COUNTRY_CFG_GERMANY -DVRG_COUNTRY_CFG_HUNGARY \
               -DVRG_COUNTRY_CFG_INDIA -DVRG_COUNTRY_CFG_ITALY -DVRG_COUNTRY_CFG_JAPAN -DVRG_COUNTRY_CFG_NETHERLANDS \
               -DVRG_COUNTRY_CFG_NEW_ZEALAND -DVRG_COUNTRY_CFG_NORTH_AMERICA -DVRG_COUNTRY_CFG_SPAIN \
               -DVRG_COUNTRY_CFG_SWEDEN -DVRG_COUNTRY_CFG_NORWAY -DVRG_COUNTRY_CFG_SWITZERLAND -DVRG_COUNTRY_CFG_TR57 \
               -DVRG_COUNTRY_CFG_UK -DVRG_COUNTRY_CFG_TAIWAN -DVRG_COUNTRY_CFG_IRELAND -DVRG_COUNTRY_CFG_CYPRUS \
               -DBRCM_SIP_TLS_SUPPORT -DVOICE_IPV6_SUPPORT -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast\
               "

CFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2','-DFEATURE_RDKB_VOICE_DM_TR104_V2','', d)}"

do_configure[depends] += "${MLPREFIX}bca-userspace-libs:do_install \
                          ${MLPREFIX}bca-mdm-layer:do_install"

inherit cmake coverity
