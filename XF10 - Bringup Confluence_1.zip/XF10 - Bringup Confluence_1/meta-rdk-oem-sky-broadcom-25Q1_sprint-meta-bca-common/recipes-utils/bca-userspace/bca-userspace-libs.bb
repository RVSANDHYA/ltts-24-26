DESCRIPTION = "BCA Userspace libraries - 504L03"
LICENSE = "CLOSED"
FILESEXTRAPATHS_prepend := "${THISDIR}:"

require bca_common.inc

DEPENDS  = "cmake-native openssl libsyswrapper virtual/kernel json-c dtc json-hal-lib bca-userspace-libs-prebuilts"
RDEPENDS_${PN}_append = " bca-userspace-libs-prebuilts"

SRC_URI = "${BROADCOM_SDK_GIT}/bca/userspace;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

S = "${WORKDIR}/git/"
SRCREV = "${AUTOREV}"
PR = "r1"

EXTRA_OECMAKE += "-DBUILD_LIBS=ON"

inherit cmake pkgconfig relative_symlinks

CFLAGS_append = " \
               -I ${S}/public/include \
               -I ${S}/public/include/linux \
               -I ${S}/private/include \
               -I ${S}/private/include/linux \
               -I ${S}/private/libs/wlcsm/include \
               -I ${STAGING_INCDIR_SHARED}/ \
               -I ${STAGING_INCDIR_SHARED}/linux \
               -I ${STAGING_INCDIR_SHARED}/net \
               -I ${STAGING_INCDIR_SHARED}/bdmf/framework/ \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/ \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/sim/ \
               -I ${STAGING_INCDIR_SHARED}/rdpa_user \
               -I ${STAGING_INCDIR_SHARED}/rdd \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/char/pmd/impl1/fw_img/ \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx/ \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/drv/phys/ \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/flash/ \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/include/ \
               -I ${STAGING_INCDIR_SHARED}/userspace/public/include/ \
               -I ${STAGING_INCDIR_SHARED}/private/include/ \
               -I ${STAGING_INCDIR_SHARED}/public/include/ \
               -I ${STAGING_INCDIR_SHARED}/json-c \
               -I ${STAGING_INCDIR_SHARED}/rdpa_gpl \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/sim \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/ \
               -I ${STAGING_INCDIR}/json-c \
               -I ${S}/public/libs/bcm_util \
               -I ${S}/public/libs/gen_util \
               -I ${S}/public/libs/bcm_boardctl \
               -I ${S}/public/libs/sys_util \
               -I ${S}/private/libs/bcm_zbus_intf \
               -I ${S}/private/libs/bcm_comp_md \
               -I ${S}/public/libs/cms_util \
               -I ${S}/private/libs/bcm_generic_hal \
               -I ${S}/private/libs/mdm_cli \
               -I ${S}/public/libs/bcm_flashutil \
               -I ${S}/public/libs/json_hal_server \
               -I ${S}/private/libs/cms_core \
               -I ${S}/private/libs/cms_core/linux \
               -I ${S}/private/libs/nvram \
               -I ${S}/private/libs/staged \
               -I ${S}/public/libs/jsonc/jsonc \
               -I ${S}/private/libs/rut_util \
               -I ${S}/public/include/linux/ \
               -I ${S}/private/libs/mdk/cdk/include/ \
               -I ${S}/private/libs/mdk/bmd/include/ \
               -I ${S}/private/libs/mdk/phy/include/ \
               -I ${S}/private/libs/mdk/cdk/arch/ \
               -I ${S}/public/libs/fdt/dtc-1.5.1 \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/\
               -I ${STAGING_INCDIR_SHARED}/userspace/private/ieee1905/include/ \
               -I ${STAGING_INCDIR_SHARED}/userspace/private/appeventd/include/ \
               -DSKY_RDKB -DBUILD_RDKWIFI -DRDK_BUILD -DCMWIFI_RDKB \
               ${BCM_FLAGS} \
               -L ${D}${libdir}\
               "

do_install_append() {

    install -d ${D}${includedir}/public/include
    install -d ${D}${includedir}/private/include
    install -d ${D}${includedir}/private/include/linux
    install -d ${D}${includedir}/public/include/linux
    install -d ${D}${includedir}/public/include/bcm_flashutil
    install -d ${D}${includedir}/public/include/bcm_boardctl
    install -d ${D}${includedir}/public/include/bcm_util
    install -d ${D}${includedir}/public/include/sys_util
    install -d ${D}${includedir}/public/include/gen_util

    install -m 0755 ${S}/public/include/*.h ${D}${includedir}/public/include/
    install -m 0755 ${S}/private/include/*.h ${D}${includedir}/private/include/
    install -m 0755 ${S}/private/include/linux/*.h ${D}${includedir}/private/include/linux/
    install -m 0755 ${S}/public/include/linux/*.h ${D}${includedir}/public/include/linux/
    install -m 0755 ${S}/public/libs/bcm_flashutil/*.h ${D}${includedir}/public/include/bcm_flashutil/
    install -m 0755 ${S}/public/libs/bcm_boardctl/*.h ${D}${includedir}/public/include/bcm_boardctl/
    install -m 0755 ${S}/public/libs/bcm_util/*.h ${D}${includedir}/public/include/bcm_util/
    install -m 0755 ${S}/public/libs/sys_util/*.h ${D}${includedir}/public/include/sys_util/
    install -m 0755 ${S}/public/libs/gen_util/*.h ${D}${includedir}/public/include/gen_util/
    install -m 0755 ${S}/private/libs/bcm_generic_hal/*.h ${D}${includedir}/private/include
    install -m 0755 ${S}/private/libs/bcm_generic_dsl_hal/*.h ${D}${includedir}/private/include
    install -m 0755 ${S}/private/libs/wlcsm/include/*.h ${D}${includedir}/private/include
    install -m 0755 ${S}/private/libs/nvram/*.h ${D}${includedir}/private/include
}

do_configure[depends] += "virtual/kernel:do_install"
do_configure[depends] += "${MLPREFIX}bca-userspace-libs-prebuilts:do_install"

FILES_${PN} += " \
        ${libdir}/* \
        ${includedir}/* \
"
INSANE_SKIP_${PN} += "dev-deps"
FILES_SOLIBSDEV = ""
INSANE_SKIP_${PN} += "dev-so"
PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"
INSANE_SKIP_${PN} += "file-rdeps"
