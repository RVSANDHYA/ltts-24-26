DESCRIPTION = "BCA Voice application"
LICENSE = "CLOSED"

# Common Bca cflags.
require recipes-utils/bca-userspace/bca_common.inc

DEPENDS += " openssl virtual/kernel bca-userspace-libs rdk-logger bca-mdm-layer bca-voicecli bca-dal-layer breakpad breakpad-wrapper"

INHIBIT_PACKAGE_STRIP = "1"

SRC_URI= "${BROADCOM_SDK_GIT}/bca/userspace;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH}"

CFLAGS+="-march=armv7-a -mno-thumb-interwork -mabi=aapcs-linux -marm -fno-common -ffixed-r8 -msoft-float -D__ARM_ARCH_7A__ -Darm -fPIC -Werror=return-type -Werror=uninitialized"

S = "${WORKDIR}/git"

VOICE = "${S}/private/apps/voice"
SRCREV = "${AUTOREV}"

LDFLAGS = " -L${STAGING_LIBDIR}/openssl-1.1.1b -L${STAGING_LIBDIR}"
LDFLAGS += "-lbreakpad_client -lbreakpadwrapper -lpthread -lstdc++ -lm"

EXTRA_OECMAKE += "-DFEATURE_RDKB_TELCOVOICE_MANAGER=ON -DFEATURE_RDKB_VOICE_DM_TR104_V2=ON"
CFLAGS_append = " \
               -I ${STAGING_INCDIR_SHARED} \
               -I ${S}/private/libs/xchg/bos/publicInc \
               -I ${S}/private/libs/xchg/str/inc \
               -I ${S}/private/libs/xchg/assert/inc \
               -I ${S}/private/libs/bcm_voice_hal \
               -I ${STAGING_INCDIR_SHARED}/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx \
               -I ${STAGING_INCDIR_SHARED}/private/include \
               -I ${S}/private/include \
               -I ${S}/private/include/linux \
               -I ${S}/public/include/linux \
               -I ${S}/public/include \
               -I ${S}/private/apps/voice/endpt/ldx/ldx_apps/dsl/apps/hausware_libs_gateway_nodist_arm/lib/arm_glibc_risc.arm.armv7.asm/ \
               -I ${STAGING_INCDIR_SHARED}/bdmf/system/linux \
               -I ${STAGING_INCDIR}/ccsp \
               -I ${STAGING_INCDIR}/syscfg \
               -I ${STAGING_INCDIR}/sysevent \
               -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
               -I ${STAGING_INCDIR}/sky/shared/opensource/include/ \
               -I ${STAGING_INCDIR}/public/include/sys_util/ \
               -I ${STAGING_INCDIR}/breakpad \
               -DINCLUDE_BREAKPAD \
               "
CFLAGS_append = "${@bb.utils.contains('DISTRO_FEATURES', 'rdkb_voice_manager_dmltr104_v2','-DFEATURE_RDKB_VOICE_DM_TR104_V2=ON','', d)}"

do_configure[depends] += "virtual/kernel:do_install"
do_configure[depends] += "${MLPREFIX}bca-userspace-libs:do_install"
do_configure[depends] += "${MLPREFIX}bca-mdm-layer:do_install"
do_configure[depends] += "${MLPREFIX}bca-dal-layer:do_install"


do_compile () {
    echo building voice application from ${VOICE}
    make BUILD_DIR=${S} -w V=99 -C ${VOICE} -f Makefile.fullsrc 2>&1
}

do_install () {
    install -d ${D}${bindir}
    install -d ${D}${sysconfdir}
    install -d ${D}${sysconfdir}/sky
    mkdir -p ${D}${sysconfdir}/telephonyProfiles.d
    cp ${VOICE}/prov/tel_profiles/sky_profiles/* ${D}${sysconfdir}/telephonyProfiles.d
    install -m 755 ${VOICE}/voice ${D}${bindir}
}

FILES_${PN} += " \
        ${bindir}/* \
    "

SOLIBS = ".so"
FILES_SOLIBSDEV = ""
INSANE_SKIP_${PN} = "ldflags already-stripped dev-so"
PACKAGE_DEBUG_SPLIT_STYLE = "debug-without-src"

# generating minidumps symbols
inherit breakpad-wrapper
#DEPENDS += "breakpad"

#LDFLAGS += "-lbreakpad_client -lpthread -lstdc++ -lm"

# generating minidumps
PACKAGECONFIG_append = " breakpad"
