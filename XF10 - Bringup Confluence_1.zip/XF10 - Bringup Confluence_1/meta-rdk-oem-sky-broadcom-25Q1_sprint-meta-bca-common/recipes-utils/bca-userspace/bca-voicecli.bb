SUMMARY = "BCA - voicecli application"
LICENSE = "CLOSED"

DEPENDS += "bca-userspace-apps"

SRC_URI = "${RDKB_COMPONENTS_ROOT_GIT}/sdk/devices/sky/sr300/common;protocol=${RDK_GIT_PROTOCOL};branch=${CCSP_GIT_BRANCH};name=voicecli"

SRCREV = "${AUTOREV}"

S = "${WORKDIR}/git/private/apps/voicecli"

LDFLAGS += " -L ${STAGING_LIBDIR} "

CFLAGS_append = " \
               -I ${STAGING_INCDIR_SHARED} \
               -I ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx \
               -I ${STAGING_INCDIR}/public/include \
               -I ${STAGING_INCDIR}/public/include/linux \
               -I ${STAGING_INCDIR}/private/include \
               -I ${STAGING_INCDIR}/userspace/private/include/ \
               -I ${STAGING_INCDIR}/sky/userspace/public/include/ \
               -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast\
               "

inherit cmake