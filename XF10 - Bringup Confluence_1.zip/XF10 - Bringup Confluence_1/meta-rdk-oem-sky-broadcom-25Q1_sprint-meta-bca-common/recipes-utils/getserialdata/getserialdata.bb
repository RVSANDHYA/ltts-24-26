DESCRIPTION = "Serial Data Application"
LICENSE = "CLOSED"

FILEXTRAPATHS_prepend := "${THISDIR}/files:"

SRC_URI = "file://getserialdata.c \
           file://getserialdata.h \
          "

inherit pkgconfig

do_compile () {

    ${CC} ${WORKDIR}/getserialdata.c ${CFLAGS} -o ${WORKDIR}/getserialdata
}

do_install () {

    install -d ${D}${bindir}
    install -m 755 ${WORKDIR}/getserialdata  ${D}${bindir}   

}

FILES_${PN} += " \
        ${bindir}/* \
    "
