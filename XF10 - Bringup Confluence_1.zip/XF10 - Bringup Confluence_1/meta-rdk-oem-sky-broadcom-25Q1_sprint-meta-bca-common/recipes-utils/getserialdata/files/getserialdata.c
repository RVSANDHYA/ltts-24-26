/*
 * Project: XLE/ASHLENE
 * File   : getserialdata.c
 * Date   : 04/03/2021
 *
 * Utility application to read all board specific parameters from
 * /proc/enviornment & dump into file. Uboot provides all these environemnt
 * fields, and exposed to /proc/environment.
 */

#include <dirent.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_DATA_LENGTH 63
#define MAX_STRING_LENGTH 128
#define MAX_VAPS 16
#define PRIVATE_WIFI_2G 1
#define PRIVATE_WIFI_5G 2
#define MESH_WIFI_BH_2G 13
#define MESH_WIFI_BH_5G 14

#define ENVIRONMENT_FILE "/proc/environment/"
#define BUILDSTRING "BuildString"
#define ADSLUSER "ADSLUser"
#define ADSLPASS "ADSLPass"
#define FACTORYSSID "factorySSID"
#define FACTORYPUBLICKEY "factoryPublicKey"
#define WIFIPASSWORD "wifiPassword"
#ifdef WNXL11BWL
#define FACTORYMODEL "ModelName"
#define SERAILNUMBER "serialNum"
#define HARDWAREVERSION "HW"
#else
#define FACTORYMODEL "factoryModel"
#define SERAILNUMBER "factorySerialNumber"
#define HARDWAREVERSION "factoryHardwareVersion"
#endif
#define FACTORYPERMIT "factoryPermit"
#define WPSPIN "WPSPin"
#define BASEMAC "ethaddr"
#define SERIAL_OUT_FILE "/tmp/serial.txt"
#define RETURN_OK 0
#define RETURN_FAILURE -1

/**
 * @brief Structure object used to store serialisation data.
 */
typedef struct _serialisation_data {
    char BuildString[MAX_DATA_LENGTH];
    char BaseMac[MAX_DATA_LENGTH];
    char factorySSID[MAX_DATA_LENGTH];
    char factoryPublicKey[MAX_DATA_LENGTH];
    char wifiPassword[MAX_DATA_LENGTH];
    char factorySerialNumber[MAX_DATA_LENGTH];
    char factoryHardwareVersion[MAX_DATA_LENGTH];
    char factoryModel[MAX_DATA_LENGTH];
    char factoryPermit[MAX_DATA_LENGTH];
    char WPSPin[MAX_DATA_LENGTH];
} serialisation_data_t;

/**
 * Global structure object to store the data.
 */
static serialisation_data_t serial_data;

/* Static function Prototype Starts. */

/**
 *  @brief write the serial information to /tmp/serial.txt
 *
 *  This function dump all the parameters into /tmp/serial.txt as
 *  key=value pair.
 *
 *  @return return none
 */
static void dump_env_data_into_file(void);

/**
 *  @brief Read environment field from /proc/environment
 *
 *  Read value from /proc/environment/<filename> and stored into
 *  incoming string object.
 *
 *  @param proc_file - String pointing to /proc/environment file name
 *  @param env_value - String to strore value read from /proc
 *
 *  @return return RETURN_OK if its read properly else RETURN_FAILURE
 */
static int get_env_value_from_procfs(const char *proc_file, char *env_value);

/**
 *  @brief Utility API to check the environment string value is required
 *
 *  Compare incoming string against required fields and return false if match
 *  not found.
 *
 *  @param name - String contains environment file in /proc/environment
 *  @return return none
 */
static bool check_is_required_field(const char *name);

/**
 *  @brief Read all the required fields from /proc/environment and store into
 * global structure
 *
 *  @return return none
 */
static int read_all_board_env_data();

/**
 *  @brief Utility API to store environment data into global structure object.
 *
 *  Compare incoming string against required fields and store it is into the
 *  global structure object.
 *
 *  @param name - String contains environment file name as well as its content
 * value.
 *  @return return RETURN_OK if its properly did else returned RETURN_FAILURE.
 */
static int store_board_env_data(const char *env_name, const char *env_val);
/* Static function Prototype Ends. */

static int get_env_value_from_procfs(const char *proc_file, char *env_value) {
    if (NULL == proc_file || NULL == env_value) {
        printf("Invalid memory \n");
        return RETURN_FAILURE;
    }

    FILE *fp = NULL;
    fp = fopen(proc_file, "r");
    if (NULL == fp) {
        printf("Failed to open %s file \n", proc_file);
        return RETURN_FAILURE;
    }

    if (NULL == fgets(env_value, MAX_DATA_LENGTH, fp)) {
        printf("Failed to read from %s file \n", proc_file);
        fclose(fp);
        return RETURN_FAILURE;
    }

    fclose(fp);
    return RETURN_OK;
}

static bool check_is_required_field(const char *name) {
    int is_required = false;
    if (NULL == name)
        return is_required;

    if ((strncmp(name, BUILDSTRING, strlen(BUILDSTRING)) == 0) ||
        (strncmp(name, FACTORYSSID, strlen(FACTORYSSID)) == 0) ||
        (strncmp(name, WIFIPASSWORD, strlen(WIFIPASSWORD)) == 0) ||
        (strncmp(name, SERAILNUMBER, strlen(SERAILNUMBER)) == 0) ||
        (strncmp(name, HARDWAREVERSION, strlen(HARDWAREVERSION)) == 0) ||
        (strncmp(name, FACTORYMODEL, strlen(FACTORYMODEL)) == 0) ||
        (strncmp(name, WPSPIN, strlen(WPSPIN)) == 0) ||
        (strncmp(name, BASEMAC, strlen(BASEMAC)) == 0) ||
        (strncmp(name, FACTORYPUBLICKEY, strlen(FACTORYPUBLICKEY)) == 0) ||
        (strncmp(name, FACTORYPERMIT, strlen(FACTORYPERMIT)) == 0)) {
        is_required = true;
    }
    return is_required;
}
static int store_board_env_data(const char *env_name, const char *env_val) {
    if (NULL == env_name || NULL == env_val) {
        printf("Invalid argments \n");
        return RETURN_FAILURE;
    }

    if (strncmp(env_name, BUILDSTRING, strlen(BUILDSTRING)) == 0) {
        strncpy(serial_data.BuildString, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, FACTORYSSID, strlen(FACTORYSSID)) == 0) {
        strncpy(serial_data.factorySSID, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, WIFIPASSWORD, strlen(WIFIPASSWORD)) == 0) {
        strncpy(serial_data.wifiPassword, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, SERAILNUMBER, strlen(SERAILNUMBER)) == 0) {
        strncpy(serial_data.factorySerialNumber, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, HARDWAREVERSION, strlen(HARDWAREVERSION)) ==
               0) {
        strncpy(serial_data.factoryHardwareVersion, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, FACTORYMODEL, strlen(FACTORYMODEL)) == 0) {
        strncpy(serial_data.factoryModel, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, WPSPIN, strlen(WPSPIN)) == 0) {
        strncpy(serial_data.WPSPin, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, BASEMAC, strlen(BASEMAC)) == 0) {
        /**
         * remove ':' from mac and store mac address.
         */
        char macAddrBuf[MAX_DATA_LENGTH] = {0};
        int i, j = 0;
        for (i = 0; i < 18; i++) {
            if (env_val[i] == ':')
                continue;

            macAddrBuf[j] = env_val[i];
            ++j;
        }
        strncpy(serial_data.BaseMac, macAddrBuf, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, FACTORYPUBLICKEY, strlen(FACTORYPUBLICKEY)) ==
               0) {
        strncpy(serial_data.factoryPublicKey, env_val, MAX_DATA_LENGTH);
    } else if (strncmp(env_name, FACTORYPERMIT, strlen(FACTORYPERMIT)) == 0) {
        strncpy(serial_data.factoryPermit, env_val, MAX_DATA_LENGTH);
    }

    return RETURN_OK;
}
static int read_all_board_env_data() {
    DIR *dir;
    struct dirent *next;
    char proc_name[MAX_STRING_LENGTH];
    char proc_val[MAX_DATA_LENGTH];

    dir = opendir(ENVIRONMENT_FILE);
    if (NULL != dir) {
        while ((next = readdir(dir)) != NULL) {
            memset(proc_name, 0, sizeof(proc_name));
            memset(proc_val, 0, sizeof(proc_val));
            if (check_is_required_field(next->d_name)) {
                snprintf(proc_name, sizeof(proc_name), "%s/%s",
                         ENVIRONMENT_FILE, next->d_name);
                if (RETURN_OK ==
                    get_env_value_from_procfs(proc_name, proc_val)) {
                    store_board_env_data(next->d_name, proc_val);
                }
            }
        }
        closedir(dir);
    }
    return RETURN_OK;
}

static void dump_env_data_into_file(void) {
    char outString[MAX_STRING_LENGTH];
    int fd;
    int number;

    fd = open(SERIAL_OUT_FILE, O_CREAT | O_WRONLY);
    if (fd < 0) {
        printf("ERROR - Could not write serial data file\r\n");
        return;
    }

    sprintf(outString, "BUILD=%s\r\n", serial_data.BuildString);
    write(fd, outString, strlen(outString));

    sprintf(outString, "BASEMAC=%s\r\n", serial_data.BaseMac);
    write(fd, outString, strlen(outString));

    sprintf(outString, "FACTORYSSID=%s\r\n", serial_data.factorySSID);
    write(fd, outString, strlen(outString));

    sprintf(outString, "WIFIPASSWORD=%s\r\n", serial_data.wifiPassword);
    write(fd, outString, strlen(outString));

    sprintf(outString, "SERIAL=%s\r\n", serial_data.factorySerialNumber);
    write(fd, outString, strlen(outString));

    serial_data.factorySerialNumber[2] = 0;
#ifdef WNXL11BWL
    	char value[16] = {0};
        char DEVICE_SERIAL_NUMBER[16];
	char SYNDICATION_PARTNER_CODE;
	FILE *fp = NULL;
        fp = popen("grep \"DEVICE_SERIAL_NUMBER=\" /tmp/serial.txt | cut -d '=' -f 2 | tr -d '\r\n'","r");
        if (fp != NULL) {
        while(fgets(value, sizeof(value), fp) != NULL) {
                strncpy(DEVICE_SERIAL_NUMBER, value, strlen(value));
        }
        pclose(fp);
	SYNDICATION_PARTNER_CODE=DEVICE_SERIAL_NUMBER[7]; //8th character of serial number is the SYNDICATION_PARTNER_CODE
	//for SHAW,ROGERS,VIDEOTRON partners REGION is CA
	if (SYNDICATION_PARTNER_CODE == 'R' || SYNDICATION_PARTNER_CODE == 'S' || SYNDICATION_PARTNER_CODE == 'V') {
		sprintf(outString, "REGION=CA\r\nTIMEZONE=pr\n");
	}
	else {
		sprintf(outString, "REGION=US\r\nTIMEZONE=pr\n");
	}		
    	}
	else
	{
		sprintf(outString, "REGION=US\r\nTIMEZONE=pr\n"); //default region is US
	}
	write(fd, outString, strlen(outString));
#else
    number = (int)strtol(serial_data.factorySerialNumber, NULL, 16);
    if ((number == 0xCF) || (number == 0xD7)) {
        sprintf(outString, "REGION=IT\r\nTIMEZONE=Europe/CET\r\n");
        write(fd, outString, strlen(outString));
    } else {
        sprintf(outString, "REGION=GB\r\nTIMEZONE=Europe/London\r\n");
        write(fd, outString, strlen(outString));
    }
#endif

    sprintf(outString, "HARDWAREVERSION=%s\r\n",
            serial_data.factoryHardwareVersion);
    write(fd, outString, strlen(outString));

    sprintf(outString, "MODEL=%s\r\n", serial_data.factoryModel);
    write(fd, outString, strlen(outString));

    /*
     * Set up all of the APs
     */
    for (int i = 1; i <= MAX_VAPS; i++) {
        if (i == PRIVATE_WIFI_2G) {
            sprintf(outString, "WPSPIN=%s\r\n", serial_data.WPSPin);
            write(fd, outString, strlen(outString));
            sprintf(outString, "WPS_ENABLE=2\r\n");
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_RADIO_ID=%d\r\n", (i % 2 ? 0 : 1));
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_SSID=%s\r\n", serial_data.factorySSID);
            write(fd, outString, strlen(outString));
            sprintf(outString, "PSK_KEY=%s\r\n", serial_data.wifiPassword);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_ENABLE=1\r\n");
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_WMMEN=1\r\n");
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_HIDESSID=0\r\n");
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_SECMODE=WPA\r\n");
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_CYPHER=CCMP\r\n");
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_WPA_%d=3\r\n", i);
            write(fd, outString, strlen(outString));

        } else if (i == PRIVATE_WIFI_5G) {
            sprintf(outString, "WPSPIN_%d=%s\r\n", i, serial_data.WPSPin);
            write(fd, outString, strlen(outString));
            sprintf(outString, "WPS_ENABLE_%d=2\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_RADIO_ID_%d=%d\r\n", i, (i % 2 ? 0 : 1));
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_SSID_%d=%s\r\n", i, serial_data.factorySSID);
            write(fd, outString, strlen(outString));
            sprintf(outString, "PSK_KEY_%d=%s\r\n", i,
                    serial_data.wifiPassword);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_ENABLE_%d=1\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_WMMEN_%d=1\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_HIDESSID_%d=0\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_SECMODE_%d=WPA\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_CYPHER_%d=CCMP\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_WPA_%d=3\r\n", i);
            write(fd, outString, strlen(outString));
        } else {
            sprintf(outString, "WPSPIN_%d=%s\r\n", i, serial_data.WPSPin);
            write(fd, outString, strlen(outString));
            sprintf(outString, "WPS_ENABLE_%d=0\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_RADIO_ID_%d=%d\r\n", i, (i % 2 ? 0 : 1));
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_SSID_%d=OutOfService\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "PSK_KEY_%d=1234567890\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_ENABLE_%d=0\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_WMMEN_%d=0\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_HIDESSID_%d=1\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_SECMODE_%d=WPA\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_CYPHER_%d=CCMP\r\n", i);
            write(fd, outString, strlen(outString));
            sprintf(outString, "AP_WPA_%d=3\r\n", i);
            write(fd, outString, strlen(outString));
        }
    }
    close(fd);
}

/* Main Routine. */
int main(int argc, char **argv) {
    if (RETURN_OK == read_all_board_env_data()) {
        dump_env_data_into_file();
    }
    return 0;
}
