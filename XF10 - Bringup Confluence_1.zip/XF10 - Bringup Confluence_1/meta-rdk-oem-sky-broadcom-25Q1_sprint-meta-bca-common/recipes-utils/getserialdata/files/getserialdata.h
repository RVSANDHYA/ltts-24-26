#ifndef __SKY_GETSERIAL_H__
#define __SKY_GETSERIAL_H__

#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>

#endif /* __SKY_GETSERIAL_H__ */
