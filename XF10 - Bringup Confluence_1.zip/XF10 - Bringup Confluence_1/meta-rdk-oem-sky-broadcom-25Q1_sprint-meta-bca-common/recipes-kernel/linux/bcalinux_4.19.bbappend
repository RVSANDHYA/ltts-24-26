FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

DEPENDS += " openssl-native"

SRC_URI += " file://0001-Boops-support-in-mmc-and-ubi-controller.patch"
SRC_URI += " file://0002-Wlan-impl87-integration_21_2.patch"
SRC_URI += " file://0003-Disable-Interrupt-for-kernel-corruption.patch"
SRC_URI += " file://0004-Fix-Compilation-Issue-With-OpenSSL.patch"
SRC_URI += " file://0005-Sky-Broadcom-WiFi-Driver-Changes.patch"
SRC_URI += " file://0008-sky-bcn-vendor-details.patch"
SRC_URI += " file://0009-sharman-336-wl-status.patch"
SRC_URI += " file://0006-CS00012261040--Data-Communication-Stalled-over-GRE-tunnel.patch"
SRC_URI += " file://0006-wifi-iface-validation-wldm.patch"
SRC_URI += " file://0007-Secure-Otp-Read.patch"
SRC_URI += " file://0008-CS00012264459-Kernel-Crash-From-WFD.patch"
SRC_URI += " file://patch.version"

do_compile_prepend () {
   cp -fr ${WORKDIR}/patch.version ${S}/
}

do_install_append () {

    install -d ${STAGING_DIR_SHARED}
    install -d ${STAGING_INCDIR_SHARED}

    # Install all the headers needed for sky userspace application
    install -d ${STAGING_INCDIR_SHARED}/userspace/public/include
    install -d ${STAGING_INCDIR_SHARED}/userspace/private/include

    # Install all the headers associated with the bcm963xx into shared sysroot.
    install -d ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx/
    install -d ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx/bcm
    install -d ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx
    install -d ${STAGING_INCDIR_SHARED}/rdpa_user/
    install -d ${STAGING_INCDIR_SHARED}/bdmf/framework/
    install -d ${STAGING_INCDIR_SHARED}/shared/opensource/drv/phys/
    install -d ${STAGING_INCDIR_SHARED}/rdpa_gpl
    install -d ${STAGING_INCDIR_SHARED}/rdd
    install -d ${STAGING_INCDIR_SHARED}/shared/opensource/flash
    install -d ${STAGING_INCDIR_SHARED}/bdmf/system/sim
    install -d ${STAGING_INCDIR_SHARED}/bdmf/system/
    install -d ${STAGING_INCDIR_SHARED}/bdmf/system/linux
    install -d ${STAGING_INCDIR_SHARED}/userspace/private/bcmcrypto/include
    install -d ${STAGING_INCDIR_SHARED}/userspace/private/ieee1905/include
    install -d ${STAGING_INCDIR_SHARED}/userspace/private/appeventd/include
    install -d ${STAGING_INCDIR_SHARED}/userspace/private/math/include
    install -d ${STAGING_DIR_SHARED}/bcmdrivers/wifi

    install -d ${STAGING_DIR_SHARED}/etc/

    install -m 644 ${S}/shared/opensource/include/bcm963xx/boardparms.h ${STAGING_INCDIR_SHARED}/userspace/private/include
    install -m 644 ${S}/shared/opensource/include/bcm963xx/*.h ${STAGING_INCDIR_SHARED}/shared/opensource/include/bcm963xx

    install -m 644 ${S}/rdp/drivers/bdmf/system/*.h ${STAGING_INCDIR_SHARED}/bdmf/system/
    install -m 644 ${S}/rdp/drivers/bdmf/system/sim/*.h ${STAGING_INCDIR_SHARED}/bdmf/system/sim/

    install -m 644 ${S}/bcmdrivers/opensource/phy/*.h ${STAGING_INCDIR_SHARED}/shared/opensource/drv/phys/
    install -m 644 ${S}/bcmdrivers/opensource/include/bcm963xx/*.h ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx/
    install -m 644 ${S}/bcmdrivers/opensource/include/bcm963xx/bcm/*.h ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx/bcm
    install -m 644 ${S}/bcmdrivers/broadcom/include/bcm963xx/*.h ${STAGING_INCDIR_SHARED}/bcmdrivers/broadcom/include/bcm963xx/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/src/include/*.h ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/char/pmd/impl1/fw_img/*.h ${STAGING_INCDIR_SHARED}/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/router/shared/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/sys/src/shared/bcmwifi/include/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/proto/include/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/src/shared/bcm_app_utils.c ${STAGING_DIR_SHARED}/bcmdrivers/wifi/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/math/src/*.c ${STAGING_DIR_SHARED}/bcmdrivers/wifi/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/math/src/*.h ${STAGING_DIR_SHARED}/bcmdrivers/wifi/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/wlioctl/include/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/sys/components/apps/hspot/router/shared/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/router/bcmdrv/include/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/router/rc/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/router/bshared/include/*.h   ${STAGING_INCDIR_SHARED}/userspace/private/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/bcmcrypto/include/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/bcmcrypto/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/apps/ieee1905/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/ieee1905/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/math/include/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/math/include/
    install -m 644 ${S}/bcmdrivers/broadcom/net/wl/impl87/main/components/apps/appeventd/*.h  ${STAGING_INCDIR_SHARED}/userspace/private/appeventd/include/

    install -m 644 ${S}/bcmdrivers/opensource/char/bcm_knvram/impl1/include/*.h ${STAGING_INCDIR_SHARED}/userspace/private/include/

    cp -fr ${S}/kernel/bcm_local_kernel_include/ ${STAGING_INCDIR_SHARED}/
    cp -rf ${S}/kernel/bcmkernel/include/uapi/linux ${STAGING_INCDIR_SHARED}/

    # Install DSL fw file.
    if [ -e ${S}/bcmdrivers/broadcom/char/adsl/impl1/adsl_phy.bin ]; then
        install -m 755 ${S}/bcmdrivers/broadcom/char/adsl/impl1/adsl_phy.bin ${STAGING_DIR_SHARED}/etc/
    fi

    # Install build profile.
    install -m 755 ${S}/targets/${BRCM_SOC_PROFILE}/${BRCM_SOC_PROFILE} ${STAGING_DIR_SHARED}/etc/build_profile
}
