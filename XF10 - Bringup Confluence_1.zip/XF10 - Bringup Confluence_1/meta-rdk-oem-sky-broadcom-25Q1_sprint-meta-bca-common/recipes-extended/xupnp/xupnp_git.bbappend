do_install_append() {
        install -d ${D}${sysconfdir}
        install -d ${D}${base_libdir}/rdk
        install -d ${D}${systemd_unitdir}/system/
        install -m 0644 ${S}/conf/broadband/xdiscovery.conf ${D}${sysconfdir}
        install -m 0644 ${S}/conf/systemd/xdevice.conf ${D}${sysconfdir}
        install -m 0755 ${S}/conf/broadband/systemd/start_upnp.sh ${D}${base_libdir}/rdk/start_upnp.sh
        install -m 0755 ${S}/conf/broadband/zcip.script ${D}${base_libdir}/rdk/zcip.script
        install -m 0755 ${S}/conf/broadband/systemd/xcal-device-client.service ${D}${systemd_unitdir}/system/xcal-device.service
        install -m 0755 ${S}/conf/broadband/systemd/xupnp.service ${D}${systemd_unitdir}/system/xupnp.service

}

do_install_append_dunfell() {
        sed -i '/After=/ a Requires=rdkssainit.service' ${D}${systemd_unitdir}/system/xcal-device.service
        sed -i '/ExecStart=/ a SuccessExitStatus=SIGTERM' ${D}${systemd_unitdir}/system/xcal-device.service
        sed -i '/Restart=always/ a TimeoutStartSec=120' ${D}${systemd_unitdir}/system/xcal-device.service
}

SYSTEMD_SERVICE_${PN} += "xcal-device.service"
FILES_${PN}_append_broadband = " ${base_libdir}/rdk/start_upnp.sh"
FILES_${PN}_append_broadband = " ${base_libdir}/rdk/zcip.script"
FILES_${PN}_append_broadband = " ${systemd_unitdir}/system/xcal-device.service"
FILES_${PN}_append_broadband = " ${systemd_unitdir}/system/xupnp.service"
