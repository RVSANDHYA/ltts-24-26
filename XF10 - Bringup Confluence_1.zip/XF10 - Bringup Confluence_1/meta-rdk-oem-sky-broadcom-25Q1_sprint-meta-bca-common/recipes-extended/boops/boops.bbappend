FILESEXTRAPATHS_prepend := "${THISDIR}/${PN}:"

SRC_URI += "file://sky_traceKernelPanic.sh"

CFLAGS_append = " \
    -I ${STAGING_INCDIR_SHARED}/ \
"

do_install_append () {
    install -d ${D}/${sysconfdir}/sky
    install -m 755 ${WORKDIR}/sky_traceKernelPanic.sh ${D}/${sysconfdir}/sky
}
FILES_${PN} += " ${sysconfdir}/sky/sky_traceKernelPanic.sh"

do_configure[depends] += " boops-k:do_install"
