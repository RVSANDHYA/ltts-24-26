/*
 * stm32f407xx_gpio_driver.c
 *
 *  Created on: May 8, 2025
 *      Author: 40042293
 */

#include"stm32f07xx_gpio.h"

void GPIO_PeriClockControl(GPIO_RegDef_t *pGPIOx, uint8_t EnorDi)
{
	if(EnorDi==ENABLE)
	{
		if(pGPIOx==GPIOA)
			GPIOA_PCLK_EN();
		else if(pGPIOx==GPIOD)
			GPIOD_PCLK_EN();
	}
	else if(EnorDi==DISABLE)
	{
		if(pGPIOx==GPIOA)
			GPIOA_PCLK_DI();
		else if(pGPIOx==GPIOD)
			GPIOD_PCLK_DI();
	}
}

void GPIO_Init(GPIO_Handle_t *pGPIOHandle)
{
	//temp=(pPIOHANDLE->MODE)<<(2*pinno)==>01<<(2*15)
	//&=~()
	//pPIOHANDLE->MODE|=temp;
	uint32_t temp=0;
	//MODE config
		temp=(pGPIOHandle->GPIO_PinConfig.GPIO_PinMode)<<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber);
		pGPIOHandle->pGPIOx->MODER &=~(0x3<<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->MODER |=temp;
	//Speed Config
		temp=(pGPIOHandle->GPIO_PinConfig.GPIO_PinSpeed << (2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->OSPEEDR &= ~(0x3 <<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->OSPEEDR |=temp;
		//PUPD
		temp=(pGPIOHandle->GPIO_PinConfig.GPIO_PinPuPdControl << (2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->PUPDR &= ~(0x3 <<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->PUPDR |=temp;
		//OPType
		temp=(pGPIOHandle->GPIO_PinConfig.GPIO_PinOPType << (1*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->OTYPER &= ~(0x3 <<(1*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
		pGPIOHandle->pGPIOx->OTYPER |=temp;
}
void GPIO_ToggleOutputPin(GPIO_RegDef_t *pGPIOx,uint8_t PinNumber)
{
	pGPIOx->ODR ^= (1<<PinNumber);
}
uint8_t GPIO_ReadFromInputPin(GPIO_RegDef_t *pGPIOx,uint8_t PinNumber)
{
	uint8_t v;
	v=(pGPIOx->IDR)>>(PinNumber);
	return v;
}
