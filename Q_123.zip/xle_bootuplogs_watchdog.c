p/WNXL11BWL_BCA_PLATFORM_20250102103106.bin
[MILESTONE]xboot_plat_init:[103] xboot_plat_support version=4.0.1 [Dec 23 2022 17:29:07]
[FW-INFO]main:[63] File size 0x45fc000 (73383936)

[FW-INFO]main:[86] Active PCI bank is PCI1

[FW-INFO]main:[87] Flashing file /tmp/WNXL11BWL_BCA_PLATFORM_20250102103106.bin to PCI2 space @15800000 size=12000000

sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 27sec irq!
[FW-INFO]xboot_plat_firmware_flashing:[1242] filename is /tmp/WNXL11BWL_BCA_PLATFORM_20250102103106.bin
[FW-INFO]xboot_plat_is_bl_update_required:[868] Unsecure device. Hence BL can be updated.
[FW-INFO]xboot_plat_is_firmware_update_required:[904] Checking if PCI image is having new firmware
[FW-INFO]xboot_plat_is_firmware_update_required:[929] NON SECURE board, skipping prod BL update
[FW-INFO]xboot_plat_is_firmware_update_required:[947] Comparing bl present in box and in PCI image
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 27sec irq!
[FW-INFO]main:[111] Flashed and verified file /tmp/WNXL11BWL_BCA_PLATFORM_20250102103106.bin to PCI2 space

[FW-INFO]main:[181] Launch bank is set to PCI2

[FW-INFO]xboot_plat_manage_bootcookie_state:[1643] Before update boot cookie ->
                 Current State: [BL FLASH COMPLETED] |  Current Boot cookie: [0] | Active PCI Bank: [1]
[FW-INFO]xboot_plat_manage_bootcookie_state:[1675] After update boot cookie  ->
         Boot cookie: [0]
root@xle-wnc:~# net_ratelimit: 22 callbacks suppressed
WLC_GET_ASSOCLIST error -14
Disconnect STA : ff:ff:ff:ff:ff:ff scb_val.val 2
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
CSIMON:  CSIMON[1.1.0] Initialization
CSIMON: M2M usr already registered ...
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
CSIMON:  CSIMON[1.1.0] Initialization
CSIMON: M2M usr already registered ...
DBG wl1: vasip 3x3 11ax ver 6.5205 2
CSIMON:  CSIMON[1.1.0] Initialization
CSIMON: M2M usr already registered ...
DBG wl1: vasip 3x3 11ax ver 6.5205 2
CSIMON:  CSIMON[1.1.0] Initialization
CSIMON: M2M usr already registered ...
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 27sec irq!
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 27sec irq!
 wlc_fatal_error 2567: wl0: fatal error, reinitializing, total count of reinit's[3]
CSIMON:  CSIMON[1.1.0] Initialization
CSIMON: M2M usr already registered ...
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 27sec irq!

root@xle-wnc:~# reboot
[  OK  ] Removed slice system-dropbear.slice.
[  OK  ] Stopped State Red Firware Download App.
[  OK  ] Stopped A Upnp service path file.
[  OK  ] Stopped target Network (Pre).
[  OK  ] Stopped target NTP Synchronization Complete.
[  OK  ] Stopped target Remote File Systems.
[  OK  ] Stopped target Timers.
[  OK  ] Stopped Daily rotation of log files.
[  OK  ] Stopped Daily Cleanup of Temporary Directories.
    sreehari: bcm96xxx_wdt_stop
     Stopping CcspTelemetry service...
[  OK  ] Stopped Broadcom GRE Tunnel Setup Service.
[  OK  ] Stopped BCA License Init Service.
[  OK  ] Stopped Create Broadocm Static Device Nodes in /dev.
         Stopping Start Broadcom Watchdog Timer...
[  OK  ] Stopped SSH Key Generation.
         Stopping Mesh Agent service...
         Stopping Mesh Wifi service...
         Starting Reboot handler Task At reboot...
         Stopping rfc_agent service...
[  OK  ] Stopped Apply Kernel Variables.
[  OK  ] Stopped Update is Completed.
[  OK  ] Stopped Rebuild Journal Catalog.
[  OK  ] Stopped Timer to log start & end date of static and dynamic operational certificates.
[  OK  ] Stopped Minidump Upload for Bootup crashes.
[  OK  ] Stopped target Login Prompts.
         Stopping CcspEthAgent service...
         Stopping CcspTandDSsp service...
[  OK  ] Stopped CcspXconf service.
         Stopping GatewayManager service...
         Stopping Firmware Upgrade Manager service...
         Stopping RDK InterDeviceManager service...
         Stopping Rdk Led Manager service...
         Stopping RDK FanManager service...
         Stopping ServiceCtrl service...
[  OK  ] Stopped BLE init and firmware version check.
[  OK  ] Stopped DNS forwarder and DHCP server.
         Stopping Getty on tty1...
         Stopping GwProvApp service...
[  OK  ] Stopped IPv6 Packet Filtering Framework.
[  OK  ] Stopped IPv4 Packet Filtering Framework.
         Stopping XLE LED Assistant service...
[  OK  ] Stopped log associated mac list service.
         Stopping Log Dmesg...
[  OK  ] Stopped Enable OCSP support based on RFC.
[  OK  ] Stopped Random file upload service.
         Stopping         Stopping Serial Getty on ttyAMA0...
         Stopping Speedtest for LTE...
         Stopping System Logger Daemon "default" instance...
         Stopping Update UTMP about System Boot/Shutdown...
         Stopping webconfig service...
         Stopping XLE Self Heal service...
[  OK  ] Stopped Serial Getty on ttyAMA0.
[  OK  ] Stopped Capture rbus rtRouâ�… logs. Only for RDK-B devices.
[  OK  ] Stopped Session manager for rbus.
[  OK  ] Stopped XLE LED Assistant service.
[  OK  ] Stopped Reset button handler service.
[  OK  ] Stopped System Logger Daemon "default" instance.
[  OK  ] Stopped Log Dmesg.
[  OK  ] Stopped Mesh Agent service.
[  OK  ] Stopped RFC service.
[  OK  ] Stopped Getty on tty1.
[  OK  ] Stopped Start Broadcom Watchdog Timer.
[  OK  ] Stopped rfc_agent service.
[  OK  ] Stopped GatewayManager service.
[  OK  ] Stopped Firmware Upgrade Manager service.
[  OK  ] Stopped Rdk Led Manager service.
[  OK  ] Stopped RDK InterDeviceManager service.
[  OK  ] Stopped RDK FanManager service.
[  OK  ] Stopped Speedtest for LTE.
[  OK  ] Stopped ServiceCtrl service.
[  OK  ] Stopped CcspTandDSsp service.
[  OK  ] Stopped CcspEthAgent service.
[  OK  ] Stopped webconfig service.
[  OK  ] Stopped GwProvApp service.
[  OK  ] Stopped CcspTelemetry service.
echo[15402]: XLE OneWiFi SelfHeal  Stopping
[  OK  ] Stopped XLE Self Heal service.
[  OK  ] Removed slice system-getty.slice.
[  OK  ] Removed slice system-serial\x2dgetty.slice.
[  OK  ] Removed slice system-syslog\x2dng.slice.
[  OK  ] Stopped target WiFi Initialization Complete.
[  OK  ] Stopped target WiFi Telemetry Service Group.
         Stopping RDK Cellular Manager service...
         Stopping harvester service...
         Stopping Notify Comp service...
         Stopping Cosa service...
         Stopping An IPC framework...
         Stopping webpa service...
[  OK  ] Stopped WiFi Telemetry Initial Cron Job Setup.
[  OK  ] Stopped Update UTMP about System Boot/Shutdown.
[  OK  ] Stopped An IPC framework.
[  OK  ] Stopped harvester service.
[  OK  ] Stopped Notify Comp service.
[  OK  ] Stopped webpa service.
[  OK  ] Stopped A daemon that creates a device.
[  OK  ] Stopped xpki certificate aquisition.
         Stopping Network Time Service...
[  OK  ] Stopped Create Volatile Files and Directories.
[  OK  ] Stopped target Local File Systems.
         Unmounting /data...
         Unmounting /etc/dhcp_static_hosts...
         Unmounting /etc/dibbler...
         Unmounting /etc/dropbear...
         Unmounting /etc/hostname...
         Unmounting /etc/hosts...
         Unmounting /etc/machine-id...
         Unmounting /etc/resolv.conf...
sh[15478]: AT+CFUN=1,1
sh[15478]: OK
         Unmounting /etc/resolv.dnsmasq...
         Unmounting /etc/xupnp...
         Unmounting /home...
         Unmounting /media...
         Unmounting /mnt/defaults...
         Unmounting /nvram/secure...
         Unmounting /nvram2...
         Unmounting /opt/secure...
         Unmounting /rdklogs...
         Stopping Flush Journal to Persistent Storage...
         Stopping Bind mount volatile /etc/dibbler...
         Stopping Bind mount volatile /etc/dropbear...
         Stopping Bind mount volatile /etc/dhcp_static_hosts...
         Stopping Bind mount volatile /etc/hostname...
         Stopping Bind mount volatile /etc/hosts...
         Stopping Bind mount volatile /media...
         Stopping Bind mount volatile /etc/resolv.conf...
         Stopping Bind mount volatile /etc/resolv.dnsmasq...
         Stopping Bind mount volatile /etc/wlan/nvram/...
         Stopping Bind mount volatile /etc/xupnp...
[  OK  ] Unmounted /etc/wlan/nvram.
[  OK  ] Stopped Network Time Service.
[  OK  ] Stopped Cosa service.
[  OK  ] Stopped RDK Cellular Manager service.
[  OK  ] Unmounted /data.
[  OK  ] Unmounted /etc/dhcp_static_hosts.
[  OK  ] Unmounted /etc/dibbler.
[  OK  ] Unmounted /etc/dropbear.
[  OK  ] Unmounted /etc/hostname.
[  OK  ] Unmounted /etc/hosts.
[  OK  ] Unmounted /etc/machine-id.
[  OK  ] Unmounted /etc/resolv.conf.
[  OK  ] Unmounted /etc/resolv.dnsmasq.
[  OK  ] Unmounted /etc/xupnp.
[  OK  ] Unmounted /home.
[  OK  ] Unmounted /media.
[  OK  ] Unmounted /mnt/defaults.
[  OK  ] Unmounted /nvram/secure.
[  OK  ] Unmounted /nvram2.
[FAILED] Failed unmounting /rdklogs.
[  OK  ] Stopped Flush Journal to Persistent Storage.
[  OK  ] Stopped Bind mount volatile /etc/dibbler.
[  OK  ] Stopped Bind mount volatile /etc/dropbear.
[  OK  ] Stopped Bind mount volatile /etc/dhcp_static_hosts.
[  OK  ] Stopped Bind mount volatile /etc/hostname.
[  OK  ] Stopped Bind mount volatile /etc/hosts.
[  OK  ] Stopped Bind mount volatile /media.
[  OK  ] Stopped Bind mount volatile /etc/resolv.conf.
[  OK  ] Stopped Bind mount volatile /etc/resolv.dnsmasq.
[  OK  ] Stopped Bind mount volatile /etc/wlan/nvram/.
[  OK  ] Stopped Bind mount volatile /etc/xupnp.
[  OK  ] Unmounted /opt/secure.
         Unmounting /mnt...
         Unmounting /opt...
         Unmounting /var/volatile...
         Stopping Rdk Wan Manager service...
[  OK  ] Stopped Network Time Service (one-shot ntpdate mode).
         Stopping Utopia service...
[  OK  ] Stopped Provides a serviceâ�…ouse to do a unit maintenance.
         Stopping Ovs Agent service...
[  OK  ] Stopped Ovs Agent service.
[  OK  ] Unmounted /mnt.
[  OK  ] Unmounted /opt.
[FAILED] Failed unmounting /var/volatile.
[  OK  ] Stopped Rdk Wan Manager service.
         Stopping Ovs Db Server service...
         Stopping PsmSsp service...
         Stopping Interface Manager service...
[  OK  ] Stopped Interface Manager service.
         Unmounting /nvram...
[  OK  ] Stopped PsmSsp service.
[  OK  ] Unmounted /nvram.
[  OK  ] Stopped Utopia service.
[  OK  ] Stopped BCA Gencfg Init Service.
         Stopping Install Broadocm wifi drivers...
[  OK  ] Stopped Secure mount service.
         Stopping Starts logbackup Service...
[  OK  ] Stopped Mount nvram File System Service.
[  OK  ] Stopped Mount data partition.
[  OK  ] Stopped Starts logbackup Service.
net_ratelimit: 22 callbacks suppressed
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe02a DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe02a DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe02a DFS state 0
In wl_dfs_cac_notify_status chanspec 0x1803 DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
In wl_dfs_cac_notify_status chanspec 0xe29b DFS state 0
[  OK  ] Stopped Ovs Db Server service.
dhd_os_stop_wd_thread(): thread:dhd_watchdog_thread:790 terminated OK
[  OK  ] Started Reboot handler Task At reboot.
deleting interface 'wl2.1' idx 1
wfd_unregisterdevice Successfully unregistered ifidx 1 wfd_idx 2
dhd_get_stats: BAD_IF
dhd_get_stats: BAD_IF
[  OK  ] Stopped rdkbLogMonitor service.
deleting interface 'wl2.2' idx 2
wfd_unregisterdevice Successfully unregistered ifidx 2 wfd_idx 2
dhd_get_stats: BAD_IF
deleting interface 'wl2.3' idx 3
wfd_unregisterdevice Successfully unregistered ifidx 3 wfd_idx 2
dhd_get_stats: BAD_IF
deleting interface 'wl2.4' idx 4
wfd_unregisterdevice Successfully unregistered ifidx 4 wfd_idx 2
dhd_get_stats: BAD_IF
deleting interface 'wl2.5' idx 5
wfd_unregisterdevice Successfully unregistered ifidx 5 wfd_idx 2
dhd_get_stats: BAD_IF
deleting interface 'wl2.6' idx 6
wfd_unregisterdevice Successfully unregistered ifidx 6 wfd_idx 2
dhd_get_stats: BAD_IF
deleting interface 'wl2.7' idx 7
wfd_unregisterdevice Successfully unregistered ifidx 7 wfd_idx 2
Get event_msgs error (-19)
find p2p index from wdev(c3c6951c) failed
dhd_get_stats: BAD_IF
dhd_get_stats: BAD_IF
dhd_get_stats: BAD_IF
cpu Ring 15 has been flushed
rdpa_dhd_helper_dhd_complete_ring_destroy(2, 1024) returned 0
dor2 rdpa_dhd_helper_cpu_data_set(0xdf4cd7fc, NULL) returned -1
wfd2-th pktlist2 <8:129> dispatch<0> list<0> pkts<0> peer<e4fdb840,dhd_pktfwd_xfer_callback+0x0/0x818 [dhd]>
dhd2 pktlist2 <8:129> dispatch<0> list<0> pkts<0> peer<00000000,  (null)>
 DEST PRIO KEY  PACKETS    CREDITS
                =======
                  0

dhd_pktfwd_sys_fini:  dhd_PKTFWD[1.0.0] Complete
kerSysDeregisterDyingGaspHandler: wl1 is deregistering
kerSysDeregisterDyingGaspHandler: wl1 is deregistered
wfd1-th pktlist1 <8:129> dispatch<0> list<0> pkts<0> peer<d2e97600,wl_pktfwd_xfer_callback+0x0/0x498 [wl]>
wl1 pktlist1 <8:129> dispatch<0> list<0> pkts<0> peer<00000000,  (null)>
 DEST PRIO KEY  PACKETS    CREDITS
                =======
                  0

wfd_unregisterdevice Successfully unregistered ifidx 0 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 1 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 2 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 3 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 4 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 5 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 6 wfd_idx 1
wfd_unregisterdevice Successfully unregistered ifidx 7 wfd_idx 1
kerSysDeregisterDyingGaspHandler: wl0 is deregistering
kerSysDeregisterDyingGaspHandler: wl0 is deregistered
wfd0-th pktlist0 <8:129> dispatch<0> list<0> pkts<0> peer<d2ea3840,wl_pktfwd_xfer_callback+0x0/0x498 [wl]>
wl0 pktlist0 <8:129> dispatch<0> list<0> pkts<0> peer<00000000,  (null)>
 DEST PRIO KEY  PACKETS    CREDITS
                =======
                  0

wfd_unregisterdevice Successfully unregistered ifidx 0 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 1 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 2 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 3 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 4 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 5 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 6 wfd_idx 0
wfd_unregisterdevice Successfully unregistered ifidx 7 wfd_idx 0
wl_pktfwd_sys_fini:  WL_PKTFWD[1.1.0] Complete
Exiting HND Module
Exiting wlshared Module
[  OK  ] Stopped Mesh Wifi service.
[  OK  ] Stopped Install Broadocm wifi drivers.
[  OK  ] Stopped Install Broadocm wifi drivers.
[  OK  ] Stopped Install Broadocm wifi drivers.
[  OK  ] Stopped target Basic System.
[  OK  ] Stopped target Paths.
[  OK  ] Stopped Waits to trigger OvsAgent.service..
[  OK  ] Stopped Process Restart Occurred Path.
[  OK  ] Stopped Apps Download Path.
[  OK  ] Stopped Path Exists.
[  OK  ] Stopped WiFi is initialized - Launch meshAgent.
[  OK  ] Stopped BRCM WiFi Initialized Path.
[  OK  ] Stopped RBus IPC Restart Occurred - Path.
[  OK  ] Stopped NTP Synchronized Path.
[  OK  ] Stopped Ntpd configuration file changes.
[  OK  ] Stopped Dispatch Password â�…ts to Console Directory Watch.
[  OK  ] Stopped Forward Password Râ�…uests to Wall Directory Watch.
[  OK  ] Stopped Utopia is initialized - Launch CcspCrSsp.
[  OK  ] Stopped Wan Initialized Path.
[  OK  ] Stopped Wifi Initialized Path.
[  OK  ] Stopped target Network is Online.
[  OK  ] Stopped target Slices.
[  OK  ] Stopped target Sockets.
[  OK  ] Closed dropbear.socket.
         Unmounting /minidumps...
         Unmounting Temporary Directory (/tmp)...
         Unmounting /var...
[  OK  ] Stopped Install Broadocm base drivers.
[  OK  ] Unmounted /minidumps.
[FAILED] Failed unmounting Temporary Directory (/tmp).
[FAILED] Failed unmounting /var.
[  OK  ] Stopped target Local File Systems (Pre).
[  OK  ] Stopped target Swap.
[  OK  ] Reached target Unmount All Filesystems.
[  OK  ] Stopped Remount Root and Kernel File Systems.
[  OK  ] Stopped Create Static Device Nodes in /dev.
[  OK  ] Reached target Shutdown.
[  OK  ] Reached target Final Step.
[  OK  ] Started Reboot.
[  OK  ] Reached target Reboot.
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 27sec irq!
 
sreehari: bcm96xxx_wdt_set_timeout
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 42sec irq!
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 42sec irq!
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 42sec irq!
sreehari: bcm96xxx_wdt_start
sreehari: bcm96xxx_wdt_get_int_based_hw_timeout
 sreehari: : wdt_irq: Arming for 42sec irq!
sreehari: bcm96xxx_wdt_shutdown
sreehari: bcm96xxx_wdt_stop
reboot: Restarting system

sreehari kernel/reboot.c, Restarting system
sreehari : ./arch/arm/kernel/reboot.c: machine_restart 1: cmd=(null)
sreehari : ./arch/arm/kernel/reboot.c: machine_restart 2: cmd=(null)
sreehari: bcmbca_wd_start
watchdog0: pretimeout event
sreehari: bcmbca_wd_start
----
BTRM
V3.0
MEM?
MEMP
CACH
DATA
ZBSS
MAIN
EMMC
OTP?
OTPP
USBT
UHD?
UHDP
IMG?
IMGL
UBI?
UBIP
PASS
AVS?
AVSL
----
AVS...
Starting AVS
CLKSYNC
68550.3.lite.7
 and Here wl will request the onewif for 
change equiv 38
37 S: 5143 L: 5243
48 S: 5149 H: 3016
50 S: 5109 H: 2992
51 S: 5132 H: 2963
54 S: 5196 H: 3021
55 S: 5216 H: 3002
56 S: 5176 H: 2976
60 S: 5218 H: 2981
61 S: 5176 H: 2982
62 S: 5176 H: 2962
R00: 5341
R01: 5173
R02: 4236
R03: 3050
R04: 7234
R05: 7099
R06: 5693
R07: 4133
R08: 21143
R09: 20321
R10: 16562
R11: 12100
R12: 15571
R13: 14072
R14: 11575
R15: 8099
R16: 14828
R17: 13919
Margins: 120 / 60
AVS_PRED:
S: 797
H: 829
L: 755
R00: 742
R01: 791
R03: 820
AVS_PRED: 829 CM: 75 Closed at: 904 / 903
37 S: 4368 L: 4625
48 S: 4365 H: 2379
50 S: 4324 H: 2356
51 S: 4354 H: 2334
54 S: 4402 H: 2377
55 S: 4421 H: 2361
56 S: 4388 H: 2342
60 S: 4419 H: 2337
61 S: 4388 H: 2345
62 S: 4398 H: 2330
R00: 4717
R01: 4384
R02: 3587
R03: 2407
R04: 6400
R05: 6032
R06: 4833
R07: 3266
R08: 18749
R09: 17270
R10: 14034
R11: 9535
R12: 13604
R13: 11761
R14: 9653
R15: 6244
R16: 12994
R17: 11709
Lock AVS

U-Boot SPL 2019.07 (Nov 26 2024 - 18:19:34 +0000)
Strap register: 0x7fffeff7
Board is non secure
$SPL: 5.04L.03@370050 $
FFinit done
find magic number 0x75456e76 at address 0x40000
FFinit find magic number 0xcb00cb at address 0x45000
reading blob from 0x45000 offset 0x23ac len 608
digest sha256 OK
FFinit find magic number 0x64447234 at address 0x2a000
reading blob from 0x2a000 offset 0xc len 45192
digest sha256 OK
mcb selector 0x101532 checksum 0xf8e14bdb safe_mode 0

U-Boot DDR standalone 2019.07 (Dec 22 2021 - 16:57:13 -0800) Build: 5.04L.03@370050

MemsysInit hpg0_generic 3.18.0.0 20210819
DDR4
8203DB14 80180000 801A0000 00000000 00000000
DDR4
MCB rev=0x00030F01 Ref ID=0x072C9 Sub Bld=0x003 Cookie=0xF8E14BDB
Dram Timing 17-17-20
CMD @1T
Virt VTT on

start of memsys_begin
mc_cfg_init(): Initialize the default values on mc_cfg
init_memc_dram_profile(): Initializing MEMC DRAM profile
---------------------------------------------------------------
MEMC DRAM profile (memc_dram_profile_struct) values:
  dram_type    = DDR4
====================================================
PART values:
  part_speed_grade    = 2400 CL17
  part_size_Mbits     = 8192 (DRAM size in MegaBits)
  part_row_bits       = 16 (number of row bits)
  part_col_bits       = 10 (number of column bits)
  part_ba_bits        = 2 (number of bank bits)
  part_bg_bits        = 1 (number of bankgroup bits)
  part_width_bits     = 16 (DRAM width in bits)
NUMER OF PARTS:
  part_num            = 1 (Number of parts)
TOTAL values:
  total_size_Mbits    = 8192 (DRAM size in MegaBits)
  total_cs_bits       = 0 (number of cs bits, for dual_rank mode)
  total_width_bits    = 16 (DRAM width in bits)
  total_burst_bytes   = 16 (Number of bytes per DRAM access)
  total_max_byte_addr = 0x3fffffff (Maximum/last DRAM byte address)
                        (Number of bits in total_max_byte_addr is 30)
                        (i.e. total_max_byte_addr goes from bit 0 to bit 29)
  ddr_2T_mode         = 0
  ddr_hdp_mode        = 1
  large_page          = 1
  ddr_dual_rank       = 0
  cs_mode             = 0
MEMC timing (memc_dram_timing_cfg_struct) values:
====================================================
  MC_CHN_TIM_TIM1_0 register fields:
    tCwl   = 16
    tRP    = 17
    tCL    = 20
    tRCD   = 17
  MC_CHN_TIM_TIM1_1 register fields:
    tCCD_L = 6
    tCCD   = 4
    tRRD_L = 8
    tRRD   = 7
  MC_CHN_TIM_TIM1_2 register fields:
    tFAW   = 36
    tRTP   = 9
    tRCr   = 56
  MC_CHN_TIM_TIM1_3 register fields:
    tWTR_L = 8
    tWTR   = 3
    tWR_L  = 18
    tWR    = 18
  MC_CHN_TIM_TIM2 register fields:
    tR2R   = 0
    tR2W   = 6
    tW2R   = 0
    tW2W   = 0
    tAL    = 0
    tRFC   = 420
====================================================
%1 SSC enabled

Poll PHY Status register
PHY Status= 1
[0x80180004] = 0x0230041f
Disable Auto-Refresh
[80180200] = 0x00000305
End of memsys_begin
Add/Ctl Alignment
Coarse Adj=0x06E deg, cmd steps=0x098
reg 0x801A0090 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A0094 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A0098 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A009C set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00A0 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00A4 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00A8 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00AC set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00B0 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00B4 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00B8 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00BC set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00C0 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00C4 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00C8 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00CC set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00D0 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00D4 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00D8 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00DC set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00E0 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00E4 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00E8 set to VDL 0x054 with Fine Adj=0x01 deg
reg 0x801A00EC set to VDL 0x054 with Fine Adj=0x01 deg
reg 0x801A00F0 set to VDL 0x054 with Fine Adj=0x01 deg
reg 0x801A00F4 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00F8 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A00FC set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A0100 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A0108 set to VDL 0x02E with Fine Adj=0x01 deg
reg 0x801A010C set to VDL 0x02E with Fine Adj=0x01 deg
 DDR_CK set to 0x26
HP RX TRIM
itrim = 0x0
lstrim = 0xB

ZQ Cal HP PHY
 R in Ohm
 P ideal: term=0x3C Drv=0x28 DQTerm=0x3C DQDrv=0x28
 N ideal: term=0xFF Drv=0x28 DQTerm=0xFF DQDrv=0x28
 P: Finger=0x364 Term=0x3E Drv=0x27 DQTerm=0x3E DQDrv=0x27
 N: Finger=0x330 Term=0x00 Drv=0x29 DQTerm=0x00 DQDrv=0x29

HP RX TRIM
itrim = 0x3
lstrim = 0xE
PLL Ref(Hz)=0x02FAF080 UI STEPS=0x04C
 DDR CLK(MHz)=0x4A9 WL CLK dly(ps)=0x0C8 (user set) bitT(ps)=0x1A3 VDLsize(fs)=0x1589 CLK_VDL=0x024
start of memc_init
[80180004] = 0x0230061f
[80180234] = 0x00001102
Enable Auto-Refresh
[80180110] = 0x11100f0e
[80180114] = 0x15141312
[80180118] = 0x19181716
[8018011c] = 0x1d1c1b1a
[80180124] = 0x04000000
[80180128] = 0x08070605
[8018012c] = 0x00000a09
[80180134] = 0x00000d0c
[80180138] = 0x0000000b
 Writing to MC_CHN_CFG_CNFG reg; data=0x00000000
[80180100] = 0x00000000
cfg_memc_timing_ctrl() Called
[80180214] = 0x10111411
[80180218] = 0x06040807
[8018021c] = 0x24000938
[80180220] = 0x08030212
[80180224] = 0x300001a4
[80180264] = 0x02000080
End of memc_init
start of pre_shmoo
[80180004] = 0xc230071f
end of pre_shmoo

SHMOO 28nm DPFE-B0
801A0000 801A0000 00000000 00020000 00000000

Shmoo WL

One UI Steps : 0x6D

   0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111
   0000000000111111111122222222223333333333444444444455555555556666666666777777777788888888889999999999000000000
   0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678
00 +X+--------------------------------------------------------------------------+++-----------------------------
01 +S+++++++++X---------------------------------------------------------------------------+++-------------------
BL2/BL3 adj schem 2

CA/CS/CLK/DQS VDL reduction G PHY
Pre adjust (vdl unit)
CLK = 0x24
WR DQS[1:0] = 0x0B, 0x01
WR DQS UI[1:0] = 0x01, 0x01

rounding down, by -0x01

Final State (vdl unit)
CLK = 0x23
WR DQS[1:0] = 0x0A, 0x00
WR DQS UI[1:0] = 0x01, 0x01


Shmoo RD En
FORCED WR ODT = 0x00001800
 DQSN DRIVE PAD CONTROL (from) (to)
 B0 000702D4 000782D4
 B1 000702D4 000782D4
one data UI = 4C. Pick point = 1.5UI + Rise
B0 RISE UI=2 VDL=1F PICK UI=3 VDL=45
B1 RISE UI=1 VDL=5D PICK UI=3 VDL=37
Rise UI Plot
   0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111
   0000000000111111111122222222223333333333444444444455555555556666666666777777777788888888889999999999000000000
   0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678
00 --S----------------------------X+++++++++++++++-------------------------------------------------------------+
01 -S-------------------------------------------------------------------------------------------X+++++++++++++++

Shmoo RD DQS DQ MPR PN with VREF
DQS :
B0 VDL=0x4B ok
B1 VDL=0x4B ok
Curr VREF | Best VREF
00000020 | 00000000
00000024 | 00000020
00000028 | 00000024
0000002C | 00000024
00000030 | 00000024
00000034 | 00000024
Using Picked VREF=0x00000024
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 --------------+++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++------------------------------------------------------------------
01 -------+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++---------------------------------------------------------------------
02 -------+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++---------------------------------------------------------------------
03 -------+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++---------------------------------------------------------------------
04 -------+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++---------------------------------------------------------------------
05 -----+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++-----------------------------------------------------------------------
06 ----------+++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++---------------------------------------------------------------------
07 -------------++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++-----------------------------------------------------------------
08 ----------+++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++-----------------------------------------------------------------
09 ----------------+++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++-----------------------------------------------------------
10 --------------+++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++-----------------------------------------------------------------
11 --------------+++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++-----------------------------------------------------------------
12 -----+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++-----------------------------------------------------------------------
13 -----++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++-------------------------------------------------------------------------
14 ----------+++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++------------------------------------------------------------------
15 ----------------+++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++----------------------------------------------------------------

Shmoo WR DQ
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123459
00 ------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------------
01 ------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------------------
02 -------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-------------------------------------------------------------------------------
03 ------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------------------
04 ----+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------------------------
05 -------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++--------------------------------------------------------------------------------
06 ----------++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++-------------------------------------------------------------------------------
07 -------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++------------------------------------------------------------------------
08 ---------------++++++++++++++++++++++++++++X++++++++++++++++++++++++++++---------------------------------------------------------------------------
09 --------------------+++++++++++++++++++++++++++X++++++++++++++++++++++++++++-----------------------------------------------------------------------
10 --------------++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++---------------------------------------------------------------------------
11 -----------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++-----------------------------------------------------------------------
12 ------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++----------------------------------------------------------------------------------
13 --------++++++++++++++++++++++++++++X++++++++++++++++++++++++++++----------------------------------------------------------------------------------
14 --------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-------------------------------------------------------------------------
15 ---------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------------

Shmoo CS0
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 ----------------------------------+++++++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++----------


Shmoo Addx Alignment

 cmd UI = 0x098
 00-13=AD00-AD13 14-15=AD14_WE,AD15_CAS 16-18=BA0-BA2 19=ACT 20=AD16_RAS 21=BG1 (if being used)
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 -------------------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+-----
01 --------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-------
02 --------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-++----
03 ------------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++----
04 -------------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++------
05 ------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+-----
06 ------------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+-----
07 -++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+-----
08 --------------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----
09 ---------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+---
10 ---------------------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+---
11 --------------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+---
12 --------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----
13 -++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++---
14 -----------------------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----
15 --------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++----
16 -------------------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+---
17 -++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----
18 --------------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----
19 --------------------------++++++++++++++++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----
20 -----------++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-+-----
21 X--------------------------------------------------------------------------------------------------------------------------------------------------

min_vdl = 0x02F, signal index = 0x07

post left justification
0x00000090 = 0x0000001B
0x00000094 = 0x00000016
0x00000098 = 0x00000016
0x0000009C = 0x00000014
0x000000A0 = 0x0000001B
0x000000A4 = 0x0000000E
0x000000A8 = 0x0000001A
0x000000AC = 0x00000009
0x000000B0 = 0x0000001C
0x000000B4 = 0x00000011
0x000000B8 = 0x0000001D
0x000000BC = 0x0000001C
0x000000C0 = 0x00000010
0x000000C4 = 0x00000009
0x000000C8 = 0x0000001F
0x000000CC = 0x00000010
0x000000D0 = 0x0000001B
0x000000D4 = 0x00000009
0x000000D8 = 0x0000001C
0x000000DC = 0x00000008
0x000000E0 = 0x00000008
0x000000E4 = 0x00000008
0x000000E8 = 0x0000002F
0x000000EC = 0x0000002E
0x000000F0 = 0x0000002E
0x000000F4 = 0x00000008
0x000000F8 = 0x00000022
0x000000FC = 0x00000008
0x00000100 = 0x00000008
0x00000108 = 0x00000012
0x0000010C = 0x00000013
0x00000110 = 0x00000000

WL pick pos adjustment
BL-0: CYC=0x00 VDL=0x26
BL-1: CYC=0x00 VDL=0x30

Shmoo RD En
FORCED WR ODT = 0x00001800
 DQSN DRIVE PAD CONTROL (from) (to)
 B0 000702D4 000782D4
 B1 000702D4 000782D4
one data UI = 4C. Pick point = 1.5UI + Rise
B0 RISE UI=1 VDL=25 PICK UI=2 VDL=4B
B1 RISE UI=1 VDL=19 PICK UI=2 VDL=3F
Rise UI Plot
   0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111
   0000000000111111111122222222223333333333444444444455555555556666666666777777777788888888889999999999000000000
   0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678
00 -S-----------------------------------X+++++++++++++++--------------------------------------------------------
01 -S-----------------------X+++++++++++++++------------------------------------------------------------++++++++

Shmoo WR DQ with VREF
Curr VREF | Best VREF
00000000 | 00000000
00000004 | 00000000
00000008 | 00000004
0000000C | 00000008
00000010 | 0000000C
00000014 | 00000010
00000018 | 00000014
0000001C | 00000014
Using Picked VREF=0x00000014
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123459
00 -------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++---------------------------------------------------------------------------
01 ------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------------------
02 --------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++--------------------------------------------------------------------------------
03 ------+++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++-----------------------------------------------------------------------------
04 ---++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------------------------
05 -------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++--------------------------------------------------------------------------------
06 ---------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++------------------------------------------------------------------------------
07 ------------+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++------------------------------------------------------------------------
08 --------------++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++---------------------------------------------------------------------------
09 -------------------++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++----------------------------------------------------------------------
10 -------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++---------------------------------------------------------------------------
11 ----------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------------
12 -----++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++---------------------------------------------------------------------------------
13 -------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++---------------------------------------------------------------------------------
14 -------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++--------------------------------------------------------------------------
15 ----------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++------------------------------------------------------------------------

Shmoo WR DM
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123459
00 ------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++---------------------------------------------------------------------------
01 --+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++----------------------------------------------------------------------------------

Shmoo RD DQS DQ Array PN with VREF
DQS :
B0 VDL=0x4A ok
B1 VDL=0x4A ok
Curr VREF | Best VREF
00000020 | 00000000
00000024 | 00000020
00000028 | 00000024
0000002C | 00000024
00000030 | 00000024
00000034 | 00000024
Using Picked VREF=0x00000024
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 -----------------------++++++++++++++++++++++++++++X++++++++++++++++++++++++++++-------------------------------------------------------------------
01 -------------+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-----------------------------------------------------------------------
02 ------------------++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++-----------------------------------------------------------------------
03 ----------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------------
04 --------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-----------------------------------------------------------------------
05 --------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++------------------------------------------------------------------------
06 ------------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++---------------------------------------------------------------------
07 --------------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++------------------------------------------------------------------
08 -------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++------------------------------------------------------------------
09 -----------------------++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++-----------------------------------------------------------
10 ----------------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------
11 --------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-----------------------------------------------------------------
12 ------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------------
13 --------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++--------------------------------------------------------------------------
14 ------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------
15 ---------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++----------------------------------------------------------------

Shmoo RD DQS DQ Array P
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 --------------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-------------------------------------------------------------------
01 ---------+++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++----------------------------------------------------------------------
02 --------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-----------------------------------------------------------------------
03 ------------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++---------------------------------------------------------------------
04 ----------+++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++---------------------------------------------------------------------
05 ----------+++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++-------------------------------------------------------------------------
06 ---------------+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++---------------------------------------------------------------------
07 -----------------+++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++------------------------------------------------------------------
08 ----------------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++-----------------------------------------------------------------
09 --------------------+++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++-----------------------------------------------------------
10 -----------------++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++-----------------------------------------------------------------
11 ------------------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++---------------------------------------------------------------
12 ----------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++-----------------------------------------------------------------------
13 ------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------------
14 ----------------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++-----------------------------------------------------------------
15 ------------------++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++----------------------------------------------------------------

Shmoo RD DQS DQ Array N
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 ------------------------++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++-----------------------------------------------------------------
01 -------------+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-----------------------------------------------------------------------
02 ------------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++----------------------------------------------------------------------
03 ----------------+++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------------
04 --------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-----------------------------------------------------------------------
05 --------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++------------------------------------------------------------------------
06 -------------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-------------------------------------------------------------------
07 ---------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++----------------------------------------------------------------
08 -------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++------------------------------------------------------------------
09 ----------------------++++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++++-----------------------------------------------------------
10 ---------------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-----------------------------------------------------------------
11 --------------------+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++----------------------------------------------------------------
12 -------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++-------------------------------------------------------------------------
13 --------------+++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++--------------------------------------------------------------------------
14 ------------------++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++-------------------------------------------------------------------
15 ---------------------+++++++++++++++++++++++++++++++X+++++++++++++++++++++++++++++++---------------------------------------------------------------

Shmoo RD DBI (Array)
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 ----------------++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++----------------------------------------------------------------------
01 ----------+++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++-------------------------------------------------------------------------

Read Data Delay Passive

using EDIS Stat

   01234567
00 --+++---
01 --+++---

picked value
BL0 3
BL1 3

Shmoo CS0
   000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111111111111111111
   000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001111111111222222222233333333334444445
   012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123451
00 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++X++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++---------+


MPR Read.
Detected 1 x16 DRAMs

    Page 2
    MPR0 : dev0=0xC8
    MPR1 : dev0=0x28
    MPR2 : dev0=0x95
    MPR3 : dev0=0x24

    DRAM temp
    dev0: 45C-85C

shmoo completed OK
start of memsys_end
[80180004] = 0x8230071f
[80180010] = 0x0000000a
end of memsys_end
start init_mc_arb
[80180300] = 0x00000000
[801803e0] = 0x00140552
[801803e4] = 0x00130551
[801803e8] = 0x00100000
[801803ec] = 0x0001322c
[80180344] = 0x00000040
[80180314] = 0x00000040
[80180324] = 0x000000e0
[80180334] = 0x000000e0
[80180310] = 0xe0000202
[80180320] = 0xe0000202
[80180340] = 0xe0000202
[80180330] = 0xe0000202
[80180350] = 0x00000404
end init_mc_arb
start init_mc_chn_arb
[80180004] = 0x8230071f
[8018023c] = 0x00000000
[80180244] = 0x40000202
[80180240] = 0x00000001
[80180250] = 0xd9c8fbea
[80180254] = 0xd9c8fbea
[80180258] = 0x51417362
end init_mc_chn_arb
start init_mc_axi_if
[801804c4] = 0x000001c8
[801804c0] = 0x310610ff
[801804c8] = 0x06060404
[801804cc] = 0x00543210
[801804d0] = 0x11111111
[801804d4] = 0x11111111
[801804d8] = 0x11111111
[801804dc] = 0x11111111
[801804e0] = 0x11111111
[801804e4] = 0x11111111
[801804e8] = 0x11111111
[801804ec] = 0x11111111
[801804f0] = 0x00000000
end init_mc_axi_if
DDR scrambling enabled.
DDR test done successfully
FFinit find magic number 0x75456e76 at address 0x40000
WDT:   Not found!
FFinit find magic number 0x74506c21 at address 0x80000
reading blob from 0x80000 offset 0xc len 179280
digest sha256 OK

U-Boot TPL 2019.07 (Nov 26 2024 - 18:19:30 +0000)
Board is non secure
$TPL: 5.04L.03@370050 $
PMC driver initcall
BCM UBUS4 driver [ubus_sys] registered
BCM UBUS4 DCM clk driver [ubus_dcm_sys] registered
IMAGE is EMMC
Trying to boot from MMC1
board_tpl_load_mmc_part: read sector 200, count=512
RESET STATUS is 0x20000000
BOOT REASON is 0x0
SELECTED Image 1 FIT_VOL_ID is 3
fit read sector 4000, sectors=13, dst=07000000, count=13, size=0x1876
## Checking hash(es) for Image atf ... sha256+ OK
## Checking hash(es) for Image optee ... sha256+ OK
## Checking hash(es) for Image uboot ... sha256+ OK
## Checking hash(es) for Image fdt_WNXL11BWL ... sha256+ OK
## Checking hash(es) for Image xboot ... sha256+ OK
tpl: active image set to: 1


U-Boot 2019.07 (Nov 28 2024 - 15:28:09 +0000), Build: 5.04L.03@370050

Model: WNXL11BWL
DRAM:  1 GiB
PMC driver initcall
PMC driver scanning DT
     Remapping PMC IO memories...
name             phys              virt          size
PMC  0xffb20060 0xffb20060 0x1e0
pmc_init:PMC using PMB_DIRECT mode
BCM UBUS4 driver [ubus_sys] registered
BCM UBUS4 DCM clk driver [ubus_dcm_sys] registered
max supported leds 32[32]
 Parallel CLED interface found
BCA CLED Controller initialized
HW led 8 registered
HW led 9 registered
HW led 14 registered
HW led 15 registered
SW led 9 registered
SW led 13 registered
SW led 9 registered
Chip ID: BCM6753_A1
ARM Cortex A7 Triple Core: 1700MHz
RDP Freq: 1000MHz
$Uboot: 5.04L.03@370050 $
WDT:   Not found!
NAND:  0 MiB
MMC:   sdhci: 0
In:    serial0
Out:   serial0
Err:   serial0
Model: WNXL11BWL
Got 0
Board is non secure
HTTPD: ready for starting
boot_device is EMMC
Net:   Using MAC Address 02:10:18:00:00:01
eth0: switch0
Hit any key to stop autoboot:  0
## Starting application at 0x01400000 ...
TS 19910506: Xboot_main_start
1-1-XLE-3.6.1 [Nov 26 2024 16:29:03]:[BL_VERSION][19913156]
1-XV-3.162.0:[XBOOT_VERSION][19918445]
1-V-1.18:[MILESTONE_CODE_VERSION][19921916]
DEBUG: Xboot_plat_log_versions:133: Xboot_plat_log_versions():133  fdt_addr=1036412904

DEBUG: Xboot_plat_log_versions:153: Firmware is loaded from bank: 1
0-1-1:[FWS_FLAG][19939624]
DEBUG: Xboot_plat_emmc_init:116: STUB
DEBUG: Xboot_os_mutex_init:52: STUB!
DEBUG: Xboot_ir_init:53: STUB!
DEBUG: Xboot_fp_init:52: STUB[Xboot_fp_init]!
DEBUG: Xboot_plat_firmware_ReadActiveBLBank:182: Xboot_plat_firmware_ReadActiveBLBank():182  fdt_addr=1036412904

DEBUG: Xboot_plat_firmware_ReadActiveBLBank:201: Firmware is loaded from bank: 1
DEBUG: xboot_plat_read_update_env:147: activebl is: 1
DEBUG: Xboot_plat_led_set_pattern:262: **** SET PATTERN [5]
DEBUG: Xboot_plat_led_set_pattern:262: **** SET PATTERN [1]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
7-10:[KEYSTORE_VERIFICATION_PASS][20016371]
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: optee_client_register_encoded_data:915: detected optee registered mode: 0x1
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_bladdr_read:443: Found valid area for struct[RuntimeCookie] at area[3] addr[0x03140000]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
TS 20316693: Xboot_runtime_cookie_initialise_bootCookie:0
1-S-C-0:[BOOT_COOKIE][20320373]
1-S-L-2:[LAUNCH_BANK][20323224]
TS 20326088: xboot_init_end
TS 20328605: Xboot_boot_process_start
TS 20331994: Xboot_try_launchbank_got_pci_list
DEBUG: Xboot_xsign_init:366: Xsign init for image PCI2
1-4-2-0-0:[PCI2]:[IMAGE_HEADER_VERIFICATION_START]:[20341021]
[XSign_New:470]:XSIGN Version:[4.0.1] Build Stamp[Nov 26 2024]:[16:29:02]

[XSign_New:471]:XSIGN OpenSSL Version: [OpenSSL 1.0.0a 1 Jun 2010]

XSIGN_INSECURE - Requested to go Insecure
[UNSIGNED_IMAGES_SUPORTED]
[XSIGN_DEBUG_ENABLE]
DEBUG: Xboot_xsign_certstore_load:244: Loading certstore
DEBUG: Xboot_xsign_certstore_load:244: Loading certstore
DEBUG: Xboot_xsign_certstore_load:248: Certstore already loaded

CertificateStore Region: [extender.xle]
CertificateStore Size: [2888]
1-4-2-0-1:[PCI2]:[IMAGE_HEADER_VERIFICATION_END]:[20407160]
DEBUG: Xboot_image_read_manifest:482: Xsign manifest for  image: PCI2, version: 250102103221, model: WNXL11BWL,  svn: 3, cvc: 250102103221, size: 733

DEBUG: Xboot_xsign_load_section:683: Get section xboot_config for image PCI2
1-4-2-13-2-2:[PCI2]:[xboot_config]:[COPY_START]:[20430252]
DEBUG: Xboot_xsign_copyfunc:126: CopyFunc: imgBase: 15800000, componentOffset: 35fa000
DEBUG: Xboot_xsign_copyfunc:127: copy 18DFA000,1 -> 3dc8a4b8
1-4-2-13-2-3:[PCI2]:[xboot_config]:[COPY_END]:[20450312]
DEBUG: Xboot_xsign_digestfunc:153: Digest 3dc8a4b8,1
DEBUG: Xboot_crypto_sha256:127: Software SHA256! 1 @ 3dc8a4b8
DEBUG: Xboot_crypto_sha256:139: Returning digest 01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b
1-4-2-13-x-00:[PCI2]:[xboot_config]:[SECTION_VERIFICATION_SUCCESS]:[20473650]
1-4-2-13-2-0:[PCI2]:[xboot_config]:[DECRYPTION_START]:[20480506]
1-4-2-13-2-1:[PCI2]:[xboot_config]:[DECRYPTION_END]:[20486235]
TS 20491789: Xboot_try_boot_image_start_PCI2
DEBUG: Xboot_try_boot_image:683: Image: PCI2

DEBUG: Xboot_plat_led_set_pattern:262: **** SET PATTERN [1]
1-4-2-0:[PCI2]:[IMAGE_IDENTIFIED_TO_LAUNCH]:[20507636]
1-4-2-5-7-0:[PCI2]:[IMAGE_RETRY_COUNT_DECREMENT_OVERRIDE_DISABLED]:[20517696]
TS 20521684: Xboot_try_boot_image_got_retry_count
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_bladdr_read:443: Found valid area for struct[CIDataPCI] at area[3] addr[0x030C4000]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
1-4-2-S-BL-3:[PCI2]:[BL_SVN_VALUE]:[20822256]
1-4-2-S-I-3:[PCI2]:[IMAGE_SVN_VALUE]:[20825011]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_bladdr_read:443: Found valid area for struct[CIDataPCI] at area[3] addr[0x030C4000]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[decryp]
DEBUG: Xboot_xsign_keystore_load:190: Loading keystore
DEBUG: Xboot_xsign_keystore_load:193: Keystore already loaded

DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 1
DEBUG: Xboot_xsign_GetEncryptionKeyTypeByIndex:978: EncryptKeyTypeTable entries 20 index: 0
DEBUG: Xboot_plat_crypto:579: key index for iv:  1, location: 014dbc12 ivsize: 16 bytes
DEBUG: Xboot_plat_crypto:587: Key index: [0], Name[BLKA_AES_128_Key_0], Algorithm[0], Encryption[0], ChainType[1],  Location[014dbc02], Action[encryp]
DEBUG: Xboot_anti_rollback_check:207: cvc check | PCI2 with cvc: 250102103221, compares to bl with cvc: 230103004249
1-4-2-C-BL-230103004249:[PCI2]:[BL_CVC_VALUE]:[21134207]
1-4-2-C-I-250102103221:[PCI2]:[IMAGE_CVC_VALUE]:[21139237]
TS 21144443: Xboot_Validate_Image_got_manifest
DEBUG: Xboot_Validate_Image:255: model name check | image: PCI2 with modelName: WNXL11BWL compares to bl with modelName: WNXL11BWL

DEBUG: Xboot_xsign_validate_unknown_section:870: Get section version for image PCI2
1-4-2-12-2-2:[PCI2]:[version]:[COPY_START]:[21167623]
DEBUG: Xboot_xsign_copyfunc:126: CopyFunc: imgBase: 15800000, componentOffset: 1000
DEBUG: Xboot_xsign_copyfunc:127: copy 15801000,10 -> 10000000
1-4-2-12-2-3:[PCI2]:[version]:[COPY_END]:[21187074]
DEBUG: Xboot_xsign_digestfunc:153: Digest 10000000,10
DEBUG: Xboot_crypto_sha256:127: Software SHA256! 10 @ 10000000
DEBUG: Xboot_crypto_sha256:139: Returning digest 80c1a9577f7ac695e70c795b5f84b83d496084948b5b186344619172ce9bbe9d
1-4-2-12-x-00:[PCI2]:[version]:[SECTION_VERIFICATION_SUCCESS]:[21210152]
DEBUG: Xboot_xsign_load_section:683: Get section kernel for image PCI2
1-4-2-1-2-2:[PCI2]:[kernel]:[COPY_START]:[21222826]
DEBUG: Xboot_xsign_copyfunc:126: CopyFunc: imgBase: 15800000, componentOffset: 2000
DEBUG: Xboot_xsign_copyfunc:127: copy 15802000,11760716 -> 01680000
1-4-2-1-2-3:[PCI2]:[kernel]:[COPY_END]:[21496550]
DEBUG: Xboot_xsign_digestfunc:153: Digest 01680000,11760716
DEBUG: Xboot_crypto_sha256:127: Software SHA256! 11760716 @ 01680000
DEBUG: Xboot_crypto_sha256:139: Returning digest eeb2b00be995bd929f8e6fdd7eb6a3e015180927e7b2ae07f43504707a8a5071
1-4-2-1-x-00:[PCI2]:[kernel]:[SECTION_VERIFICATION_SUCCESS]:[21914826]
1-4-2-1-2-0:[PCI2]:[kernel]:[DECRYPTION_START]:[21921068]
1-4-2-1-2-1:[PCI2]:[kernel]:[DECRYPTION_END]:[21926190]
DEBUG: Xboot_xsign_query_partition:512: Section DM_rootfs of image PCI2: XSIGN_STATUS_FAILURE not  present.
DEBUG: Xboot_xsign_query_partition:512: Section initramfs of image PCI2: XSIGN_STATUS_FAILURE not  present.
DEBUG: Xboot_xsign_load_section:683: Get section rootfs for image PCI2
1-4-2-2-2-2:[PCI2]:[rootfs]:[COPY_START]:[21956312]
DEBUG: Xboot_xsign_copyfunc:126: CopyFunc: imgBase: 15800000, componentOffset: b47000
DEBUG: Xboot_xsign_copyfunc:127: copy 16347000,44769280 -> 20000000
1-4-2-2-2-3:[PCI2]:[rootfs]:[COPY_END]:[22941703]
DEBUG: Xboot_xsign_digestfunc:153: Digest 20000000,44769280
DEBUG: Xboot_crypto_sha256:127: Software SHA256! 44769280 @ 20000000
DEBUG: Xboot_crypto_sha256:139: Returning digest ec9fa62dc15440f0e66a9f8c0cd6fc7cbffbad891097da28382b7fd4fb2c7993
1-4-2-2-x-00:[PCI2]:[rootfs]:[SECTION_VERIFICATION_SUCCESS]:[24477563]
1-4-2-2-2-0:[PCI2]:[rootfs]:[DECRYPTION_START]:[24483806]
1-4-2-2-2-1:[PCI2]:[rootfs]:[DECRYPTION_END]:[24488927]
DEBUG: Xboot_xsign_load_section:743: Decrypted Section size: [44769280]
DEBUG: Xboot_xsign_load_section:683: Get section dtb for image PCI2
1-4-2-4-2-2:[PCI2]:[dtb]:[COPY_START]:[24506205]
DEBUG: Xboot_xsign_copyfunc:126: CopyFunc: imgBase: 15800000, componentOffset: b3a000
DEBUG: Xboot_xsign_copyfunc:127: copy 1633A000,49153 -> 38001000
1-4-2-4-2-3:[PCI2]:[dtb]:[COPY_END]:[24528847]
DEBUG: Xboot_xsign_digestfunc:153: Digest 38001000,49153
DEBUG: Xboot_crypto_sha256:127: Software SHA256! 49153 @ 38001000
DEBUG: Xboot_crypto_sha256:139: Returning digest 5a18d340fa2ebf2fb57b9b45e17ccb1c52cc9e4b3cf805dc82e35588d94eac94
1-4-2-4-x-00:[PCI2]:[dtb]:[SECTION_VERIFICATION_SUCCESS]:[24550979]
1-4-2-4-2-0:[PCI2]:[dtb]:[DECRYPTION_START]:[24556967]
1-4-2-4-2-1:[PCI2]:[dtb]:[DECRYPTION_END]:[24561828]
DEBUG: Xboot_xsign_load_section:683: Get section bootargs for image PCI2
1-4-2-3-2-2:[PCI2]:[bootargs]:[COPY_START]:[24572942]
DEBUG: Xboot_xsign_copyfunc:126: CopyFunc: imgBase: 15800000, componentOffset: 35f9000
DEBUG: Xboot_xsign_copyfunc:127: copy 18DF9000,56 -> 38000000
1-4-2-3-2-3:[PCI2]:[bootargs]:[COPY_END]:[24592653]
DEBUG: Xboot_xsign_digestfunc:153: Digest 38000000,56
DEBUG: Xboot_crypto_sha256:127: Software SHA256! 56 @ 38000000
DEBUG: Xboot_crypto_sha256:139: Returning digest 2ab1d916fa21fd4a9d6891e12c233b11887c39c93ecd84d7b473244739f13f54
1-4-2-3-x-00:[PCI2]:[bootargs]:[SECTION_VERIFICATION_SUCCESS]:[24615732]
1-4-2-3-2-0:[PCI2]:[bootargs]:[DECRYPTION_START]:[24622154]
1-4-2-3-2-1:[PCI2]:[bootargs]:[DECRYPTION_END]:[24627449]
DEBUG: Xboot_xsign_load_section:743: Decrypted Section size: [56]
DEBUG: Xboot_load_section:639: Image load boot arguments with size=56
TS 24644547: Xboot_try_image_loaded
DEBUG: Xboot_try_image:798: Kernel and rootfs ready

1-4-2-X-00:[PCI2]:[IMAGE_STATUS_OK]:[24652536]
TS 24656699: Xboot_try_image_do_boot
DEBUG: Xboot_watchdog_enable:64: Starting watchdog. Timeout: 60s
1-5-7-1-60:[WATCHDOG_TIMER_ENABLE][24665728]
DEBUG: Xboot_do_boot:413: Image: PCI2

1-L-100:[LED_INTENSITY_VALUE][24727430]
DEBUG: getAligned:300: Input=0x2ab2fff Aligned=0x2ab2000
DEBUG: Xboot_set_kernel_cli_args:378: fs.type[0] | bootargs[ ramdisk_size=43720 initrd=0x20000000,44769280 root=/dev/ram0 rootfstype=squashfs xboot.i]
DEBUG: Xboot_xsign_query_partition:512: Section boot_environment of image PCI2: XSIGN_STATUS_FAILURE not  present.
1-4-2-5-4-9:[PCI2]:[IMAGE_RETRY_COUNT_DECREMENT]:[24786648]
1-4-2-5-6-9:[PCI2]:[IMAGE_RETRY_COUNT_VALUE]:[24839933]
5-5-2:[ALL_IMAGE_RETRY_COUNT_DECREMENT][24844828]
1-4-2-5-0-250102103221:[PCI2]:[IMAGE_LAUNCH]:[24846441]
DEBUG: Xboot_os_boot:89: setting bootargs to  ramdisk_size=43720 initrd=0x20000000,44769280 root=/dev/ram0 rootfstype=squashfs xboot.image=PCI2 image

DEBUG: Xboot_os_boot:106: setting bootm_str to bootm 0x01680000 - 0x38001000 kernel = 3800100001680000 dtb = 38001000

DEBUG: Xboot_standalone_exit:48: jumping to exit point
DEBUG: Xboot_standalone_entry:18: Xboot exiting
## Application terminated, rc = 0x0
## Booting kernel from Legacy Image at 01680000 ...
   Image Name:   Linux
   Image Type:   ARM Linux Kernel Image (uncompressed)
   Data Size:    11760652 Bytes = 11.2 MiB
   Load Address: 01008000
   Entry Point:  01008000
   Verifying Checksum ... OK
## Flattened Device Tree blob at 38001000
   Booting using the fdt blob at 0x38001000
   Loading Kernel Image ... OK
   Loading Device Tree to 07f73000, end 07fff000 ... OK
RSVD: not found enrty for adsl
RSVD: not found enrty for bufmem
RSVD: not found enrty for rnrmem
RSVD: Allocated for rdp1    64MB
RSVD: Allocated for rdp2    12MB
RSVD: Allocated for blbank    1MB
RSVD: Allocated for dhd2    11MB
RSVD: Total 0x05800000 bytes CMA reserved memory @ 0x3a800000
linux boot command line overriden from bootargs env variable:
    ramdisk_size=43720 initrd=0x20000000,44769280 root=/dev/ram0 rootfstype=squashfs xboot.image=PCI2 image_name=WNXL11BWL_BCA_PLATFORM_2025010210310

Starting kernel ...

Booting Linux on physical CPU 0x0
Linux version 4.19.294 (srs730@rdk-dunfell) (gcc version 9.3.0 (GCC)) #1 SMP PREEMPT Mon Dec 30 16:27:19 UTC 2024
CPU: ARMv7 Processor [410fc075] revision 5 (ARMv7), cr=10c5387d
CPU: div instructions available: patching division code
CPU: PIPT / VIPT nonaliasing data cache, VIPT aliasing instruction cache
OF: fdt: Machine model: WNXL11BWL
earlycon: pl11 at MMIO 0xff812000 (options '115200n8')
bootconsole [pl11] enabled
Memory policy: Data cache writealloc
Reserved memory: created CMA memory pool at 0x3a800000, size 88 MiB
OF: reserved mem: initialized node dt_reserved_cma, compatible id shared-dma-pool
psci: probing for conduit method from DT.
psci: PSCIv1.1 detected in firmware.
psci: Using standard PSCI v0.2 function IDs
psci: MIGRATE_INFO_TYPE not supported.
psci: SMC Calling Convention v1.0
percpu: Embedded 14 pages/cpu s27980 r8192 d21172 u57344
Built 1 zonelists, mobility grouping on.  Total pages: 260608
Kernel command line:  ramdisk_size=43720 initrd=0x20000000,44769280 root=/dev/ram0 rootfstype=squashfs xboot.image=PCI2 image_name=WNXL11BWL_BCA_PLAT
Dentry cache hash table entries: 131072 (order: 7, 524288 bytes)
Inode-cache hash table entries: 65536 (order: 6, 262144 bytes)
Memory: 888104K/1048576K available (7168K kernel code, 253K rwdata, 1568K rodata, 1024K init, 571K bss, 70360K reserved, 90112K cma-reserved, 172032K)
Virtual kernel memory layout:
    vector  : 0xffff0000 - 0xffff1000   (   4 kB)
    fixmap  : 0xffc00000 - 0xfff00000   (3072 kB)
    vmalloc : 0xf0800000 - 0xff800000   ( 240 MB)
    lowmem  : 0xc0000000 - 0xf0000000   ( 768 MB)
    pkmap   : 0xbfe00000 - 0xc0000000   (   2 MB)
    modules : 0xbf000000 - 0xbfe00000   (  14 MB)
      .text : 0x(ptrval) - 0x(ptrval)   (8160 kB)
      .init : 0x(ptrval) - 0x(ptrval)   (1024 kB)
      .data : 0x(ptrval) - 0x(ptrval)   ( 254 kB)
       .bss : 0x(ptrval) - 0x(ptrval)   ( 572 kB)
SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=3, Nodes=1
rcu: Preemptible hierarchical RCU implementation.
        Tasks RCU enabled.
NR_IRQS: 16, nr_irqs: 16, preallocated irqs: 16
arch_timer: cp15 timer(s) running at 50.00MHz (phys).
clocksource: arch_sys_counter: mask: 0xffffffffffffff max_cycles: 0xb8812736b, max_idle_ns: 440795202655 ns
sched_clock: 56 bits at 50MHz, resolution 20ns, wraps every 4398046511100ns
Switching to timer-based delay loop, resolution 20ns
Calibrating delay loop (skipped), value calculated using timer frequency.. 100.00 BogoMIPS (lpj=50000)
CPU: Testing write buffer coherency: ok
pid_max: default: 32768 minimum: 301
Security Framework initialized
AppArmor: AppArmor initialized
Mount-cache hash table entries: 2048 (order: 1, 8192 bytes)
Mountpoint-cache hash table entries: 2048 (order: 1, 8192 bytes)
Setting up static identity map for 0x1100000 - 0x1100060
rcu: Hierarchical SRCU implementation.
CCI-500 hardware cache coherency enabled
bootloader version  U-Boot2019.07(11/28/2024-15:28:09+0000)5.04L.03@370050
BoardId [WNXL11BWL], NVRAM_ULBOARDSTUFFOPTION=0
Booted from eMMC boot partition 1
smp: Bringing up secondary CPUs ...
smp: Brought up 1 node, 3 CPUs
SMP: Total of 3 processors activated (300.00 BogoMIPS).
CPU: All CPU(s) started in SVC mode.
devtmpfs: initialized
VFP support v0.3: implementor 41 architecture 2 part 30 variant 7 rev 5
clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
futex hash table entries: 1024 (order: 4, 65536 bytes)
pinctrl core: initialized pinctrl subsystem
NET: Registered protocol family 16
OTP driver initcall
OTP driver scanning DT
Strap Register: 0x7fffeff7
DMA: preallocated 256 KiB pool for atomic coherent allocations
audit: initializing netlink subsys (disabled)
audit: type=2000 audit(0.047:1): state=initialized audit_enabled=0 res=1
cpuidle: using governor ladder
BCM UBUS Driver initcall
ubus systop              phys addr 0x83000000 virt addr 0xf0815000
ubus registration        phys addr 0x83000200 virt addr 0xf0862200
ubus coherency           phys addr 0x810a0400 virt addr 0xf0864400
ubus mst node BIU        phys addr 0x83020000 virt addr 0xf0866000
ubus mst node PER        phys addr 0x83010000 virt addr 0xf0868000
ubus mst node USB        phys addr 0x83018000 virt addr 0xf086a000
ubus mst node WIFI0      phys addr 0x83050000 virt addr 0xf086c000
ubus mst node PCIE0      phys addr 0x83030000 virt addr 0xf086e000
ubus mst node DMA0       phys addr 0x83078000 virt addr 0xf0870000
ubus mst node DMA1       phys addr 0x8307c000 virt addr 0xf0872000
ubus mst node DMA2       phys addr 0x83088000 virt addr 0xf0874000
ubus mst node QM         phys addr 0x83070000 virt addr 0xf0876000
ubus mst node RQ0        phys addr 0x8308c000 virt addr 0xf0878000
ubus mst node RQ1        phys addr 0x83090000 virt addr 0xf087a000
PMC driver initcall
PMC driver scanning DT
 not match PMC
pmc match PMC brcm,bca-pmc-lite
     Remapping PMC IO memories...
             phys              virt          size
     0x00000000ffb20060 0x00000000f087c060 0x000001e0
AVS:InitMemory
AVS:MapSystem
PVTMON: 1VD AVS closed at 904mV
PVTMON: Current Die temp is 48871mC
PVTMON: Current DAC value 542 = 665mV
PVTMON is locked in range 512 ... 572
AVS:Schedule tracking
pmc_init:PMC using PMB_DIRECT mode
Serial: AMBA PL011 UART driver
Powering on XRDP core...
Toggle reset of XRDP core...
bcm_rsvmem plat_rsvmem_cached_device: assigned reserved memory node dt_reserved_cma
reserved CMA memory rdp1 virt addr f0880000 phys addr 0x3a800000 size 0x4000000 cached=1
bcm_rsvmem plat_rsvmem_uncached_device: assigned reserved memory node dt_reserved_cma
reserved CMA memory rdp2 virt addr f4881000 phys addr 0x3e800000 size 0xc00000 cached=0
reserved CMA memory dhd2 virt addr f5482000 phys addr 0x3f400000 size 0xb00000 cached=0
brcm_otp_init entry
bcm-bca-gpio ff800500.gpioc: Setting up BCA GPIO
bca_extintr ff800004.bca_extintr0: Ext_Int_0 HWIrq 152 virq 40
bca_extintr ff800004.bca_extintr0: Ext_Int_1 HWIrq 153 virq 41
bca_extintr ff800004.bca_extintr0: Ext_Int_2 HWIrq 154 virq 42
bca_extintr ff800004.bca_extintr0: Ext_Int_3 HWIrq 155 virq 43
bca_extintr ff800004.bca_extintr0: Ext_Int_4 HWIrq 156 virq 44
bca_extintr ff800004.bca_extintr0: Ext_Int_5 HWIrq 157 virq 45
bca_extintr ff800004.bca_extintr0: Ext_Int_6 HWIrq 158 virq 46
bca_extintr ff800004.bca_extintr0: Ext_Int_7 HWIrq 159 virq 47
bca_extintr ff800004.bca_extintr0: Readed resouce bca_extintr0 start 0xff800004 end 0xff80004b
bcm-bca-cled-ctrl ff803000.led_ctrl: max supported leds 32[32]
bcm-bca-cled-ctrl ff803000.led_ctrl:  Parallel CLED interface found
bcm-bca-cled-ctrl ff803000.led_ctrl: BCA CLED Controller initialized
SCSI subsystem initialized
usbcore: registered new interface driver usbfs
usbcore: registered new interface driver hub
usbcore: registered new device driver usb
NET: Registered protocol family 8
NET: Registered protocol family 20
map_hw_timer_interrupt,162: interrupt_id 36
map_hw_timer_interrupt,162: interrupt_id 37
map_hw_timer_interrupt,162: interrupt_id 38
map_hw_timer_interrupt,162: interrupt_id 39
bca_extintr ff800004.bca_extintr0: GPIO 29 is mapped to ExtIntr_0 [virq 40]
input: buttons as /devices/platform/buttons/input/input0
bcm-bca-leds ff803000.led_ctrl:parallel-port_0-led_0: led 8 registered
bcm-bca-leds ff803000.led_ctrl:parallel-port_0-led_1: led 9 registered
bcm-bca-leds ff803000.led_ctrl:parallel-port_3-led_0: led 14 registered
bcm-bca-leds ff803000.led_ctrl:parallel-port_3-led_1: led 15 registered
bcm-bca-leds ff803000.led_ctrl:sw_parallel_led_9: led 0 registered
bcm-bca-leds ff803000.led_ctrl:sw_parallel_led_13: led 10 registered
bcm-bca-leds ff803000.led_ctrl:sw_parallel_led_14: led 12 registered
bcm-bca-leds ff803000.led_ctrl:wl_pwr_0: led 0 registered
bcm-dgasp ff85a004.dying_gasp: Dying Gasp platform device brcm,dgasp-periph matched
dg-periph-reg: 0xff85a004<-->0xf5fa7004:0x00000000
dg-get-otp-trim: 0x00000000
dtb-dg-trim    : 0x00000000
dg-get-otp-hys : 0x00000000
dtb-dg-hys     : 0x00000000
DYING GASP IRQ Initialized and Enabled
Broadcom GBPMv0.1 initialized
Broadcom IQoS v1.0 initialized
Broadcom Logger v0.1
Char device /dev/bcmnet(250) registered
Assigning idx[1] for lo
skb_free_task created successfully with start budget 32, period 10ms
BLOG v3.0 Initialized
BLOG Rule v1.0 Initialized
 create_bcm_tcp_task:348 bind_mask:0x2
bcm_tcp_task created successfully with budget 256 ,cpumask:0x2
clocksource: Switched to clocksource arch_sys_counter
AppArmor: AppArmor Filesystem Enabled
NET: Registered protocol family 2
IP idents hash table entries: 16384 (order: 5, 131072 bytes)
tcp_listen_portaddr_hash hash table entries: 512 (order: 0, 6144 bytes)
TCP established hash table entries: 8192 (order: 3, 32768 bytes)
TCP bind hash table entries: 8192 (order: 4, 65536 bytes)
TCP: Hash tables configured (established 8192 bind 8192)
UDP hash table entries: 512 (order: 2, 16384 bytes)
UDP-Lite hash table entries: 512 (order: 2, 16384 bytes)
NET: Registered protocol family 1
Assigning idx[2] for blogtcp_local
blogtcp_local netdev registered successfully
Trying to unpack rootfs image as initramfs...
rootfs image is not initramfs (junk in compressed archive); looks like an initrd
Freeing initrd memory: 43720K
Initialise system trusted keyrings
workingset: timestamp_bits=30 max_order=18 bucket_order=0
squashfs: version 4.0 (2009/01/31) Phillip Lougher
jffs2: version 2.2. (NAND) (SUMMARY)  Â© 2001-2006 Red Hat, Inc.
fuse init (API version 7.27)
Key type asymmetric registered
Asymmetric key parser 'x509' registered
io scheduler noop registered (default)
io scheduler mq-deadline registered
io scheduler kyber registered
brd: module loaded
loop: module loaded
bcmbca-hsspi ff801000.spi: Broadcom BCMBCA High Speed SPI Controller driver
bcmbca-hsspi ff801000.spi: spi driver using polling mode
Assigning idx[3] for dummy0
Assigning idx[4] for ifb0
Assigning idx[5] for ifb1
PPP generic driver version 2.4.2
PPP BSD Compression module registered
PPP Deflate Compression module registered
NET: Registered protocol family 24
usbcore: registered new interface driver cdc_wdm
i2c /dev entries driver
sdhci: Secure Digital Host Controller Interface driver
sdhci: Copyright(c) Pierre Ossman
sdhci-pltfm: SDHCI platform and OF driver helper
mmc0: SDHCI controller on ff810000.sdhci [ff810000.sdhci] using ADMA
usbcore: registered new interface driver usbhid
usbhid: USB HID core driver
optee: probing for conduit method from DT.
optee: revision 3.7 (a2fa5018)
optee: initialized driver
pktgen: Packet Generator for packet performance testing. Version: 2.75
GACT probability NOT on
Mirror/redirect action on
Simple TC action Loaded
u32 classifier
    input device check on
    Actions configured
xt_time: kernel timezone is -0000
gre: GRE over IPv4 demultiplexor driver
ip_gre: GRE over IPv4 tunneling driver
Assigning idx[6] for gre0
Assigning idx[7] for gretap0
Assigning idx[8] for erspan0
Initializing XFRM netlink socket
NET: Registered protocol family 10
Segment Routing with IPv6
sit: IPv6, IPv4 and MPLS over IPv4 tunneling driver
Assigning idx[9] for sit0
Assigning idx[10] for ip6tnl0
ip6_gre: GRE over IPv6 tunneling driver
Assigning idx[11] for ip6gre0
NET: Registered protocol family 17
NET: Registered protocol family 15
bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
l2tp_core: L2TP core driver, V2.0
l2tp_ppp: PPPoL2TP kernel driver, V2.0
8021q: 802.1Q VLAN Support v1.8
sctp: Hash tables configured (bind 512/512)
brcmboard registered
brcmboard: brcm_board_init entry
 --- WNXL11BWL gpio init start ----
 --- WNXL11BWL gpio init done ----
bcm_memc 80180e08.memory_controller: matched the memory controller to brcm,bcm-memc
bcm-ubus-dcm 83000080.ubus_dcm_sys: Broadcom BCA UBUS DCM Driver
bcm-ubus-dcm 83000080.ubus_dcm_sys: ubus dcm clk resource [mem 0x83000080-0x830000ff flags 0x200]
bcm-ubus-dcm 83000080.ubus_dcm_sys: map to virt addr 0xf6025080
BOOT REASON 0x14
RESET STATUS 0x20000000

Optical detection module loaded.
mmc0: new high speed MMC card at address 0001
Bridge Broadcom hooks registered
ebt_blog registered
mmcblk0: mmc0:0001 008GB1 7.28 GiB
ebt_ftos registered
mmcblk0boot0: mmc0:0001 008GB1 partition 1 4.00 MiB
ebt_qos_map registered
mmcblk0boot1: mmc0:0001 008GB1 partition 2 4.00 MiB
ebt_time registered
mmcblk0rpmb: mmc0:0001 008GB1 partition 3 4.00 MiB, chardev (248:0)
ebt_dscp registered
ebt_vtag registered
ebt_wmm_mark registered
ebt_reject registered
brcm-unimac 828a8000.unimac: registered
brcm-mdio1 ff802060.mdio1: clock-divider=12
brcm-mdio1 ff802060.mdio1: clock-divider-fast=4
Alternate GPT is invalid, using primary GPT.
brcm-mdio1 ff802060.mdio1: registered
 mmcblk0: p1 p2 p3 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14 p15 p16 p17 p18
MDIO Clock Divider Value: 12 Probe mode: No
brcm-egphy 828ba204.egphy: registered
brcm-xrdpled 828a0200.xrdpled: registered
brcm-sgmii 828ba280.sgmii: registered
brcm-rgmii 828a0300.rgmii: registered
Registering SWP/SWPB emulation handler
Loading compiled-in X.509 certificates
Key type trusted registered
Key type encrypted registered
AppArmor: AppArmor sha1 policy hashing enabled
ff812000.serial0: ttyAMA0 at MMIO 0xff812000 (irq = 33, base_baud = 0) is a PL011 rev3
console [ttyAMA0] enabled
console [ttyAMA0] enabled
bootconsole [pl11] disabled
bootconsole [pl11] disabled
Registered phy device: EGPHY:0x2
Registered phy device: EGPHY:0x5
RAMDISK: squashfs filesystem found at block 0
RAMDISK: Loading 43718KiB [1 disk] into ram disk... -
\
|
/
-
\
done.
VFS: Mounted root (squashfs filesystem) readonly on device 1:0.
devtmpfs: mounted
Freeing unused kernel memory: 1024K
Checked W+X mappings: passed, no W+X pages found
Run /sbin/init as init process
systemd[1]: System time before build time, advancing clock.
systemd[1]: systemd 244 running in system mode. (-PAM -AUDIT -SELINUX +IMA +APPARMOR -SMACK +SYSVINIT +UTMP -LIBCRYPTSETUP -GCRYPT -GNUTLS -ACL +XZ -)
systemd[1]: Detected architecture arm.

Welcome to RDK (A Yocto Project based Distro) 2.0 (dunfell)!

systemd[1]: Set hostname to <xle-wnc>.
random: systemd: uninitialized urandom read (16 bytes read)
systemd[1]: Initializing machine ID from random generator.
systemd[1]: Installed transient /etc/machine-id file.
systemd[1]: /lib/systemd/system/dbus.socket:5: ListenStream= references a path below legacy directory /var/run/, updating /var/run/dbus/system_bus_so.
random: systemd: uninitialized urandom read (16 bytes read)
systemd[1]: system-getty.slice: unit configures an IP firewall, but the local system does not support BPF/cgroup firewalling.
systemd[1]: (This warning is only shown for the first unit using IP firewalling.)
systemd[1]: Created slice system-getty.slice.
[  OK  ] Created slice system-getty.slice.
random: systemd: uninitialized urandom read (16 bytes read)
systemd[1]: Created slice system-serial\x2dgetty.slice.
[  OK  ] Created slice system-serial\x2dgetty.slice.
systemd[1]: Started Dispatch Password Requests to Console Directory Watch.
[  OK  ] Started Dispatch Password â�…ts to Console Directory Watch.
systemd[1]: Started Forward Password Requests to Wall Directory Watch.
[  OK  ] Started Forward Password Râ�…uests to Wall Directory Watch.
systemd[1]: Reached target Network is Online.
[  OK  ] Reached target Network is Online.
systemd[1]: Reached target Paths.
[  OK  ] Reached target Paths.
systemd[1]: Reached target Remote File Systems.
[  OK  ] Reached target Remote File Systems.
systemd[1]: Reached target Slices.
[  OK  ] Reached target Slices.
systemd[1]: Reached target Swap.
[  OK  ] Reached target Swap.
systemd[1]: Listening on initctl Compatibility Named Pipe.
[  OK  ] Listening on initctl Compatibility Named Pipe.
systemd[1]: Listening on Journal Audit Socket.
[  OK  ] Listening on Journal Audit Socket.
systemd[1]: Listening on Journal Socket (/dev/log).
[  OK  ] Listening on Journal Socket (/dev/log).
systemd[1]: Listening on Journal Socket.
[  OK  ] Listening on Journal Socket.
systemd[1]: Listening on udev Control Socket.
[  OK  ] Listening on udev Control Socket.
systemd[1]: Listening on udev Kernel Socket.
[  OK  ] Listening on udev Kernel Socket.
systemd[1]: Condition check resulted in Huge Pages File System being skipped.
systemd[1]: Mounting POSIX Message Queue File System...
         Mounting POSIX Message Queue File System...
systemd[1]: Mounting Kernel Debug File System...
         Mounting Kernel Debug File System...
systemd[1]: Mounting Temporary Directory (/tmp)...
         Mounting Temporary Directory (/tmp)...
systemd[1]: Starting AppArmor initialization...
         Starting AppArmor initialization...
systemd[1]: Started AppArmor Early start.
[  OK  ] Started AppArmor Early start.
systemd[1]: Condition check resulted in Create list of static device nodes for the current kernel being skipped.
systemd[1]: Starting Journal Service...
         Starting Journal Service...
systemd[1]: Condition check resulted in Load Kernel Modules being skipped.
systemd[1]: Mounting FUSE Control File System...
         Mounting FUSE Control File System...
systemd[1]: Condition check resulted in Kernel Configuration File System being skipped.
systemd[1]: Starting Remount Root and Kernel File Systems...
         Starting Remount Root and Kernel File Systems...
systemd[1]: Starting Apply Kernel Variables...
         Starting Apply Kernel Variables...
systemd[1]: Starting udev Coldplug all Devices...
         Starting udev Coldplug all Devices...
systemd[1]: Mounted POSIX Message Queue File System.
[  OK  ] Mounted POSIX Message Queue File System.
systemd[1]: Mounted Kernel Debug File System.
[  OK  ] Mounted Kernel Debug File System.
systemd[1]: Started Journal Service.
[  OK  ] Started Journal Service.
[  OK  ] Mounted Temporary Directory (/tmp).
[FAILED] Failed to start AppArmor initialization.
See 'systemctl status apparmor.service' for details.
[  OK  ] Mounted FUSE Control File System.
[  OK  ] Started Remount Root and Kernel File Systems.
         Starting Mount data partition...
         Starting Create Broadocm Static Device Nodes in /dev...
         Starting Start Broadcom Watchdog Timer...
         Starting Create Static Device Nodes in /dev...
random: systemd-journal: uninitialized urandom read (16 bytes read)
[  OK  ] Started Start Broadcom Watchdog Timer.
audit: type=1400 audit(1735574621.224:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="interdevicemanager" pid=812 comm="app"
[  OK  ] Started udev Coldplug all Devices.
audit: type=1400 audit(1735574621.306:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="radiusauthd" pid=956 comm="apparmor_p"
[  OK  ] Started Apply Kernel Variables.
[  OK  ] Started Create Static Device Nodes in /dev.
random: systemd: uninitialized urandom read (16 bytes read)
audit: type=1400 audit(1735574621.373:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name="OvsAgent_ovsdb-server_check.sh" pid=1"
[  OK  ] Reached target Local File Systems (Pre).
random: systemd: uninitialized urandom read (16 bytes read)
         Mounting /minidumps...
         Mounting /mnt...
         Mounting /rdklogs...
         Mounting /var...
         Starting udev Kernel Device Manager...
[  OK  ] Mounted /minidumps.
[  OK  ] Mounted /mnt.
[  OK  ] Mounted /rdklogs.
[  OK  ] Mounted /var.
         Mounting /var/volatile...
         Starting Flush Journal to Persistent Storage...
[  OK  ] Mounted /var/volatile.
         Starting Bind mount volatile /etc/default/locale...
systemd-journald[796]: Received client request to flush runtime journal.
         Starting Bind mount volatile /home/root...
         Starting Bind mount volatile /etc/hostname...
         Starting Bind mount volatile /etc/hosts...
         Starting Bind mount volatile /media...
         Starting Bind mount volatile /etc/wlan/nvram/...
         Starting Bind mount volatile /etc/wlan/nvram/...
[  OK  ] Started Create Broadocm Static Device Nodes in /dev.
[  OK  ] Started Flush Journal to Persistent Storage.
[  OK  ] Started Bind mount volatile /etc/default/locale.
[  OK  ] Started udev Kernel Device Manager.
[  OK  ] Started Bind mount volatile /home/root.
[  OK  ] Started Bind mount volatile /etc/hostname.
[  OK  ] Started Bind mount volatile /etc/hosts.
[  OK  ] Started Bind mount volatile /media.
[  OK  ] Started Bind mount volatile /etc/wlan/nvram/.
[  OK  ] Started Bind mount volatile /etc/wlan/nvram/.
[  OK  ] Reached target Local File Systems.
random: systemd: uninitialized urandom read (16 bytes read)
random: systemd: uninitialized urandom read (16 bytes read)
random: systemd: uninitialized urandom read (16 bytes read)
EXT4-fs (mmcblk0p6): mounted filesystem with ordered data mode. Opts: (null)
EXT4-fs (mmcblk0p9): mounted filesystem with ordered data mode. Opts: (null)
[  OK  ] Started Mount data partition.
         Starting Install Broadcom base drivers test...
         Starting Create Volatile Files and Directories...
[  OK  ] Started Create Volatile Files and Directories.
         Starting Run pending postinsts...
         Starting Rebuild Journal Catalog...
         Starting Update UTMP about System Boot/Shutdown...
[  OK  ] Started Update UTMP about System Boot/Shutdown.
[  OK  ] Started Rebuild Journal Catalog.
         Starting Update is Completed...
[FAILED] Failed to start Run pending postinsts.
See 'systemctl status run-postinsts.service' for details.
[  OK  ] Started Update is Completed.
BCMLIBS loaded...
Initializing WLCSM Module
WLCSM Module loaded successfully
bcm_bpm: module license 'Proprietary' taints kernel.
Disabling lock debugging due to kernel taint
Broadcom BPM Module Char Driver v0.1 Registered<304>
[NTC bpm] bpm_pool_manager_init: num_objs_per_slab:0 init_num_buf:11983

[NTC bpm] bpm_init_buf_pool: buf_top_idx:11983
[NTC bpm] bpm_init_buf_pool: num_bpm_slabs:0
[NTC bpm] bpm_init_skb_pool: skbs pool inited total 11983
Broadcom 802.1Q VLAN Interface, v0.1

Note: select_fpm_buf_size#353: BCM_MAX_PKT_LEN_MTU_BASED 1532 BCM_PKTBUF_SIZE 2624 TOTAL_FPM_TOKENS 131072 CHIP_VER 61 fpm_pool_memory_size 67108864 0

Note: select_fpm_buf_size#579: BCM_MAX_PKT_LEN_MTU_BASED 1532 TOTAL_FPM_TOKENS 131072 CHIP_VER 61 fpm_pool_memory_size 67108864 fpm_buf_size 512 fpm_0




++++Runner sg_desc_pool and sg_header_pool created successfully !!!!!!!!!!!!!!!!
SG descriptor Num_of_entries 4096, sz_of_entry 56, mem_size 229376, addr 0xee3c0000
SG header pool Num_of_entries 4096, sz_of_entry 128, mem_size 524288, addr 0xedc00000
Creating CPU ring for queue number 26 with 24576 packets descriptor=0xbf4fcdf0, size_of_entry 8
Done initializing Ring 26 Base=0xedcc0000 num of entries= 24576 RDD Base=2dcc0000 descriptor=0xbf4fcdf0
Creating CPU ring for queue number 27 with 2048 packets descriptor=0xbf4fce48, size_of_entry 16
Done initializing Ring 27 Base=0xedd00000 num of entries= 2048 RDD Base=2dd00000 descriptor=0xbf4fce48
Creating CPU ring for queue number 28 with 2048 packets descriptor=0xbf4fcea0, size_of_entry 16
Done initializing Ring 28 Base=0xedd10000 num of entries= 2048 RDD Base=2dd10000 descriptor=0xbf4fcea0
Creating CPU ring for queue number 25 with 32768 packets descriptor=0xbf4fcd98, size_of_entry 8
Done initializing Ring 25 Base=0xedd80000 num of entries= 32768 RDD Base=2dd80000 descriptor=0xbf4fcd98
Creating CPU ring for queue number 24 with 4096 packets descriptor=0xbf4fcd40, size_of_entry 8
Done initializing Ring 24 Base=0xedd20000 num of entries= 4096 RDD Base=2dd20000 descriptor=0xbf4fcd40
Enforcer is ready
Broadcom BP3 Driver - Platform: TELCO, BPA: v0, BLOB: v1, License Folder: "/data/licenses", Chip Name: 6753, OUI: D89C8E, Release Tag: 5.04L.04p3
[ERROR bp3] __license_verify_and_load,154: Wrong CCF size 366 expected 1076
BP3 status - provisioned
Broadcom Ingress QoS Module  Char Driver v1.0 Registered<244>

Broadcom Ingress QoS v1.0 initialized
Broadcom Packet Flow Cache
FCACHE_CONFIG_MAX_UCAST_FLOW_ENTRIES<16384>
FCACHE_CONFIG_MAX_MCAST_GROUPS<256>
FCACHE_CONFIG_MAX_MCAST_CLIENTS_PER_GROUP<64>
FCACHE_CONFIG_MAX_MCAST_CLIENTS<1024>
FCACHE_CONFIG_MAX_UNKNOWN_UCAST_GROUPS<16>
FCACHE_CONFIG_MAX_UNKNOWN_UCAST_CLIENTS_PER_GROUP<16>
FCACHE_CONFIG_MAX_UNKNOWN_UCAST_CLIENTS<256>
FCACHE_CONFIG_MAX_FDB_ENTRIES<1024>
FCACHE_CONFIG_MAX_HOST_DEV_ENTRIES<64>
FCACHE_CONFIG_MAX_HOST_MAC_ENTRIES<32>
FCACHE_CONFIG_MAX_FLOW_ENTRIES<17664>
npe_max_entries<17664>
Bind blog_notify_evt_enqueue_fn[<bf6c2260>]
fc_evt task created successfully
max_ent = 17664 intvl_msec = 10000 num_slices = 2000 num_ent = 9 period_msec = 5
NBUFF v1.0 Initialized
fcache: max_groups<256> mcast_max_clients_per_group<64> mcast_max_clients<1024>
fcache: mcast_max_ent<1280>
fcache: unknown_ucast_max_groups<16> unknown_ucast_max_clients_per_group<16> unknown_ucast_max_clients<256>
fcache: unknown_ucast_group_max_ent<272>
fcache: ucast_max_ent<16384>
fcache: max_ent<17664>
group_type_mcast.group_bitmap_pool_p<ee699780>
group_type_unknown_ucast.group_bitmap_pool_p<ee699d80>
Total # of labels = 79
Initialized fcache state
        Pkt HW acceleration is disabled/unavailable.
Broadcom Packet Flow Cache  Char Driver v4.0 Registered<302>
fc_timer_task created successfully
        Pkt HW acceleration is disabled/unavailable.
Created Proc FS /procfs/fcache
Broadcom Packet Flow Cache registered with netdev chain
Broadcom Packet Flow Cache learning via BLOG enabled.
[FHW]  pktDbgLvl[0xbf6e4a84]=0
[FHW]  fhw_construct:
Initialized Fcache HW accelerator layer state
flwStatsThread created. numFlwsPerPoll 588 maxFlwIdx 17663
Fcache Pathstats created
Constructed Broadcom Packet Flow Cache v4.0
Broadcom Command List Driver v1.0
bcmenet DT
Registered mac device: UNIMAC:0x0
bca_led_request_network_leds:L816 network led 0 for port 0 link 0x3 activity 0x3
bca_led_request_network_leds:L816 network led 1 for port 0 link 0x4 activity 0x4
Registered mac device: UNIMAC:0x3
bca_led_request_network_leds:L816 network led 0 for port 3 link 0x3 activity 0x3
bca_led_request_network_leds:L816 network led 1 for port 3 link 0x4 activity 0x4
Assigning idx[12] for bcmsw
BCMENET: Enabling Software GSO for bcmsw
Assigning idx[13] for eth0
BCMENET: Enabling Software GSO for eth0
Assigning idx[14] for eth1
BCMENET: Enabling Software GSO for eth1
random: systemd: uninitialized urandom read (16 bytes read)
Creating CPU ring for queue number 4 with 1024 packets descriptor=0xbf4fc660, size_of_entry 16
Done initializing Ring 4 Base=0xedee0000 num of entries= 1024 RDD Base=2dee0000 descriptor=0xbf4fc660
Creating CPU ring for queue number 3 with 1024 packets descriptor=0xbf4fc608, size_of_entry 16
Done initializing Ring 3 Base=0xedee8000 num of entries= 1024 RDD Base=2dee8000 descriptor=0xbf4fc608
dgasp: kerSysRegisterDyingGaspHandler: bcmsw registered
xrdp_leds_init Port 0 configured
xrdp_leds_init Port 3 configured
[NTC bitpool] idx_pool_init: 533:PktRnr[0]:Create Index Pool_Size = 17408
[NTC bitpool] idx_pool_init: 533:L2L3-ucast:Create Index Pool_Size = 32768
Initialized Tunnel table key
Initialized Runner Host Layer
Initialized Runner Unicast Layer
Initialized Runner L2 Unicast Layer
[NTC bitpool] idx_pool_init: 533:mcast:Create Index Pool_Size = 1152
IPTV ddr base addr: 0x000000002d820000
IPTV virtual ddr base addr: ed820000
Initialized Runner Multicast Layer
[NTC bitpool] idx_pool_init: 533:FHW[0]:Create Index Pool_Size = 17408
Retrieve num_fhw_path=64
Pathstats allocated 2048 bytes
Flow Cache: Lookup Key Optional Fields bitmasks:
<1> mcast vtag_mask: <0000ffff> <00000fff>
<3> mcast vtag_mask: <0000ffff> <00000fff>
Broadcom Packet Flow Cache HW acceleration enabled.
Enabled Runner binding to Flow Cache
Initialized Runner Protocol Layer (1000)
Broadcom Runner Blog Driver Char Driver v0.1 Registered <309>
[NTC bitpool] idx_pool_init: 533:mcast_whitelist:Create Index Pool_Size = 1024
bcm_mcast_init successful
Broadcom PCIe Host Controller Driver (impl1)
  bcm-pcie: DEF CFG: ssc 0x11, speed  0x0, scanorder 0x0, apon 0x0 barmask 0x0
  bcm-pcie:        : pwr 0x0, errlog 0x1111, msi 0x1111, acc  0x1111, pllclkid 0x3210
  bcm-pcie:        : loglevel 0x1 pllclkadj 0x0 linkupretries 0x0 phyrxfilter 0x0 epuperstb 0x1111
  bcm-pcie: [4] DT node available: vpcie@0
  bcm-pcie: vcore [0] found vdev [0]
  bcm-pcie: Core [4] has 0 regulators
bcm-pcie 84000000.vpcie: PCI host bridge to bus 0000:01
pci_bus 0000:01: root bus resource [mem 0x84000000-0x84ffffff]
pci_bus 0000:01: root bus resource [bus 01]
  bcm-pcie: found Port [4] GEN0 Core Rev [1.00] with 0 Lanes
  bcm-pcie: [4] vcore [0] initialized with [1] device
PCI: bus1: Fast back to back transfers disabled
pci 0000:01:00.0: BAR 0: assigned [mem 0x84000000-0x84ffffff 64bit]
  bcm-pcie: Core [0] DT node available: pcie@0
  bcm-pcie: Core [0] has 0 regulators
bcm-pcie 80040000.pcie: PCI host bridge to bus 0001:00
pci_bus 0001:00: root bus resource [mem 0xc0000000-0xcfffffff]
pci_bus 0001:00: root bus resource [bus 00-0f]
  bcm-pcie: found Port [0] GEN2 Core Rev [4.02] with 1 Lanes
  bcm-pcie: Port [0] using 28hpm-Viper, RefClk:50MHz Serdes
GetRCalSetting_1UM_VERT: SW RCAL_1UM_VERT is not needed on this platform
  bcm-pcie: Port [0] SSC Disabled
  bcm-pcie: Core [0] Using epuperstb
  bcm-pcie: Core [0] Link UP - [1] lanes, [GEN2] speed
  bcm-pcie: Core [0] BAR1 Addr: 0x00_00000000 Size: 1 GB
  bcm-pcie: Port [0] SSC Enabled
  bcm-pcie: Core [0] Enabled PCIE/UBUS Error Interrupts
  bcm-pcie: Core [0] UBUS Intr [UBUS_LINKUP]
PCI: bus0: Fast back to back transfers disabled
pci 0001:00:00.0: bridge configuration invalid ([bus 00-00]), reconfiguring
pci 0001:01:00.0: 4.000 Gb/s available PCIe bandwidth, limited by 5 GT/s x1 link at 0001:00:00.0 (capable of 8.000 Gb/s with 5 GT/s x2 link)
PCI: bus1: Fast back to back transfers disabled
pci 0001:00:00.0: BAR 8: assigned [mem 0xc0000000-0xc0bfffff]
pci 0001:00:00.0: BAR 9: assigned [mem 0xc0c00000-0xc0cfffff 64bit pref]
pci 0001:01:00.0: BAR 2: assigned [mem 0xc0000000-0xc07fffff 64bit]
pci 0001:01:00.0: BAR 4: assigned [mem 0xc0c00000-0xc0cfffff 64bit pref]
pci 0001:01:00.0: BAR 0: assigned [mem 0xc0800000-0xc080ffff 64bit]
pci 0001:00:00.0: PCI bridge to [bus 01]
pci 0001:00:00.0:   bridge window [mem 0xc0000000-0xc0bfffff]
pci 0001:00:00.0:   bridge window [mem 0xc0c00000-0xc0cfffff 64bit pref]
pcieport 0001:00:00.0: enabling device (0140 -> 0142)
  bcm-pcie: Core [1] DT node available: pcie@1
  bcm-pcie: Core [1] has 0 regulators
bcm-pcie 80050000.pcie: PCI host bridge to bus 0002:00
pci_bus 0002:00: root bus resource [mem 0xd0000000-0xdfffffff]
pci_bus 0002:00: root bus resource [bus 00-0f]
  bcm-pcie: found Port [1] GEN2 Core Rev [4.02] with 1 Lanes
  bcm-pcie: Port [1] using 28hpm-Viper, RefClk:50MHz Serdes
GetRCalSetting_1UM_VERT: SW RCAL_1UM_VERT is not needed on this platform
  bcm-pcie: Core [1] Using epuperstb
  bcm-pcie: Core [1] Link UP - [1] lanes, [GEN2] speed
  bcm-pcie: Core [1] BAR1 Addr: 0x00_00000000 Size: 1 GB
  bcm-pcie: Core [1] Enabled PCIE/UBUS Error Interrupts
  bcm-pcie: Core [1] UBUS Intr [UBUS_LINKUP]
PCI: bus0: Fast back to back transfers disabled
pci 0002:00:00.0: bridge configuration invalid ([bus 00-00]), reconfiguring
PCI: bus1: Fast back to back transfers disabled
pci 0002:00:00.0: BAR 8: assigned [mem 0xd0000000-0xd0bfffff]
pci 0002:00:00.0: BAR 9: assigned [mem 0xd0c00000-0xd0cfffff 64bit pref]
pci 0002:01:00.0: BAR 2: assigned [mem 0xd0000000-0xd07fffff 64bit]
pci 0002:01:00.0: BAR 4: assigned [mem 0xd0c00000-0xd0cfffff 64bit pref]
pci 0002:01:00.0: BAR 0: assigned [mem 0xd0800000-0xd080ffff 64bit]
pci 0002:00:00.0: PCI bridge to [bus 01]
pci 0002:00:00.0:   bridge window [mem 0xd0000000-0xd0bfffff]
pci 0002:00:00.0:   bridge window [mem 0xd0c00000-0xd0cfffff 64bit pref]
pcieport 0002:00:00.0: enabling device (0140 -> 0142)
Wifi Forwarding Driver is initialized!
HS UART: Driver $Revision: 1.00 $
ttyH0 at MMIO 0xff810400 (irq = 20, base_baud = 3125000) is a HS_UART
bcm-bca-usb-ctrl 8000c200.usb_ctrl: ---- Powering up USB blocks
bcm-bca-usb-xhci 8000d000.usb0_xhci: registered successfully
ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver
ehci-platform: EHCI generic platform driver
ehci-platform 8000c300.usb0_ehci: EHCI Host Controller
ehci-platform 8000c300.usb0_ehci: new USB bus registered, assigned bus number 1
ehci-platform 8000c300.usb0_ehci: irq 29, io mem 0x8000c300
ehci-platform 8000c300.usb0_ehci: USB 2.0 started, EHCI 1.00
hub 1-0:1.0: USB hub found
hub 1-0:1.0: 1 port detected
ehci-pci: EHCI PCI platform driver
ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver
ohci-platform: OHCI generic platform driver
ohci-platform 8000c400.usb0_ohci: Generic Platform OHCI controller
ohci-platform 8000c400.usb0_ohci: new USB bus registered, assigned bus number 2
ohci-platform 8000c400.usb0_ohci: irq 30, io mem 0x8000c400
hub 2-0:1.0: USB hub found
hub 2-0:1.0: 1 port detected
ohci-pci: OHCI PCI platform driver
xhci-hcd xhci-hcd.0: xHCI Host Controller
xhci-hcd xhci-hcd.0: new USB bus registered, assigned bus number 3
xhci-hcd xhci-hcd.0: hcc params 0x0250f17d hci version 0x100 quirks 0x0000000000014810
xhci-hcd xhci-hcd.0: irq 28, io mem 0x8000d000
hub 3-0:1.0: USB hub found
hub 3-0:1.0: config failed, hub doesn't have any ports! (err -19)
xhci-hcd xhci-hcd.0: xHCI Host Controller
xhci-hcd xhci-hcd.0: new USB bus registered, assigned bus number 4
xhci-hcd xhci-hcd.0: Host supports USB 3.0 SuperSpeed
hub 4-0:1.0: USB hub found
hub 4-0:1.0: 1 port detected
usbcore: registered new interface driver usblp
usb 1-1: new high-speed USB device number 2 using ehci-platform
usbcore: registered new interface driver usb-storage
usbcore: registered new interface driver uas

SMTC PMD driver loaded.
../../bcmdrivers/opensource/char/smtc/bcm96855/bcm_smtc.c.1184.detect_init: platform_driver_register() rc=0
usbserial: *** TTYUSB driver set for LTE Modem communications ***
usbcore: registered new interface driver option
usbserial: USB Serial support registered for GSM modem (1-port)
option 1-1:1.0: GSM modem (1-port) converter detected
usb 1-1: GSM modem (1-port) converter now attached to ttyUSB0
option 1-1:1.1: GSM modem (1-port) converter detected
usb 1-1: GSM modem (1-port) converter now attached to ttyUSB1
option 1-1:1.2: GSM modem (1-port) converter detected
usb 1-1: GSM modem (1-port) converter now attached to ttyUSB2
option 1-1:1.3: GSM modem (1-port) converter detected
usb 1-1: GSM modem (1-port) converter now attached to ttyUSB3
usbnet_thread created successfully
qmi_wwan 1-1:1.4: cdc-wdm0: USB WDM device
Assigning idx[15] for wwan0
qmi_wwan 1-1:1.4 wwan0: register 'qmi_wwan' at usb-8000c300.usb0_ehci-1, WWAN/QMI device, 8a:1b:0a:b9:36:23
usbcore: registered new interface driver qmi_wwan
usbcore: registered new interface driver cdc_ncm
usbcore: registered new interface driver cdc_mbim
bcm_thermal_drv brcm-therm: Trip 0: threshold=105000 mC hysteresis=2000 mC
bcm_thermal_drv brcm-therm: Trip 1: threshold=110000 mC hysteresis=2000 mC
bcm_thermal_drv brcm-therm: Trip 2: threshold=115000 mC hysteresis=2000 mC
bcm_thermal_drv brcm-therm: Trip 11: threshold=120000 mC hysteresis=10000 mC
[  OK  ] Started Install Broadcom base drivers test.
[  OK  ] Reached target System Initialization.
[  OK  ] Started Daily Cleanup of Temporary Directories.
[  OK  ] Reached target Timers.
[  OK  ] Listening on D-Bus System Message Bus Socket.
[  OK  ] Reached target Sockets.
[  OK  ] Reached target Basic System.
         Starting Broadcom BDMF...
         Starting Broadcom Networking Setup Script...
         Starting Broadcom GRE Tunnel Setup Service...
         Starting BCA License Init Service...
         Starting Install Broadocm wifi drivers...
         Starting Default Time Setter...
[  OK  ] Started D-Bus System Message Bus.
[  OK  ] Started Getty on tty1.
[  OK  ] Started XLE LED Assistant service.
         Starting Mount nvram File System Service...
[  OK  ] Started Reset button handler service.
[  OK  ] Started Serial Getty on ttyAMA0.
[  OK  ] Reached target Login Prompts.
[  OK  ] Reached target Multi-User System.
         Starting Update UTMP about System Runlevel Changes...
[  OK  ] Started Sky Xboot PCI Manager Application.
[  OK  ] Started XT4-fs (mmcblk0p7): mounted filesystem with ordered data mode. Opts: (null)
;39mBroadcom BDMF.
[  OK  ] Started Broadcom Networking Setup Script.
EXT4-fs (mmcblk0p8): mounted filesystem with ordered data mode. Opts: (null)
[  OK  ] Started Broadcom GRE Tunnel Setup Service.
[FAILED] Failed to start BCA License Init Service.
See 'systemctl status bca-license-init.service' fsh (1727): drop_caches: 1
or details.
[  OK  ] Started Install Broadocm wifi drivers.
[  OK  ] Started Default Time Setter.
[  OK  ] Started Mount nvram File System Service.
         Starting Install Broadocm wifi drivers...
[  OK  ] Started Update UTMP about System Runlevel Changes.
[  OK  ] Started Install Broadocm wifi drivers.
         Starting Install Broadocm wifi drivers...
Loading wlshared Module...
cfg80211: Loading compiled-in X.509 certificates for regulatory database
cfg80211: Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
platform regulatory.0: Direct firmware load for regulatory.db failed with error -2
cfg80211: failed to load regulatory.db
Loading HND Module
WL MLO AP IDS assignment -1 -1 -1 -1
igs_module_init:841:     IGS 29 create network socket successful
osl_skb_audit: PASS
wl_module_init: passivemode set to 0x1
wl_module_init: txworkq set to 0x0
wl_pktfwd_sys_init:  WL_PKTFWD[1.1.0] Success
SKY: wl_pci_probe Accepting device 0x6756
wl 0000:01:00.0: enabling device (0140 -> 0142)
SKY: wl_attach device (0x6756) selected for wl0
wl0: creating kthread wl0-kthrd
si_doattach: using BAR0 value: enum_base=84000000
BME Service Initialization
BME: M2M Core id 0x844 rev 132
M2M Service Initialization: M2M_DD_ENAB 0x00000003
M2M: M2M Core id 0x844 rev 132
M2M: SUCCESS eng 0 alloc rings <(ptrval),(ptrval)>,(ptrval) depth 256
M2M: SUCCESS eng 1 alloc rings <(ptrval),(ptrval)>,(ptrval) depth 256
M2M: DMA 0 IntRcvLazy 01000000
M2M: DMA 0 RcvCtrl XmtCtrl enabled
M2M: DMA 1 IntRcvLazy 01000000
M2M: DMA 1 RcvCtrl XmtCtrl enabled
wl0: phy_radio_attach: RF Band Cap: 2G:1 5G:1
WET:wet_maxip_per_sta=2
BME:register key<1010804> user RLM sel IDX set 1 mem 4 8 hi 0 0
wl0 taf_do_enable: TAF is enabled
CSIMON module registered
wfd0-thrd WL 0 FLowControl total<59918> lo<17975> hi<8987> favor prio<4>
wfd_bind: wfd0-thrd initialized pktlists: radio 0 nodes 4104 xfer wl_pktfwd_xfer_callback+0x0/0x4e0 [wl]

Creating CPU ring for queue number 8 with 2048 packets descriptor=0xbf4fc7c0, size_of_entry 16
Done initializing Ring 8 Base=0xed380000 num of entries= 2048 RDD Base=2d380000 descriptor=0xbf4fc7c0
Creating CPU ring for queue number 9 with 2048 packets descriptor=0xbf4fc818, size_of_entry 16
Done initializing Ring 9 Base=0xed390000 num of entries= 2048 RDD Base=2d390000 descriptor=0xbf4fc818
 wfd_bind: Dev wl0 wfd_idx 0 wl_radio_idx 0 Type skb:sll configured WFD thread wfd0-thrd minQId/maxQId (0/1), status (0) qmask 0x3
wl_wfd_bind: wl0 wfd_idx 0 success
Assigning idx[16] for wl0
wfd_registerdevice Successfully registered dev wl0 ifidx 0 wfd_idx 0
wl0: Broadcom BCM6756 802.11 Wireless Controller 17.10.251.7305 (r) [8d5afc1d8] (I)
dgasp: kerSysRegisterDyingGaspHandler: wl0 registered
SKY: wl_pci_probe Rejecting device 0x6715
SKY: wl_pci_probe Accepting device 0x6710
wl 0002:01:00.0: enabling device (0140 -> 0142)
SKY: wl_attach device (0x6710) selected for wl1
wl1: creating kthread wl1-kthrd
BME Service Initialization
BME: M2M Core id 0x844 rev 129
M2M Service Initialization: M2M_DD_ENAB 0x00000003
M2M: M2M Core id 0x844 rev 129
M2M: SUCCESS eng 0 alloc rings <(ptrval),(ptrval)>,(ptrval) depth 256
M2M: SUCCESS eng 1 alloc rings <(ptrval),(ptrval)>,(ptrval) depth 256
M2M: DMA 0 IntRcvLazy 01000000
M2M: DMA 0 RcvCtrl XmtCtrl enabled
M2M: DMA 1 IntRcvLazy 01000000
M2M: DMA 1 RcvCtrl XmtCtrl enabled
wl1: phy_radio_attach: RF Band Cap: 2G:1 5G:1
wl1: PCIE config linkctrl:0x10120000 linkcap:0x46dc12 max_speed:5 GT/s max_width:1  neg_speed:5 GT/s neg_width:1 => 'slow':0
WET:wet_maxip_per_sta=2
BME:register key<1010802> user RLM sel IDX set 1 mem 2 8 hi 0 0
wl1 taf_do_enable: TAF is enabled
CSIMON module registered
wfd1-thrd WL 1 FLowControl total<59918> lo<17975> hi<8987> favor prio<4>
wfd_bind: wfd1-thrd initialized pktlists: radio 1 nodes 4104 xfer wl_pktfwd_xfer_callback+0x0/0x4e0 [wl]

Creating CPU ring for queue number 11 with 2048 packets descriptor=0xbf4fc8c8, size_of_entry 16
Done initializing Ring 11 Base=0xecf30000 num of entries= 2048 RDD Base=2cf30000 descriptor=0xbf4fc8c8
Creating CPU ring for queue number 12 with 2048 packets descriptor=0xbf4fc920, size_of_entry 16
Done initializing Ring 12 Base=0xec820000 num of entries= 2048 RDD Base=2c820000 descriptor=0xbf4fc920
 wfd_bind: Dev wl1 wfd_idx 1 wl_radio_idx 1 Type skb:sll configured WFD thread wfd1-thrd minQId/maxQId (0/1), status (0) qmask 0xc
wl_wfd_bind: wl1 wfd_idx 1 success
Assigning idx[17] for wl1
wfd_registerdevice Successfully registered dev wl1 ifidx 0 wfd_idx 1
wl1: Broadcom BCM6710 802.11 Wireless Controller 17.10.251.7305 (r) [8d5afc1d8] (I)
dgasp: kerSysRegisterDyingGaspHandler: wl1 registered
ERROR: IOCTL BOARD_IOCTL_FLASH_READ attempted -- should be done in library, not IOCTL
dhd_module_init in
DHD_FKB_POOL size is:1280 and entry size:2624
DHD_PKTTAG POOL size is:2592 and entry size:64
dhd_pktfwd_sys_init:  dhd_PKTFWD[1.0.0] Success
dhd_queue_budget = 256
dhd_sta_threshold = 2048
dhd_if_threshold = 65536
PCI_PROBE:  bus 1, slot 0,vendor 14E4, device 6715(good PCI location)
pcieh 0001:01:00.0: enabling device (0140 -> 0142)
DHD: dongle ram size is set to 5242880(orig 5242880) at 0x0
WET:wet_maxip_per_sta = 2
dhd:2: fw path:/etc/wlan/dhd nv path:(null)
dol2 not supported, hw [0x3] nv [0x7]
dhd_runner_attach: Tx Offload - Disabled, Ring Size = 1024
dhd_runner_attach: Rx Offload - Disabled, Ring Size = 1024
CFG80211-ERROR) wl_setup_wiphy :
Registering Vendor80211
CFG80211-ERROR) wl_cfg80211_apply_eventbuffer :
Get event_msgs error (-19)
CFG80211-ERROR) wl_cfg80211_set_cac_state_change_eventbits :
failed to set WLC_E_CAC_STATE_CHANGE bit
CFG80211-ERROR) wl_cfg80211_apply_eventbuffer :
Get event_msgs error (-19)
CFG80211-ERROR) wl_cfg80211_set_radar_detect_eventbits :
failed to set WLC_E_RADAR_DETECTED bit
dhd_attach(): thread:dhd_watchdog_thread:79e started
dhd_deferred_work_init: work queue initialized
wl2: pktfwd_tbl 0xbfb11008
wfd_bind: wfd2-thrd initialized pktlists: radio 2 nodes 4104 xfer dhd_pktfwd_xfer_callback+0x0/0x7e8 [dhd]

Creating CPU ring for queue number 14 with 2048 packets descriptor=0xbf4fc9d0, size_of_entry 16
Done initializing Ring 14 Base=0xec7c0000 num of entries= 2048 RDD Base=2c7c0000 descriptor=0xbf4fc9d0
Creating CPU ring for queue number 15 with 2048 packets descriptor=0xbf4fca28, size_of_entry 16
Done initializing Ring 15 Base=0xec7d0000 num of entries= 2048 RDD Base=2c7d0000 descriptor=0xbf4fca28
Instantiating WFD 2 thread
 wfd_bind: Dev wl2 wfd_idx 2 wl_radio_idx 2 Type fkb:sll configured WFD thread wfd2-thrd minQId/maxQId (0/1), status (0) qmask 0x30
dhd_wfd_bind: wl2 wfd_idx 2 success
dhdpcie_irq_enabled: depth:0
------------[ cut here ]------------
WARNING: CPU: 1 PID: 1949 at mm/page_alloc.c:4421 __alloc_pages_nodemask+0x99c/0xb38
Modules linked in: dhd(+) init_addr(bfb35000 - bfb36000), core_addr(bfa50000 - bfae9000)
 wl(P) init_addr(00000000 - 00000000), core_addr(f950f000 - f9838000)
 igs init_addr(00000000 - 00000000), core_addr(bfa47000 - bfa4b000)
 emf init_addr(00000000 - 00000000), core_addr(bfa3b000 - bfa3e000)
 hnd init_addr(00000000 - 00000000), core_addr(bf9ca000 - bf9f9000)
 cfg80211 init_addr(00000000 - 00000000), core_addr(bf97d000 - bf9a9000)
 firmware_class init_addr(00000000 - 00000000), core_addr(bf973000 - bf974000)
 wlshared init_addr(00000000 - 00000000), core_addr(bf96a000 - bf96b000)
 bcm_thermal init_addr(00000000 - 00000000), core_addr(bf957000 - bf958000)
 cdc_mbim init_addr(00000000 - 00000000), core_addr(bf94e000 - bf94f000)
 cdc_ncm init_addr(00000000 - 00000000), core_addr(bf941000 - bf944000)
 qmi_wwan init_addr(00000000 - 00000000), core_addr(bf931000 - bf933000)
 usbnet init_addr(00000000 - 00000000), core_addr(bf923000 - bf927000)
 mii init_addr(00000000 - 00000000), core_addr(bf91c000 - bf91d000)
 option init_addr(00000000 - 00000000), core_addr(bf8fe000 - bf8ff000)
 usb_wwan init_addr(00000000 - 00000000), core_addr(bf8f7000 - bf8f8000)
 usbserial init_addr(00000000 - 00000000), core_addr(bf8e9000 - bf8ed000)
 smtc init_addr(00000000 - 00000000), core_addr(bf8dc000 - bf8df000)
dhd_watchdog_thread delay 200ms to access the dongle...
 bcm_pondrv(P) init_addr(00000000 - 00000000), core_addr(bf88a000 - bf8a5000)
 uas init_addr(00000000 - 00000000), core_addr(bf87e000 - bf881000)
 usb_storage init_addr(00000000 - 00000000), core_addr(bf864000 - bf869000)
 usblp init_addr(00000000 - 00000000), core_addr(bf859000 - bf85b000)
 xhci_plat_hcd init_addr(00000000 - 00000000), core_addr(bf850000 - bf851000)
 xhci_hcd init_addr(00000000 - 00000000), core_addr(bf827000 - bf83b000)
 ohci_pci init_addr(00000000 - 00000000), core_addr(bf81e000 - bf81f000)
 ohci_platform init_addr(00000000 - 00000000), core_addr(bf815000 - bf816000)
 ohci_hcd init_addr(00000000 - 00000000), core_addr(bf806000 - bf80b000)
 ehci_pci init_addr(00000000 - 00000000), core_addr(bf7fd000 - bf7fe000)
 ehci_platform init_addr(00000000 - 00000000), core_addr(bf7f4000 - bf7f5000)
 ehci_hcd init_addr(00000000 - 00000000), core_addr(bf7e2000 - bf7ea000)
 bcm_bca_usb init_addr(00000000 - 00000000), core_addr(bf7d9000 - bf7da000)
 hs_uart_drv init_addr(00000000 - 00000000), core_addr(bf7ce000 - bf7d0000)
 wfd init_addr(00000000 - 00000000), core_addr(bf7bf000 - bf7c4000)
 bcm_pcie_hcd init_addr(00000000 - 00000000), core_addr(bf79d000 - bf7ab000)
 bcmmcast init_addr(00000000 - 00000000), core_addr(bf775000 - bf786000)
 pktrunner(P) init_addr(00000000 - 00000000), core_addr(bf75d000 - bf765000)
 rdpa_cmd init_addr(00000000 - 00000000), core_addr(bf74a000 - bf750000)
 bcm_enet init_addr(00000000 - 00000000), core_addr(bf71e000 - bf732000)
 cmdlist(P) init_addr(00000000 - 00000000), core_addr(bf6fc000 - bf70d000)
 pktflow(P) init_addr(00000000 - 00000000), core_addr(bf694000 - bf6cb000)
 bcm_ingqos init_addr(00000000 - 00000000), core_addr(bf656000 - bf65a000)
 bcm_bp3drv(P) init_addr(00000000 - 00000000), core_addr(bf62f000 - bf640000)
 rdpa_mw init_addr(00000000 - 00000000), core_addr(bf61f000 - bf624000)
 rdpa_usr init_addr(00000000 - 00000000), core_addr(bf601000 - bf611000)
 rdpa(P) init_addr(00000000 - 00000000), core_addr(bf1b0000 - bf314000)
 rdpa_gpl_ext init_addr(00000000 - 00000000), core_addr(bf1a9000 - bf1aa000)
 bcmvlan(P) init_addr(00000000 - 00000000), core_addr(bf185000 - bf194000)
 bcm_bpm(P) init_addr(00000000 - 00000000), core_addr(bf171000 - bf177000)
 rdpa_gpl init_addr(00000000 - 00000000), core_addr(bf15e000 - bf160000)
 bdmf init_addr(00000000 - 00000000), core_addr(bf01a000 - bf037000)
 bcm_knvram init_addr(00000000 - 00000000), core_addr(bf010000 - bf011000)
 bcmlibs init_addr(00000000 - 00000000), core_addr(bf000000 - bf004000)
CPU: 2 PID: 1949 Comm: insmod Tainted: P                  4.19.294 #1
Hardware name: Generic DT based system
[<c1110cb0>] (unwind_backtrace) from [<c110bac0>] (show_stack+0x10/0x14)
[<c110bac0>] (show_stack) from [<c17db8ec>] (dump_stack+0x90/0xa4)
[<c17db8ec>] (dump_stack) from [<c17d2108>] (__warn+0xb8/0xd4)
[<c17d2108>] (__warn) from [<c17d2164>] (warn_slowpath_null+0x40/0x4c)
[<c17d2164>] (warn_slowpath_null) from [<c11b0398>] (__alloc_pages_nodemask+0x99c/0xb38)
[<c11b0398>] (__alloc_pages_nodemask) from [<c11136c0>] (__dma_alloc_buffer.constprop.0+0x30/0x88)
[<c11136c0>] (__dma_alloc_buffer.constprop.0) from [<c11137f8>] (simple_allocator_alloc+0x14/0x28)
[<c11137f8>] (simple_allocator_alloc) from [<c1112b50>] (__dma_alloc+0x140/0x314)
[<c1112b50>] (__dma_alloc) from [<c1112d58>] (arm_coherent_dma_alloc+0x34/0x3c)
[<c1112d58>] (arm_coherent_dma_alloc) from [<bfaa891c>] (osl_dma_alloc_contiguous+0x138/0x198 [dhd])
[<bfaa891c>] (osl_dma_alloc_contiguous [dhd]) from [<bfa8b268>] (dhdpcie_bhm_mem_alloc+0xb8/0x1f8 [dhd])
[<bfa8b268>] (dhdpcie_bhm_mem_alloc [dhd]) from [<bfa90fa8>] (dhdpcie_pci_probe+0x2dc/0x458 [dhd])
[<bfa90fa8>] (dhdpcie_pci_probe [dhd]) from [<c13f12c0>] (pci_device_probe+0x9c/0x124)
[<c13f12c0>] (pci_device_probe) from [<c1439d1c>] (really_probe+0x1e4/0x2b0)
[<c1439d1c>] (really_probe) from [<c143a0e8>] (__driver_attach+0xe0/0xe4)
[<c143a0e8>] (__driver_attach) from [<c1437e30>] (bus_for_each_dev+0x78/0xc0)
[<c1437e30>] (bus_for_each_dev) from [<c14391a4>] (bus_add_driver+0x184/0x208)
[<c14391a4>] (bus_add_driver) from [<c143a7c8>] (driver_register+0x74/0x108)
[<c143a7c8>] (driver_register) from [<bfa907b0>] (dhdpcie_bus_register+0x44/0x114 [dhd])
[<bfa907b0>] (dhdpcie_bus_register [dhd]) from [<bfb351e8>] (dhd_module_init+0x1e8/0x1000 [dhd])
[<bfb351e8>] (dhd_module_init [dhd]) from [<c1102dd4>] (do_one_initcall+0x58/0x1ac)
[<c1102dd4>] (do_one_initcall) from [<c118e674>] (do_init_module+0x44/0x1c0)
[<c118e674>] (do_init_module) from [<c11907c0>] (load_module+0x1f2c/0x22d0)
[<c11907c0>] (load_module) from [<c1190de8>] (sys_finit_module+0xd0/0xe8)
[<c1190de8>] (sys_finit_module) from [<c1101000>] (ret_fast_syscall+0x0/0x58)
Exception stack(0xec88bfa8 to 0xec88bff0)
bfa0:                   00000000 007151c8 00000003 00715190 00000000 00715570
bfc0: 00000000 007151c8 00715190 0000017b 00000000 00000005 bef77e04 bef77ef2
bfe0: bef77c58 bef77c48 0046f215 b6f37c92
---[ end trace 281550c19727e540 ]---
dhdpcie_bhm_mem_alloc: PCIe IPC BHM ALLOC FAILURE: size 16777216
dhd:2: fw path:/etc/wlan/dhd nv path:(null)
dhd_bus_start download fw /etc/wlan/dhd, nv
DHD  concate_extfdimg_name: Final FW path is /etc/wlan/dhd/6715b0//rtecdc.bin
dhd_bus_download_firmware: firmware path=/etc/wlan/dhd/6715b0//rtecdc.bin, nvram path=
dhdpcie_ramsize_adj: Enter
dhdpcie_ramsize_adj: Adjust dongle RAMSIZE to 0x380000
dhdpcie_download_code_file: process hybrid firmware file
dhdpcie_hybridfw_get_next_block Found section 0 with length 1679364
dhdpcie_hybridfw_get_next_block Found section 1 with length 1105920

RDK (A Yocto Project based Distro) 2.0 xle-wnc ttyAMA0

xle-wnc login: root (adhdpcie_download_code_file: hybridfw DMA Buf va ec200000 pa hi 0x00000000 lo 0x2c200000 len 1105920
utomatic login)

dhdpcie_bus_write_vars: Download, Upload and compare of NVRAM succeeded.
dhdpcie_bus_write_sysmem_tlvs: HYBRIDFW Host page location info: 0x000000002c200000 binary_size:1105920

PCIe IPC Host Dongle Training Commences ...

PCIe IPC UPLOAD COMMENCE
PCIe IPC LOCATED: read_u32 daddr32 0x000ae674 took 25023 usec. ram[0x00000000,0x0037fffc]
PCIe IPC HEADER: daddr32 0x000ae674 size 128 revision: host 0x86 dngl 0x86
         FWID 0x656d625f, flags 0x10a10086, dcap1 0x2f8f0000 dcap2 0x00000027
         trap 0x00000000 assrt 0x00000000,0x00000000,0 cons 0x0019a008
         mbox H2D 0x001b5690 D2H 0x001b5694 rings 0x001b23d0
PCIe IPC HEADER HME: version 9 users 15 size 256
         ID HMEUSR PAGES ALIGN   BOUNDARY  FLAGS  BHM
-sh: /etc/device.properties: No s         0 SCRMEM     1   256 0x01ffffff 0x003c  NO
uch file or directory     1 PKTPGR   512   256 0x01ffffff 0x003c  NO

          2 MACIFS   768   256 0x01ffffff 0x003c  NO
          3 LCLPKT   128   256 0x01ffffff 0x003c  NO
          4 PSQPKT   512   256 0x01ffffff 0x003e  NO
          5 CSIMON    33   256 0x01ffffff 0x003c  NO
          6 HMOSWP   270  4096 0x01ffffff 0x003f  NO
                                                                                                                                                     O
          8 AIR_IQ     0   256 0x01ffffff 0x003c  NO
          9 SBFTBL     1   256 0x01ffffff 0x003c  NO
         10 HMOSCB   810   256 0x01ffffff 0x003c  NO
         11 LOWMAC     0   256 0x01ffffff 0x003c  NO
         12 CLSBUF     0   256 0x01ffffff 0x003c  NO
         13 BMPSVC     0   256 0x01ffffff 0x003c  NO
         14 HMOPPR    20   256 0x01ffffff 0x003c  NO
PCIe IPC RINGS: size 128 Ring Mem daddr32 0x001b2450
         H2D Indices Array daddr32: WR 0x001b45d0 RD 0x001b4e18
         D2H Indices Array daddr32: WR 0x001b5660 RD 0x001b5678
         Total: H2D rings 530 D2H rings 6 flowrings 528 interfaces 16
PCIe IPC UPLOAD COMPLETED

root@xle-wnc:~# PCIe IPC REVISION 134 Configuration and Features
         Config  : D2H Sync Mode: 0x00000000
         Config  : Max Rings H2D 530 D2H 6
         Config  : Ring Index Size 4 bytes
         Feature : Host Backup Queue Depth
         Feature : Host iDMA
         Config  : Flowring per TID
         Feature : Dongle DMA Indices H2D 1 D2H 1
         Protocol: H2D WR Indices Array: DMA Buf va f60e9000 pa hi 0x00000000 lo 0x2c6d8000 len    2176 = 4 *  530
         Protocol: D2H RD Indices Array: DMA Buf va f60e9c00 pa hi 0x00000000 lo 0x2c6d8c00 len      64 = 4 *    6
         Protocol: D2H WR Indices Array: DMA Buf va f60ea000 pa hi 0x00000000 lo 0x2c6d9000 len      64 = 4 *    6
         Protocol: H2D RD Indices Array: DMA Buf va f60ea400 pa hi 0x00000000 lo 0x2c6d9400 len    2176 = 4 *  530
         Feature : SFH Insertion 1
         Feature : CSI Monitor
         Feature : Fast Delete Ring
         Feature : Fast Delete Ring disabled
dor2: HBQD not supported by Runner
dor2: BA256 updated Profile ID [4], max_items RxP/RxC [1024]/[4096]

         Config  : WI Formats TxP 1 RxP 1 TxC 1 RxC 1
         Feature : HWA iDMA RxPost
         Feature : HWA iDMA TxCpl
         Feature : HWA iDMA RxCpl
         Feature : HWA TxPost
         Protocol: H2D TxPost  : format 1 [type 2 size 32 max 2560 hdr_off 16]
dor2: TxP ring format type [2] not supported by Runner
         Protocol: H2D RxPost 1: format 1 [type 1 size  8 max 1024 shift 0]
dor2: RxP ring format type [1] not supported by Runner
         Protocol: D2H TxCpln 3: format 1 [type 1 size  8 max 1024]
dor2: TxC ring format type [1] not supported by Runner
         Protocol: H2D RxCpln 4: format 1 [type 1 size  8 max 1024 offset 0]
dor2: RxC ring format type [1] not supported by Runner
dor2 ringid [4] Using default max_items [1024]
         Feature : TID from Donlge (rx_cmpl_v2)  supported
         Config  : RxPost Data buffer length 1836
         Config  : Host PhysAddr hi32 0
         Protocol: HME Haddr64 Table users 15 DMA Buf va ee5bb000 pa hi 0x00000000 lo 0x2e5bb000 len     120
         Protocol: HME user 0 DMA Buf va ef3f2000 pa hi 0x00000000 lo 0x2f3f2000 len    4096
         Protocol: HME user 1 DMA Buf va ebc00000 pa hi 0x00000000 lo 0x2bc00000 len 2097152
         Protocol: HME user 2 DMA Buf va eb800000 pa hi 0x00000000 lo 0x2b800000 len 3145728
         Protocol: HME user 3 DMA Buf va ebe00000 pa hi 0x00000000 lo 0x2be00000 len  524288
         Protocol: HME user 4 DMA Buf va eb400000 pa hi 0x00000000 lo 0x2b400000 len 2097152
         Protocol: HME user 5 DMA Buf va ebe80000 pa hi 0x00000000 lo 0x2be80000 len  135168
         Protocol: HME user 6 DMA Buf va ec200000 pa hi 0x00000000 lo 0x2c200000 len 1105920
         Protocol: HME user 7 DMA Buf va ebf00000 pa hi 0x00000000 lo 0x2bf00000 len  786432
         Protocol: HME user 9 DMA Buf va ef3f1000 pa hi 0x00000000 lo 0x2f3f1000 len    4096
         Protocol: HME user 10 DMA Buf va eb000000 pa hi 0x00000000 lo 0x2b000000 len 3317760
         Protocol: HME user 14 DMA Buf va ebec0000 pa hi 0x00000000 lo 0x2bec0000 len   81920
PCIe IPC Host Dongle Training Completed!

dhd_bus_start: Initializing 530 h2drings
dhd_runner_profile_init: profile = 4 0512/0512 1024/2048 0512/0512 0512/0000 0512/0000
dor2: using WME AC based flowid allocation
Attach flowrings pool for 528 rings
iDMA enabled PCIEControl = 1083839a
Config doorbell for d2h_rings <3>
Runner DHD Offload initialization Successful

Created netlink: radio unit idx 2, nl_id 24
CSIMON: HOST CSIMON[1.1.1]
dhd2: SBFTBL disabled
CUR_ETHERADDR : 6
d8 9c 8e 00 05 5c
dhd_sync_with_dongle: GET_REVINFO device 0x6003, vendor 0x14e4, chipnum 0x6715, corerev 132
Dongle Host Driver, version 17.10.251.7305 (r) [8d5afc1d8] (I)
Compiled in drivers/net/wireless/bcmdhd
Assigning idx[18] for wl2
wfd_registerdevice Successfully registered dev wl2 ifidx 0 wfd_idx 2
Register interface [wl2]  MAC: d8:9c:8e:00:05:5c

dhd_module_init out
IPv6: ADDRCONF(NETDEV_UP): eth0: link is not ready
IPv6: ADDRCONF(NETDEV_UP): eth1: link is not ready
wl0: mtu greater than device maximum
wl1: mtu greater than device maximum
eth0 EGPHY:GMII:0x2 - Link Up 1 Gbps Full duplex
eth1 EGPHY:GMII:0x5 - Link Up 1 Gbps Full duplex
IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
IPv6: ADDRCONF(NETDEV_CHANGE): eth1: link becomes ready
CSIMON:  CSIMON[1.1.1] Initialization
Assigning idx[19] for wl0.1
wfd_registerdevice Successfully registered dev wl0.1 ifidx 1 wfd_idx 0
Assigning idx[20] for wl0.2
wfd_registerdevice Successfully registered dev wl0.2 ifidx 2 wfd_idx 0
Assigning idx[21] for wl0.3
wfd_registerdevice Successfully registered dev wl0.3 ifidx 3 wfd_idx 0
Assigning idx[22] for wl0.4
wfd_registerdevice Successfully registered dev wl0.4 ifidx 4 wfd_idx 0
Assigning idx[23] for wl0.5
wfd_registerdevice Successfully registered dev wl0.5 ifidx 5 wfd_idx 0
Assigning idx[24] for wl0.6
wfd_registerdevice Successfully registered dev wl0.6 ifidx 6 wfd_idx 0
Assigning idx[25] for wl0.7
wfd_registerdevice Successfully registered dev wl0.7 ifidx 7 wfd_idx 0
CSIMON:  CSIMON[1.1.1] Initialization
CSIMON: M2M usr already registered ...
CFG80211-ERROR) wl_cfg80211_ch_switch_notify :
non-cfg path, need not notify nl80211 layer
CSIMON:  CSIMON[1.1.1] Initialization
CSIMON: M2M usr already registered ...
CFG80211-ERROR) wl_allocate_wowl_config :
Wowl not supported (-23)
CFG80211-ERROR) wl_cfg80211_ch_switch_notify :
non-cfg path, need not notify nl80211 layer
CSIMON:  CSIMON[1.1.1] Initialization
Assigning idx[26] for wl1.1
wfd_registerdevice Successfully registered dev wl1.1 ifidx 1 wfd_idx 1
Assigning idx[27] for wl1.2
wfd_registerdevice Successfully registered dev wl1.2 ifidx 2 wfd_idx 1
Assigning idx[28] for wl1.3
wfd_registerdevice Successfully registered dev wl1.3 ifidx 3 wfd_idx 1
Assigning idx[29] for wl1.4
wfd_registerdevice Successfully registered dev wl1.4 ifidx 4 wfd_idx 1
Assigning idx[30] for wl1.5
wfd_registerdevice Successfully registered dev wl1.5 ifidx 5 wfd_idx 1
Assigning idx[31] for wl1.6
wfd_registerdevice Successfully registered dev wl1.6 ifidx 6 wfd_idx 1
Assigning idx[32] for wl1.7
wfd_registerdevice Successfully registered dev wl1.7 ifidx 7 wfd_idx 1

root@xle-wnc:~#
root@xle-wnc:~# CSIMON:  CSIMON[1.1.1] Initialization
CSIMON: M2M usr already registered ...

root@xle-wnc:~# lsmod
Module                  Size  Used by
dhd                   933888  0
wl                   8245248  0
igs                    32768  2 wl,dhd
emf                    24576  3 wl,igs,dhd
hnd                   319488  4 wl,emf,igs,dhd
cfg80211              241664  2 wl,dhd
firmware_class         16384  1 cfg80211
wlshared               16384  2 wl,dhd
bcm_thermal            16384  0
cdc_mbim               16384  0
cdc_ncm                24576  1 cdc_mbim
qmi_wwan               28672  0
usbnet CFG80211-ERROR) wl_cfg80211_ch_switch_notify :
                28672  3 cdc_mbinon-cfg path, need not notify nl80211 layer
m,qmi_wwan,cdc_ncm
mii                    16384  1 usbnet
option                 49152  0
usb_wwan               16384  1 option
usbserial              28672  2 option,usb_wwan
smtc                   28672  0
bcm_pondrv            253952  0
uas                    24576  0
usb_storage            57344  1 uas
usblp                  20480  0
xhci_plat_hcd          16384  0
xhci_hcd              122880  1 xhci_plat_hcd
ohci_pci               16384  0
ohci_platform          16384  0
ohci_hcd               32768  2 ohci_pci,ohci_platform
ehci_pci               16384  0
ehci_platform          16384  0
ehci_hcd               45056  2 ehci_platform,ehci_pci
bcm_bca_usb            16384  0
hs_uart_drv            20480  0
wfd                    36864  2 wl,dhd
bcm_pcie_hcd           94208  1 dhd
bcmmcast              114688  4 emf,igs,dhd,wfd
pktrunner              61440  0
rdpa_cmd               45056  0
bcm_enet              126976  1 bcm_pcie_hcd
cmdlist               102400  1 pktrunner
pktflow               356352  1 pktrunner
bcm_ingqos            225280  1 rdpa_cmd
bcm_bp3drv            118784  0
rdpa_mw                36864  2 pktrunner,rdpa_cmd
rdpa_usr               86016  0
rdpa                 3788800  0
rdpa_gpl_ext           16384  1 rdpa_cmd
bcmvlan               102400  0
bcm_bpm                49152  0
rdpa_gpl               28672  9 rdpa_usr,pktrunner,bcm_enet,rdpa_mw,bcmmcast,dhd,wfd,rdpa_cmd,rdpa
bdmf                 1257472  11 rdpa_usr,pktrunner,bcm_enet,rdpa_mw,rdpa_gpl,bcmmcast,dhd,wfd,rdpa_cmd,rdpa,bcm_pondrv
bcm_knvram             16384  7 bcm_pcie_hcd,hnd,rdpa_mw,dhd
bcmlibs                32768  6 wl,pktrunner,dhd,wfd,pktflow,rdpa
root@xle-wnc:~#
root@xle-wnc:~#
root@xle-wnc:~# CSIMON:  CSIMON[1.1.1] Initialization
CSIMON: M2M usr already registered ...
CFG80211-ERROR) wl_allocate_wowl_config :
Wowl not supported (-23)
CFG80211-ERROR) wl_cfg80211_ch_switch_notify :
non-cfg path, need not notify nl80211 layer
wl2: dhd_prot_ioctl: status ret value is -29 cmd=263
dhd_hwa_event: Dongle(wl2) schedule hwa event
dhd_hwa_event_handler: Dongle(wl2) hwa event scheduled
wl2: dhd_prot_ioctl: status ret value is -29 cmd=263
Assigning idx[33] for wl2.1
wfd_registerdevice Successfully registered dev wl2.1 ifidx 1 wfd_idx 2
Register interface [wl2.1]  MAC: da:9c:8e:00:05:5d

(null): ifindex 1 Post ifcreate ops done. Returning
Assigning idx[34] for wl2.2
wfd_registerdevice Successfully registered dev wl2.2 ifidx 2 wfd_idx 2
Register interface [wl2.2]  MAC: da:9c:8e:00:05:5e

(null): ifindex 2 Post ifcreate ops done. Returning
Assigning idx[35] for wl2.3
wfd_registerdevice Successfully registered dev wl2.3 ifidx 3 wfd_idx 2
Register interface [wl2.3]  MAC: da:9c:8e:00:05:5f

(null): ifindex 3 Post ifcreate ops done. Returning
Assigning idx[36] for wl2.4
wfd_registerdevice Successfully registered dev wl2.4 ifidx 4 wfd_idx 2
Register interface [wl2.4]  MAC: da:9c:8e:00:05:58

(null): ifindex 4 Post ifcreate ops done. Returning
Assigning idx[37] for wl2.5
wfd_registerdevice Successfully registered dev wl2.5 ifidx 5 wfd_idx 2
Register interface [wl2.5]  MAC: da:9c:8e:00:05:59

(null): ifindex 5 Post ifcreate ops done. Returning
Assigning idx[38] for wl2.6
wfd_registerdevice Successfully registered dev wl2.6 ifidx 6 wfd_idx 2
Register interface [wl2.6]  MAC: da:9c:8e:00:05:5a

(null): ifindex 6 Post ifcreate ops done. Returning
Assigning idx[39] for wl2.7
wfd_registerdevice Successfully registered dev wl2.7 ifidx 7 wfd_idx 2
Register interface [wl2.7]  MAC: da:9c:8e:00:05:5b

(null): ifindex 7 Post ifcreate ops done. Returning
dhd_set_monitor: Mismatched params, return

root@xle-wnc:~#
root@xle-wnc:~# wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
dhd_wmf_igs_broadcast: WMF: send failure
IGMP Query send failed
random: 496 urandom warning(s) missed due to ratelimiting
dhd_wmf_igs_broadcast: WMF: send failure
IGMP Query send failed
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -20 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -11 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
wl2: dhd_prot_ioctl: status ret value is -23 cmd=263
dhd_hwa_event: Dongle(wl2) schedule hwa event
dhd_hwa_event_handler: Dongle(wl2) hwa event scheduled
wl2: dhd_prot_ioctl: status ret value is -44 cmd=263
wl2: dhd_prot_ioctl: status ret value is -44 cmd=263
wl2: dhd_prot_ioctl: status ret value is -44 cmd=263
wl2: dhd_prot_ioctl: status ret value is -44 cmd=263
wl2: dhd_prot_ioctl: status ret value is -44 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -2 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -2 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -2 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -2 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -2 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -7 cmd=263
wl2: dhd_prot_ioctl: status ret value is -2 cmd=263
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
dhd_set_mac_addr_handler: MACID is overwritten
wl2: dhd_prot_ioctl: status ret value is -23 cmd=139
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
  0000: 01
  0000: 6e 2c 0a 03 0c 03 0e 03 10 00 12 03 14 03 16 03
  0010: 18 04 1a 04 1c 04 1e 04 2c 06 2e 06 30 07 00 07
  0020: 08 0f 10 17 18 1f 20 27 28 2f 30 37 38 3f
wl2: dhd_prot_ioctl: status ret value is -23 iov=p2p
dhd_hwa_event: Dongle(wl2) schedule hwa event
dhd_hwa_event_handler: Dongle(wl2) hwa event scheduled
wl2: dhd_prot_ioctl: status ret value is -23 iov=wowl
CFG80211-ERROR) wl_allocate_wowl_config :
Wowl not supported (-23)
Info: PBCD wps_pbcd_update_wps_ifnames did not find any interface to add to wps ap ifnames list wps_ifnames=[] lan_ifnames=[]
Info: PBCD wps_pbcd_update_wps_ifnames did not find any interface to add to wps sta ifnames list wps_ifnames=[] lan_ifnames=[]
Info: PBCD wps_pbcd_init_co_host_nbr_info did not find any interface to add to ifnames from lan_ifnames=[]

root@xle-wnc:~#
root@xle-wnc:~# uptime
 00:00:50 up 1 min,  load average: 1.19, 0.36, 0.12
root@xle-wnc:~#
root@xle-wnc:~#
root@xle-wnc:~# lsmod
Module                  Size  Used by
dhd                   933888  0
wl                   8245248  0
igs                    32768  2 wl,dhd
emf                    24576  3 wl,igs,dhd
hnd                   319488  4 wl,emf,igs,dhd
cfg80211              241664  2 wl,dhd
firmware_class         16384  1 cfg80211
wlshared               16384  2 wl,dhd
bcm_thermal            16384  0
cdc_mbim               16384  0
cdc_ncm                24576  1 cdc_mbim
qmi_wwan               28672  0
usbnet                 28672  3 cdc_mbim,qmi_wwan,cdc_ncm
mii                    16384  1 usbnet
option                 49152  0
usb_wwan               16384  1 option
usbserial              28672  2 option,usb_wwan
smtc                   28672  0
bcm_pondrv            253952  0
uas                    24576  0
usb_storage            57344  1 uas
usblp                  20480  0
xhci_plat_hcd          16384  0
xhci_hcd              122880  1 xhci_plat_hcd
ohci_pci               16384  0
ohci_platform          16384  0
ohci_hcd               32768  2 ohci_pci,ohci_platform
ehci_pci               16384  0
ehci_platform          16384  0
ehci_hcd               45056  2 ehci_platform,ehci_pci
bcm_bca_usb            16384  0
hs_uart_drv            20480  0
wfd                    36864  2 wl,dhd
bcm_pcie_hcd           94208  1 dhd
bcmmcast              114688  4 emf,igs,dhd,wfd
pktrunner              61440  0
rdpa_cmd               45056  0
bcm_enet              126976  1 bcm_pcie_hcd
cmdlist               102400  1 pktrunner
pktflow               356352  1 pktrunner
bcm_ingqos            225280  1 rdpa_cmd
bcm_bp3drv            118784  0
rdpa_mw                36864  2 pktrunner,rdpa_cmd
rdpa_usr               86016  0
rdpa                 3788800  0
rdpa_gpl_ext           16384  1 rdpa_cmd
bcmvlan               102400  0
bcm_bpm                49152  0
rdpa_gpl               28672  9 rdpa_usr,pktrunner,bcm_enet,rdpa_mw,bcmmcast,dhd,wfd,rdpa_cmd,rdpa
bdmf                 1257472  11 rdpa_usr,pktrunner,bcm_enet,rdpa_mw,rdpa_gpl,bcmmcast,dhd,wfd,rdpa_cmd,rdpa,bcm_pondrv
bcm_knvram             16384  9 bcm_pcie_hcd,hnd,rdpa_mw,dhd
bcmlibs                32768  6 wl,pktrunner,dhd,wfd,pktflow,rdpa
root@xle-wnc:~# ifconfig
eth0      Link encap:Ethernet  HWaddr D8:9C:8E:00:05:5B
          inet6 addr: fe80::da9c:8eff:fe00:55b/64 Scope:Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:35 errors:0 dropped:0 overruns:0 frame:0
          TX packets:8 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:5780 (5.6 KiB)  TX bytes:928 (928.0 B)

eth1      Link encap:Ethernet  HWaddr D8:9C:8E:00:05:5B
          inet6 addr: fe80::da9c:8eff:fe00:55b/64 Scope:Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:85 errors:0 dropped:0 overruns:0 frame:0
          TX packets:7 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:10727 (10.4 KiB)  TX bytes:854 (854.0 B)

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope:Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 (0.0 B)  TX bytes:0 (0.0 B)

wl0       Link encap:Ethernet  HWaddr D8:9C:8E:00:05:5D
          inet6 addr: fe80::da9c:8eff:fe00:55d/64 Scope:Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:0 errors:0 dropped:1 overruns:0 frame:174
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 (0.0 B)  TX bytes:0 (0.0 B)
          Interrupt:23

wl1       Link encap:Ethernet  HWaddr D8:9C:8E:00:05:5E
          inet6 addr: fe80::da9c:8eff:fe00:55e/64 Scope:Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:0 errors:0 dropped:1 overruns:0 frame:6770
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 (0.0 B)  TX bytes:0 (0.0 B)
          Interrupt:90

wl2       Link encap:Ethernet  HWaddr D8:9C:8E:00:05:5C
          inet6 addr: fe80::da9c:8eff:fe00:55c/64 Scope:Link
          UP BROADCAST RUNNING MULTICAST  MTU:1600  Metric:1
          RX packets:0 errors:0 dropped:34 overruns:0 frame:0
          TX packets:7 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 (0.0 B)  TX bytes:826 (826.0 B)

root@xle-wnc:~# cat /ver
cat: can't open '/ver': No such file or directory
root@xle-wnc:~# cat /vers
cat: can't open '/vers': No such file or directory
root@xle-wnc:~#
root@xle-wnc:~#
root@xle-wnc:~# cat /ver
cat: can't open '/ver': No such file or directory
root@xle-wnc:~#

