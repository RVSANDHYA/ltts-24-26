/*************************************************************************************
 *
 *   * Project     : C Application to handle Front Panel Button Events and do actions
 *   * File        : button_handler.c
 *   * Author      : vysakh.venugopal@sky.uk
 *   * Date        : 08/11/2022
 *   *
 *   * Description : Application which monitor for key events on /dev/input/event0.
 *   Once driver pushed the key events upon reset button press/hold, application
 *   will catch it and do the required actions.
 *   It supports:
 *       - Upon 5s key hold and release - reboot
 *       - Upon hold for 15s - Do hard factory reset
 **************************************************************************************/
/* Header Files*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <linux/input.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <sys/un.h>
#include <unistd.h>

/* Defines. */
#define LOGERROR(fmt, arg...) \
    fprintf(stderr, "ERROR[%s.%u]: " fmt "\n", __FUNCTION__, __LINE__, ##arg)

#define LOGINFO(fmt, arg...) \
    fprintf(stderr, "NOTICE:[%s.%u]: " fmt "\n", __FUNCTION__, __LINE__, ##arg)


#define KEY_PRESS_VAL 1
#define KEY_RELEASE_VAL 0
#define KEY_HOLD_VAL 2

#define EVENT_INPUT_FILE "/dev/input/event0"
#define BUF_SIZE 1024
#define FP_KEY_CODE 88
#define REBOOT_REASON_RESET_BUTTON "reset-button"
#define RESET_TIMEOUT 5
#define FR_RESET_TIMEOUT 15

#define RESET_HANDLER_SCRIPT "/etc/init/button_handler.sh"
#define RESET "reset"
#define FACTORY_RESET "factory_reset"

/* Static Functions. */
/**
 * @brief Do soft reboot.
 */
static void do_reset (void);

/**
 * @brief Do hard factory reset.
 *
 */
static void do_factory_reset (void);

static void do_reset (void)
{
    LOGINFO("Enter");
    char cmd[BUF_SIZE] = {0};

    sprintf(cmd, "%s %s", RESET_HANDLER_SCRIPT,RESET);
    if ( system(cmd)) {
        LOGERROR("Failed execute script %s to do system %s\n", RESET_HANDLER_SCRIPT, RESET);
    }
}

static void do_factory_reset (void) {
    LOGINFO("Enter");
    char cmd[BUF_SIZE] = {0};

    sprintf(cmd, "%s %s", RESET_HANDLER_SCRIPT,FACTORY_RESET);
    if ( system(cmd)) {
        LOGERROR("Failed execute script %s to do system %s\n", RESET_HANDLER_SCRIPT, FACTORY_RESET);
    }
}

/* Main routine. */
int main (int argc, char** argv)
{
    bool   bthread_running = true;
    int    ifd = 0;

    ifd = open (EVENT_INPUT_FILE, O_RDONLY|O_SYNC);
    if ( ifd > 0 )
    {
        struct input_event ev;
        const int count = sizeof (ev);
        long int keypress_time = 0;
        long int keyrelease_time = 0;
        long int elapsedTime = 0;

        while (bthread_running == true)
        {
            bzero (&ev, count);
            int ret = read (ifd, &ev, count);
            if (count == ret)
            {
                if ( ev.type == EV_KEY && ev.code == FP_KEY_CODE)
                {
                    LOGINFO("Getting input %d %d %d %ld", ev.type, ev.code, ev.value, ev.time.tv_sec);
                    switch (ev.value)
                    {
                        case KEY_PRESS_VAL:
                            LOGINFO("Key Press detected, time [%ld]", ev.time.tv_sec);
                            keypress_time = ev.time.tv_sec;
                            break;
                        case KEY_RELEASE_VAL:
                            LOGINFO("Key Release detected, time [%ld]", ev.time.tv_sec);
                            keyrelease_time = ev.time.tv_sec;
                            elapsedTime = keyrelease_time - keypress_time;
                            LOGINFO("Time between press/release = [%ld]", elapsedTime);
                            if (elapsedTime >= RESET_TIMEOUT && elapsedTime < FR_RESET_TIMEOUT) {
                                LOGINFO("Requested soft reset.");
                                do_reset();
                            }
                            break;
                        case KEY_HOLD_VAL:
                            //Hold event received. Required a factory reset.
                            LOGINFO("Hold key for 15 seconds, requested factory reset \n");
                            do_factory_reset ();
                            break;
                    }
                }
            }
            else
            {
                LOGERROR("Failed to read input from %s",EVENT_INPUT_FILE);
                break;
            }
        }
    }
    else
    {
        LOGERROR("Failed to open file %s", EVENT_INPUT_FILE);
    }

    return 0;
}
