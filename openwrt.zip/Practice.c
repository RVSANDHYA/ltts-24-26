Kerenel Development:
-------------------
I want to practice two major things:
1. Write a kernel module and how to debug it with GDB when there a panic from this module
2. Write a driver to read the dtb from kernel data structures.

